import { db } from "./index";
import * as schema from "@shared/schema";
import { and, eq } from "drizzle-orm";
import bcrypt from "bcrypt";

async function seed() {
  try {
    // Check if admin user exists
    const existingAdmin = await db.query.users.findFirst({
      where: eq(schema.users.role, schema.UserRole.ADMIN),
    });

    if (!existingAdmin) {
      console.log("Creating admin user...");
      const hashedPassword = await bcrypt.hash("admin123", 10);
      
      // Insert admin user
      const [adminUser] = await db.insert(schema.users).values({
        username: "admin",
        email: "admin@medicare.com",
        password: hashedPassword,
        firstName: "Sarah",
        lastName: "Johnson",
        role: schema.UserRole.ADMIN,
        status: schema.UserStatus.ACTIVE,
        profileImage: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80",
      }).returning();
      
      console.log("Admin user created successfully.");
    } else {
      console.log("Admin user already exists.");
    }

    // Seed doctor data
    const doctorData = [
      {
        username: "doctor_emily",
        email: "emily.wilson@medicare.com",
        password: "password123",
        firstName: "Emily",
        lastName: "Wilson",
        role: schema.UserRole.DOCTOR,
        profileImage: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80",
        specialization: "Cardiology",
        status: schema.DoctorStatus.AVAILABLE,
        availableDays: ["monday", "tuesday", "wednesday", "thursday", "friday"],
        nextAvailability: new Date("2023-05-24T14:00:00"),
      },
      {
        username: "doctor_michael",
        email: "michael.chen@medicare.com",
        password: "password123",
        firstName: "Michael",
        lastName: "Chen",
        role: schema.UserRole.DOCTOR,
        profileImage: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80",
        specialization: "Neurology",
        status: schema.DoctorStatus.ON_LEAVE,
        availableDays: ["monday", "wednesday", "friday"],
        nextAvailability: new Date("2023-05-28T09:00:00"),
      },
      {
        username: "doctor_sarah",
        email: "sarah.johnson@medicare.com",
        password: "password123",
        firstName: "Sarah",
        lastName: "Johnson",
        role: schema.UserRole.DOCTOR,
        profileImage: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80",
        specialization: "Pediatrics",
        status: schema.DoctorStatus.AVAILABLE,
        availableDays: ["monday", "tuesday", "wednesday", "thursday", "friday"],
        nextAvailability: new Date("2023-05-24T16:30:00"),
      },
      {
        username: "doctor_james",
        email: "james.rodriguez@medicare.com",
        password: "password123",
        firstName: "James",
        lastName: "Rodriguez",
        role: schema.UserRole.DOCTOR,
        profileImage: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80",
        specialization: "Orthopedics",
        status: schema.DoctorStatus.UNAVAILABLE,
        availableDays: ["tuesday", "thursday", "saturday"],
        nextAvailability: new Date("2023-05-25T10:00:00"),
      },
    ];

    // Insert doctors
    for (const doctor of doctorData) {
      // Check if doctor already exists
      const existingUser = await db.query.users.findFirst({
        where: eq(schema.users.email, doctor.email),
      });

      if (!existingUser) {
        console.log(`Creating doctor: ${doctor.firstName} ${doctor.lastName}`);
        const hashedPassword = await bcrypt.hash(doctor.password, 10);
        
        // Create user
        const [user] = await db.insert(schema.users).values({
          username: doctor.username,
          email: doctor.email,
          password: hashedPassword,
          firstName: doctor.firstName,
          lastName: doctor.lastName,
          role: doctor.role,
          status: schema.UserStatus.ACTIVE,
          profileImage: doctor.profileImage,
        }).returning();
        
        // Create doctor profile
        await db.insert(schema.doctors).values({
          userId: user.id,
          specialization: doctor.specialization,
          status: doctor.status,
          availableDays: doctor.availableDays,
          nextAvailability: doctor.nextAvailability,
        });
        
        console.log(`Doctor ${doctor.firstName} ${doctor.lastName} created successfully.`);
      } else {
        console.log(`Doctor ${doctor.firstName} ${doctor.lastName} already exists.`);
      }
    }

    // Seed activity logs
    const activityData = [
      {
        action: "doctor_added",
        details: "<span class='font-medium'>Dr. Emily Wilson</span> was added to the system",
        entityType: "doctor",
        timestamp: new Date("2023-05-24T10:23:00"),
      },
      {
        action: "appointments_scheduled",
        details: "<span class='font-medium'>12 new appointments</span> were scheduled",
        entityType: "appointment",
        timestamp: new Date("2023-05-24T09:45:00"),
      },
      {
        action: "doctor_leave_requested",
        details: "<span class='font-medium'>Dr. Michael Chen</span> requested leave",
        entityType: "doctor",
        timestamp: new Date("2023-05-23T17:30:00"),
      },
      {
        action: "patients_assigned",
        details: "<span class='font-medium'>8 patients</span> were assigned to Dr. James Rodriguez",
        entityType: "patient",
        timestamp: new Date("2023-05-23T15:15:00"),
      },
    ];

    // Create activity logs
    const existingLogs = await db.query.activityLogs.findMany();
    
    if (existingLogs.length === 0) {
      console.log("Creating activity logs...");
      for (const activity of activityData) {
        await db.insert(schema.activityLogs).values({
          action: activity.action,
          details: activity.details,
          entityType: activity.entityType,
          timestamp: activity.timestamp,
        });
      }
      console.log("Activity logs created successfully.");
    } else {
      console.log("Activity logs already exist.");
    }

    console.log("Seeding completed successfully.");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
