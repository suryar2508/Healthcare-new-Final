import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AppLayout from "@/components/layout/AppLayout";
import LoginPage from "@/pages/LoginPage";

// Admin Pages
import DashboardPage from "@/pages/admin/DashboardPage";
import DoctorsPage from "@/pages/admin/DoctorsPage";
import PharmacistsPage from "@/pages/admin/PharmacistsPage";
import PatientsPage from "@/pages/admin/PatientsPage";
import AppointmentsPage from "@/pages/admin/AppointmentsPage";
import InventoryPage from "@/pages/admin/InventoryPage";
import AnalyticsPage from "@/pages/admin/AnalyticsPage";
import SettingsPage from "@/pages/admin/SettingsPage";

// Doctor Pages
import DoctorDashboardPage from "@/pages/doctor/DoctorDashboardPage";

// Patient Pages
import PatientDashboardPage from "@/pages/patient/PatientDashboardPage";

// Pharmacist Pages
import PharmacistDashboardPage from "@/pages/pharmacist/PharmacistDashboardPage";

// Role-based layout component
function RoleBasedLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  
  // If on login page, don't show app layout
  if (location === "/" || location === "/login") {
    return <>{children}</>;
  }
  
  // Otherwise, wrap with AppLayout for admin routes
  if (location.startsWith("/admin")) {
    return <AppLayout>{children}</AppLayout>;
  }
  
  // For other role pages (doctor, patient, pharmacist), render directly
  return <>{children}</>;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={LoginPage} />
      <Route path="/login" component={LoginPage} />
      
      {/* Admin Routes */}
      <Route path="/admin/dashboard" component={DashboardPage} />
      <Route path="/admin/doctors" component={DoctorsPage} />
      <Route path="/admin/pharmacists" component={PharmacistsPage} />
      <Route path="/admin/patients" component={PatientsPage} />
      <Route path="/admin/appointments" component={AppointmentsPage} />
      <Route path="/admin/inventory" component={InventoryPage} />
      <Route path="/admin/analytics" component={AnalyticsPage} />
      <Route path="/admin/settings" component={SettingsPage} />
      
      {/* Doctor Routes */}
      <Route path="/doctor/dashboard" component={DoctorDashboardPage} />
      
      {/* Patient Routes */}
      <Route path="/patient/dashboard" component={PatientDashboardPage} />
      
      {/* Pharmacist Routes */}
      <Route path="/pharmacist/dashboard" component={PharmacistDashboardPage} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <RoleBasedLayout>
        <Router />
      </RoleBasedLayout>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
