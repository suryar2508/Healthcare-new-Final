import { useState } from "react";
import { 
  BarChart3, 
  Calendar, 
  Clock, 
  Users, 
  ArrowDown,
  ArrowUp,
  Minus,
  Stethoscope,
  UserCheck,
  FilePlus,
  AlertTriangle,
  LogOut,
  User,
  Settings,
  FileText,
  Search,
  PlusCircle,
  Check
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useLocation } from "wouter";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";

// Sample appointments data
const appointmentsData = [
  { id: 1, time: "09:00 AM", patient: "Michael Brown", status: "upcoming", issue: "Regular checkup", age: 42, gender: "Male" },
  { id: 2, time: "10:15 AM", patient: "Emma Wilson", status: "upcoming", issue: "Fever and cough", age: 35, gender: "Female" },
  { id: 3, time: "11:30 AM", patient: "David Clark", status: "completed", issue: "Hypertension follow-up", age: 58, gender: "Male" },
  { id: 4, time: "01:00 PM", patient: "Sophia Martinez", status: "upcoming", issue: "Diabetes management", age: 49, gender: "Female" },
  { id: 5, time: "02:30 PM", patient: "James Johnson", status: "upcoming", issue: "Back pain", age: 45, gender: "Male" },
  { id: 6, time: "03:45 PM", patient: "Emily Davis", status: "upcoming", issue: "Post-surgery follow-up", age: 37, gender: "Female" },
];

// Sample patient data
const patientData = {
  name: "Michael Brown",
  age: 42,
  gender: "Male",
  bloodType: "O+",
  contact: "+1 (555) 123-4567",
  email: "michael.brown@example.com",
  address: "123 Main St, New York, NY 10001",
  allergies: ["Penicillin", "Sulfa drugs"],
  chronicConditions: ["Hypertension", "Type 2 Diabetes"],
  currentMedications: [
    { name: "Lisinopril", dosage: "10mg", frequency: "Once daily" },
    { name: "Metformin", dosage: "500mg", frequency: "Twice daily" }
  ],
  vitalSigns: {
    bloodPressure: "138/85",
    heartRate: 78,
    temperature: 98.6,
    respiratoryRate: 14,
    oxygenSaturation: 98,
    height: "5'10\"",
    weight: "185 lbs"
  },
  recentVisits: [
    { date: "2023-10-15", reason: "Regular checkup", diagnosis: "Controlled hypertension", treatment: "Continued current medication" },
    { date: "2023-07-22", reason: "Flu symptoms", diagnosis: "Seasonal influenza", treatment: "Prescribed Tamiflu and rest" }
  ]
};

// Machine Learning model for drug recommendation
// Enhanced prescription form schema
const prescriptionFormSchema = z.object({
  diagnosis: z.string().min(3, { message: "Diagnosis is required" }),
  symptoms: z.string().min(3, { message: "Symptoms are required" }),
  notes: z.string().optional(),
  useAI: z.boolean().default(true),
  medications: z.array(z.object({
    name: z.string().min(1, { message: "Medication name is required" }),
    dosage: z.string().min(1, { message: "Dosage is required" }),
    frequency: z.string().min(1, { message: "Frequency is required" }),
    duration: z.string().min(1, { message: "Duration is required" }),
    quantity: z.number().min(1, { message: "Quantity must be at least 1" }),
    instructions: z.string().optional()
  })),
  vitals: z.object({
    bloodPressure: z.string().optional(),
    heartRate: z.string().optional(),
    temperature: z.string().optional(),
    oxygenLevel: z.string().optional()
  }),
  followUpDate: z.date().optional(),
  billDetails: z.object({
    consultationFee: z.number().min(0),
    medicationCosts: z.number().min(0),
    otherCharges: z.number().min(0),
    discount: z.number().min(0),
  })
});

// ML model for drug interactions (simulated)
const checkDrugInteractions = (drugs: string[]): {hasInteraction: boolean, interactions: string[], severity: ('high' | 'moderate' | 'low')[]} => {
  // Enhanced drug interaction database
  const knownInteractions: Record<string, Array<{drug: string, severity: 'high' | 'moderate' | 'low', effect: string}>> = {
    "Lisinopril": [
      {drug: "Potassium supplements", severity: "high", effect: "Risk of hyperkalemia"},
      {drug: "Spironolactone", severity: "high", effect: "Dangerous potassium elevation"}
    ],
    "Metformin": [
      {drug: "Iodinated contrast media", severity: "high", effect: "Risk of lactic acidosis"},
      {drug: "Alcohol", severity: "moderate", effect: "Enhanced hypoglycemic effect"}
    ],
    "Aspirin": [
      {drug: "Warfarin", severity: "high", effect: "Increased bleeding risk"},
      {drug: "Clopidogrel", severity: "moderate", effect: "Enhanced antiplatelet effect"},
      {drug: "Ibuprofen", severity: "moderate", effect: "Reduced cardioprotective effect"}
    ],
    "Amoxicillin": [
      {drug: "Allopurinol", severity: "moderate", effect: "Increased risk of rash"},
      {drug: "Probenecid", severity: "low", effect: "Increased amoxicillin levels"}
    ],
    "Ibuprofen": [
      {drug: "Aspirin", severity: "moderate", effect: "Reduced cardioprotective effect"},
      {drug: "Warfarin", severity: "high", effect: "Increased bleeding risk"},
      {drug: "Lithium", severity: "moderate", effect: "Increased lithium levels"}
    ]
  };

  const interactions: string[] = [];

  drugs.forEach(drug => {
    if (knownInteractions[drug]) {
      knownInteractions[drug].forEach(interactingDrug => {
        if (drugs.includes(interactingDrug)) {
          interactions.push(`${drug} and ${interactingDrug}`);
        }
      });
    }
  });

  return {
    hasInteraction: interactions.length > 0,
    interactions
  };
};

// ML model for drug recommendations based on diagnosis (simulated)
const getRecommendedDrugs = (diagnosis: string, symptoms: string): string[] => {
  // In a real application, this would be a sophisticated ML model
  const diagnosisLower = diagnosis.toLowerCase();
  const symptomsLower = symptoms.toLowerCase();

  if (diagnosisLower.includes("hypertension")) {
    return ["Lisinopril", "Amlodipine", "Losartan", "Hydrochlorothiazide"];
  } else if (diagnosisLower.includes("diabetes")) {
    return ["Metformin", "Glipizide", "Januvia", "Insulin"];
  } else if (diagnosisLower.includes("infection") || symptomsLower.includes("fever")) {
    return ["Amoxicillin", "Azithromycin", "Cephalexin", "Ciprofloxacin"];
  } else if (symptomsLower.includes("pain") || diagnosisLower.includes("pain")) {
    return ["Acetaminophen", "Ibuprofen", "Naproxen", "Tramadol"];
  } else if (symptomsLower.includes("cough") || symptomsLower.includes("cold")) {
    return ["Dextromethorphan", "Guaifenesin", "Pseudoephedrine", "Cetirizine"];
  } else {
    return ["No specific recommendation available. Please use clinical judgment."];
  }
};

export default function DoctorDashboardPage() {
  const [, navigate] = useLocation();
  const [currentTab, setCurrentTab] = useState("appointments");
  const [selectedPatient, setSelectedPatient] = useState<any>(null);
  const [showPrescriptionDialog, setShowPrescriptionDialog] = useState(false);
  const { toast } = useToast();

  // Create prescription form
  const prescriptionForm = useForm<z.infer<typeof prescriptionFormSchema>>({
    resolver: zodResolver(prescriptionFormSchema),
    defaultValues: {
      diagnosis: "",
      symptoms: "",
      notes: "",
      useAI: true,
      medications: [],
      vitals: {
        bloodPressure: "",
        heartRate: "",
        temperature: "",
        oxygenLevel: ""
      },
      followUpDate: undefined,
      billDetails: {
        consultationFee: 0,
        medicationCosts: 0,
        otherCharges: 0,
        discount: 0,
      }
    }
  });

  // ML-based recommendations
  const [recommendations, setRecommendations] = useState<string[]>([]);
  const [selectedDrugs, setSelectedDrugs] = useState<string[]>([]);
  const [interactions, setInteractions] = useState<{hasInteraction: boolean, interactions: string[]}>({
    hasInteraction: false,
    interactions: []
  });

  // Handle ML recommendations
  const onGenerateRecommendations = (values: z.infer<typeof prescriptionFormSchema>) => {
    if (values.useAI) {
      const recommendedDrugs = getRecommendedDrugs(values.diagnosis, values.symptoms);
      setRecommendations(recommendedDrugs);
      toast({
        title: "AI Recommendations Generated",
        description: "Treatment options have been suggested based on the diagnosis and symptoms."
      });
    } else {
      setRecommendations([]);
    }
  };

  // Handle drug selection
  const handleDrugSelection = (drug: string) => {
    const newSelectedDrugs = [...selectedDrugs];

    if (newSelectedDrugs.includes(drug)) {
      // Remove if already selected
      const index = newSelectedDrugs.indexOf(drug);
      newSelectedDrugs.splice(index, 1);
    } else {
      // Add if not selected
      newSelectedDrugs.push(drug);
    }

    setSelectedDrugs(newSelectedDrugs);

    // Check for interactions
    if (newSelectedDrugs.length > 1) {
      const interactionCheck = checkDrugInteractions(newSelectedDrugs);
      setInteractions(interactionCheck);

      if (interactionCheck.hasInteraction) {
        toast({
          title: "Potential Drug Interaction Detected",
          description: `Warning: ${interactionCheck.interactions.join(', ')} may interact.`,
          variant: "destructive"
        });
      }
    } else {
      setInteractions({
        hasInteraction: false,
        interactions: []
      });
    }
  };

  // Submit prescription
  const onSubmitPrescription = (values: z.infer<typeof prescriptionFormSchema>) => {
    if (values.medications.length === 0) {
      toast({
        title: "No medications selected",
        description: "Please select at least one medication for the prescription.",
        variant: "destructive"
      });
      return;
    }

    // Calculate total bill
    const totalBill = values.billDetails.consultationFee + values.billDetails.medicationCosts + values.billDetails.otherCharges - values.billDetails.discount;

    // In a real app, this would save to the database and generate a bill
    toast({
      title: "Prescription Created",
      description: `Prescription saved. Total bill: $${totalBill.toFixed(2)}`
    });

    setShowPrescriptionDialog(false);
    prescriptionForm.reset();
    setRecommendations([]);
    setSelectedDrugs([]);
    setInteractions({
      hasInteraction: false,
      interactions: []
    });
  };

  // Handle logout
  const handleLogout = () => {
    // Clear user session
    localStorage.removeItem("userRole");
    navigate("/");
  };

  // View patient details
  const viewPatientDetails = (appointment: any) => {
    setSelectedPatient(patientData);
    setCurrentTab("patient");
  };

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-900 flex flex-col">
      {/* Header */}
      <header className="bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 py-4 px-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
              <AlertTriangle className="h-5 w-5 text-white" />
            </div>
            <h1 className="text-xl font-bold ml-3">MediCare+ <span className="text-primary">Doctor</span></h1>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={() => navigate("/doctor/settings")}>
              <Settings className="h-5 w-5" />
            </Button>
            <div className="flex items-center">
              <Avatar>
                <AvatarImage src="https://randomuser.me/api/portraits/men/32.jpg" />
                <AvatarFallback>DC</AvatarFallback>
              </Avatar>
              <div className="ml-3 hidden md:block">
                <p className="text-sm font-medium">Dr. James Wilson</p>
                <p className="text-xs text-neutral-500">Cardiologist</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className="w-20 md:w-64 bg-white dark:bg-neutral-800 border-r border-neutral-200 dark:border-neutral-700 p-4 hidden md:block">
          <nav className="space-y-2">
            <Button 
              variant={currentTab === "appointments" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("appointments")}
            >
              <Calendar className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Appointments</span>
            </Button>
            <Button 
              variant={currentTab === "patient" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("patient")}
              disabled={!selectedPatient}
            >
              <User className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Patient Details</span>
            </Button>
            <Button 
              variant={currentTab === "prescriptions" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("prescriptions")}
            >
              <FileText className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Prescriptions</span>
            </Button>
            <Separator className="my-4" />
            <Button 
              variant="ghost" 
              className="w-full justify-start text-neutral-500"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Logout</span>
            </Button>
          </nav>
        </aside>

        {/* Content Area */}
        <main className="flex-1 p-6 overflow-auto">
          <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full">
            {/* Appointments Tab */}
            <TabsContent value="appointments" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">Today's Appointments</h2>
                <div className="flex items-center space-x-2">
                  <Select defaultValue="today">
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Filter appointments" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="tomorrow">Tomorrow</SelectItem>
                      <SelectItem value="week">This Week</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button>
                    <Calendar className="h-4 w-4 mr-2" />
                    Calendar View
                  </Button>
                </div>
              </div>

              {/* Appointments List */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {appointmentsData.map(appointment => (
                  <Card key={appointment.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <Badge
                          className={appointment.status === "upcoming" 
                            ? "bg-blue-100 text-blue-800" 
                            : appointment.status === "completed"
                            ? "bg-green-100 text-green-800"
                            : "bg-neutral-100 text-neutral-800"}
                        >
                          {appointment.status}
                        </Badge>
                        <p className="text-sm font-medium">{appointment.time}</p>
                      </div>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="flex items-start">
                        <Avatar className="h-10 w-10 mr-3">
                          <AvatarFallback>{appointment.patient.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-medium">{appointment.patient}</h3>
                          <p className="text-sm text-neutral-500">
                            {appointment.age} yrs, {appointment.gender}
                          </p>
                          <p className="text-sm mt-1">{appointment.issue}</p>
                        </div>
                      </div>
                      <div className="mt-4 flex space-x-2">
                        <Button 
                          size="sm" 
                          className="flex-1"
                          onClick={() => viewPatientDetails(appointment)}
                        >
                          View Details
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="flex-1"
                          onClick={() => {
                            setSelectedPatient(patientData);
                            setShowPrescriptionDialog(true);
                          }}
                        >
                          Prescribe
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Patient Details Tab */}
            <TabsContent value="patient" className="space-y-6">
              {selectedPatient ? (
                <>
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                    <div className="flex items-center">
                      <Avatar className="h-16 w-16 mr-4">
                        <AvatarFallback>{selectedPatient.name.split(' ').map((n: string) => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h2 className="text-2xl font-bold">{selectedPatient.name}</h2>
                        <p className="text-neutral-500">
                          {selectedPatient.age} years • {selectedPatient.gender} • {selectedPatient.bloodType}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 mt-4 sm:mt-0">
                      <Button onClick={() => setShowPrescriptionDialog(true)}>
                        <FilePlus className="h-4 w-4 mr-2" />
                        New Prescription
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Patient Info */}
                    <Card className="lg:col-span-1">
                      <CardHeader>
                        <CardTitle>Patient Information</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <p className="text-sm font-medium text-neutral-500">Contact</p>
                          <p>{selectedPatient.contact}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-neutral-500">Email</p>
                          <p>{selectedPatient.email}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-neutral-500">Address</p>
                          <p>{selectedPatient.address}</p>
                        </div>
                        <Separator />
                        <div>
                          <p className="text-sm font-medium text-neutral-500">Allergies</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {selectedPatient.allergies.map((allergy: string) => (
                              <Badge key={allergy} variant="outline" className="bg-red-50 text-red-700 border-red-200">
                                {allergy}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-neutral-500">Chronic Conditions</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {selectedPatient.chronicConditions.map((condition: string) => (
                              <Badge key={condition} variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                                {condition}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Vital Signs */}
                    <Card className="lg:col-span-1">
                      <CardHeader>
                        <CardTitle>Current Vital Signs</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Blood Pressure</p>
                            <p className="text-lg font-medium">{selectedPatient.vitalSigns.bloodPressure}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Heart Rate</p>
                            <p className="text-lg font-medium">{selectedPatient.vitalSigns.heartRate} bpm</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Temperature</p>
                            <p className="text-lg font-medium">{selectedPatient.vitalSigns.temperature}°F</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Respiratory Rate</p>
                            <p className="text-lg font-medium">{selectedPatient.vitalSigns.respiratoryRate} breaths/min</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Oxygen Saturation</p>
                            <p className="text-lg font-medium">{selectedPatient.vitalSigns.oxygenSaturation}%</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Height / Weight</p>
                            <p className="text-lg font-medium">{selectedPatient.vitalSigns.height} / {selectedPatient.vitalSigns.weight}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Current Medications */}
                    <Card className="lg:col-span-1">
                      <CardHeader>
                        <CardTitle>Current Medications</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {selectedPatient.currentMedications.map((med: any, i: number) => (
                            <div key={i} className="p-3 border border-neutral-200 dark:border-neutral-700 rounded-md">
                              <p className="font-medium">{med.name}</p>
                              <p className="text-sm text-neutral-500">{med.dosage} • {med.frequency}</p>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Medical History */}
                    <Card className="lg:col-span-3">
                      <CardHeader>
                        <CardTitle>Visit History</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {selectedPatient.recentVisits.map((visit: any, i: number) => (
                            <div key={i} className="p-4 border border-neutral-200 dark:border-neutral-700 rounded-md">
                              <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-2">
                                <p className="font-medium">{new Date(visit.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                                <Badge variant="outline" className="max-w-fit mt-1 md:mt-0">{visit.reason}</Badge>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-3">
                                <div>
                                  <p className="text-sm font-medium text-neutral-500">Diagnosis</p>
                                  <p>{visit.diagnosis}</p>
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-neutral-500">Treatment</p>
                                  <p>{visit.treatment}</p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </>
              ) : (
                <div className="text-center py-12">
                  <User className="h-12 w-12 mx-auto text-neutral-300 mb-4" />
                  <h3 className="text-xl font-medium">No Patient Selected</h3>
                  <p className="text-neutral-500 mt-1">Select a patient from your appointments to view their details</p>
                </div>
              )}
            </TabsContent>

            {/* Prescriptions Tab */}
            <TabsContent value="prescriptions" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">Prescriptions</h2>
                <div className="flex items-center space-x-2">
                  <Input 
                    placeholder="Search prescriptions..." 
                    className="w-[200px]"
                  />
                  <Button onClick={() => {
                    if (selectedPatient) {
                      setShowPrescriptionDialog(true);
                    } else {
                      toast({
                        title: "No patient selected",
                        description: "Please select a patient first from the appointments",
                        variant: "destructive"
                      });
                    }
                  }}>
                    <FilePlus className="h-4 w-4 mr-2" />
                    New Prescription
                  </Button>
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Prescriptions</CardTitle>
                  <CardDescription>Prescriptions you've written in the last 30 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <FileText className="h-12 w-12 mx-auto text-neutral-300 mb-4" />
                    <h3 className="text-xl font-medium">No Recent Prescriptions</h3>
                    <p className="text-neutral-500 mt-1">Prescriptions you write will appear here</p>
                    <Button className="mt-4" onClick={() => {
                      if (selectedPatient) {
                        setShowPrescriptionDialog(true);
                      } else {
                        toast({
                          title: "No patient selected",
                          description: "Please select a patient first from the appointments",
                          variant: "destructive"
                        });
                      }
                    }}>
                      <FilePlus className="h-4 w-4 mr-2" />
                      Create New Prescription
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>

      {/* AI-Powered Prescription Dialog */}
      <Dialog open={showPrescriptionDialog} onOpenChange={setShowPrescriptionDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Create Prescription for {selectedPatient?.name}</DialogTitle>
            <DialogDescription>
              Enter diagnosis and symptoms to get AI-recommended treatments
            </DialogDescription>
          </DialogHeader>

          <Form {...prescriptionForm}>
            <form onSubmit={prescriptionForm.handleSubmit(onSubmitPrescription)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={prescriptionForm.control}
                  name="diagnosis"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Diagnosis</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter diagnosis" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={prescriptionForm.control}
                  name="symptoms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Symptoms</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter symptoms" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={prescriptionForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter additional notes" 
                        className="h-24"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={prescriptionForm.control}
                name="useAI"
                render={({ field }) => (
                  <FormItem className="flex items-center space-x-2">
                    <FormControl>
                      <input
                        type="checkbox"
                        checked={field.value}
                        onChange={field.onChange}
                        className="accent-primary h-4 w-4"
                      />
                    </FormControl>
                    <FormLabel className="!mt-0">Use AI recommendations</FormLabel>
                    <FormDescription>Get medication suggestions based on diagnosis and symptoms</FormDescription>
                  </FormItem>
                )}
              />

              <FormField
                control={prescriptionForm.control}
                name="medications"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Medications</FormLabel>
                    <FormControl>
                      <div className="space-y-4">
                        {field.value.map((med, index) => (
                          <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Input type="text" placeholder="Medication Name" {...field.value[index].name} />
                            <Input type="text" placeholder="Dosage" {...field.value[index].dosage} />
                            <Input type="text" placeholder="Frequency" {...field.value[index].frequency} />
                            <Input type="text" placeholder="Duration" {...field.value[index].duration} />
                            <Input type="number" placeholder="Quantity" {...field.value[index].quantity} />
                            <Textarea placeholder="Instructions" {...field.value[index].instructions} />
                          </div>                        ))}
                        <Button onClick={() => field.onChange([...field.value, { name: "", dosage: "", frequency: "", duration: "", quantity: 1, instructions: "" }])}>Add Medication</Button>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={prescriptionForm.control}
                name="vitals"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vital Signs</FormLabel>
                    <FormControl>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Input placeholder="Blood Pressure" {...field.value.bloodPressure} />
                        <Input placeholder="Heart Rate" {...field.value.heartRate} />
                        <Input placeholder="Temperature" {...field.value.temperature} />
                        <Input placeholder="Oxygen Level" {...field.value.oxygenLevel} />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={prescriptionForm.control}
                name="followUpDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Follow Up Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={prescriptionForm.control}
                name="billDetails"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Billing Details</FormLabel>
                    <FormControl>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Input type="number" placeholder="Consultation Fee" {...field.value.consultationFee} />
                        <Input type="number" placeholder="Medication Costs" {...field.value.medicationCosts} />
                        <Input type="number" placeholder="Other Charges" {...field.value.otherCharges} />
                        <Input type="number" placeholder="Discount" {...field.value.discount} />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />


              <div className="flex justify-end">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    const values = prescriptionForm.getValues();
                    onGenerateRecommendations(values);
                  }}
                  disabled={!prescriptionForm.getValues().useAI}
                >
                  Generate Recommendations
                </Button>
              </div>

              {/* AI Recommendations */}
              {recommendations.length > 0 && (
                <div className="border border-neutral-200 dark:border-neutral-700 rounded-md p-4">
                  <h3 className="font-medium mb-2">AI Recommended Medications</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {recommendations.map((drug, index) => (
                      <div 
                        key={index}
                        className={`p-2 border ${selectedDrugs.includes(drug) ? 'border-primary bg-primary-50 dark:bg-primary-900/20' : 'border-neutral-200 dark:border-neutral-700'} rounded-md cursor-pointer flex items-center justify-between`}
                        onClick={() => handleDrugSelection(drug)}
                      >
                        <span>{drug}</span>
                        {selectedDrugs.includes(drug) && <Check className="h-4 w-4 text-primary" />}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Drug interactions warning */}
              {interactions.hasInteraction && (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 p-4 rounded-md">
                  <div className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-red-800 dark:text-red-300">Potential Drug Interactions Detected</h4>
                      <ul className="list-disc pl-5 mt-1 text-sm text-red-700 dark:text-red-300">
                        {interactions.interactions.map((interaction, i) => (
                          <li key={i}>{interaction} may interact</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {/* Selected Medications Summary */}
              {selectedDrugs.length > 0 && (
                <div className="border border-neutral-200 dark:border-neutral-700 rounded-md p-4">
                  <h3 className="font-medium mb-2">Selected Medications</h3>
                  <ul className="list-disc pl-5">
                    {selectedDrugs.map((drug, index) => (
                      <li key={index}>{drug}</li>
                    ))}
                  </ul>
                </div>
              )}

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowPrescriptionDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  Save Prescription
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}