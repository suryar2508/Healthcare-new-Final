import { useQuery } from "@tanstack/react-query";
import { 
  BarChart3, 
  Calendar, 
  Clock, 
  Users, 
  ArrowDown,
  ArrowUp,
  Minus,
  Stethoscope,
  UserCheck,
  Pill,
  ShieldAlert,
  Package
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useMobile } from "@/hooks/use-mobile";
import { Link } from "wouter";

// Sample activity data
const activities = [
  { id: 1, type: "appointment", message: "New appointment with <strong>John Doe</strong>", time: "5 mins ago" },
  { id: 2, type: "patient", message: "Patient <strong>Sarah Johnson</strong> checked in", time: "15 mins ago" },
  { id: 3, type: "medicine", message: "<strong>Amoxicillin</strong> stock is running low", time: "1 hour ago" },
  { id: 4, type: "doctor", message: "Dr. <strong>Emily White</strong> is now on leave", time: "3 hours ago" },
  { id: 5, type: "alert", message: "System update scheduled for <strong>tonight</strong>", time: "5 hours ago" },
];

// Sample upcoming appointments
const upcomingAppointments = [
  { id: 1, patient: "Michael Brown", doctor: "Dr. James Rodriguez", time: "09:30 AM", date: "Today", status: "confirmed" },
  { id: 2, patient: "Emily Davis", doctor: "Dr. Emma Wilson", time: "10:15 AM", date: "Today", status: "confirmed" },
  { id: 3, patient: "David Wilson", doctor: "Dr. Maria Garcia", time: "11:00 AM", date: "Today", status: "confirmed" },
  { id: 4, patient: "Sarah Johnson", doctor: "Dr. James Rodriguez", time: "02:30 PM", date: "Today", status: "pending" },
  { id: 5, patient: "Robert Taylor", doctor: "Dr. Maria Garcia", time: "09:00 AM", date: "Tomorrow", status: "confirmed" },
];

// Chart colors
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export default function DashboardPage() {
  const isMobile = useMobile();

  // Doctor stats query
  const { data: doctorStats, isLoading: isLoadingDoctorStats } = useQuery({
    queryKey: ['/api/doctors/stats'],
  });

  // Activities query
  const { data: activityData, isLoading: isLoadingActivities } = useQuery({
    queryKey: ['/api/activities'],
  });

  // Format activities from API
  const formattedActivities = Array.isArray(activityData) ? activityData.slice(0, 5) : [];

  // Sample chart data
  const appointmentsPieData = [
    { name: 'Cardiology', value: 35 },
    { name: 'Neurology', value: 20 },
    { name: 'Pediatrics', value: 25 },
    { name: 'Orthopedics', value: 15 },
    { name: 'Dermatology', value: 10 },
  ];

  const patientGrowthData = [
    { month: 'Jan', patients: 150 },
    { month: 'Feb', patients: 180 },
    { month: 'Mar', patients: 190 },
    { month: 'Apr', patients: 220 },
    { month: 'May', patients: 250 },
    { month: 'Jun', patients: 280 },
  ];
  
  // Function to get activity icon
  const getActivityIcon = (type: string) => {
    switch(type) {
      case 'appointment':
        return <Calendar className="h-8 w-8 text-blue-500 bg-blue-100 p-1.5 rounded-full" />;
      case 'patient':
        return <Users className="h-8 w-8 text-green-500 bg-green-100 p-1.5 rounded-full" />;
      case 'medicine':
        return <Pill className="h-8 w-8 text-amber-500 bg-amber-100 p-1.5 rounded-full" />;
      case 'doctor':
        return <Stethoscope className="h-8 w-8 text-purple-500 bg-purple-100 p-1.5 rounded-full" />;
      case 'alert':
        return <ShieldAlert className="h-8 w-8 text-red-500 bg-red-100 p-1.5 rounded-full" />;
      default:
        return <Calendar className="h-8 w-8 text-blue-500 bg-blue-100 p-1.5 rounded-full" />;
    }
  };

  // Function to get status badge style
  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'confirmed':
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100";
      case 'pending':
        return "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100";
      case 'cancelled':
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100";
      default:
        return "bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-100";
    }
  };

  // Function to return trend icon based on percentage
  const getTrendIcon = (percentage: number) => {
    if (percentage > 0) {
      return <ArrowUp className="h-4 w-4 text-green-500" />;
    } else if (percentage < 0) {
      return <ArrowDown className="h-4 w-4 text-red-500" />;
    }
    return <Minus className="h-4 w-4 text-neutral-500" />;
  };

  return (
    <div className="p-6 pb-20 md:pb-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 sm:mb-0">Dashboard</h1>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Calendar className="h-4 w-4 mr-2" />
            {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
          </Button>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card className="shadow-sm bg-white dark:bg-card hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Total Doctors</CardTitle>
          </CardHeader>
          <CardContent className="pb-4">
            {isLoadingDoctorStats ? (
              <Skeleton className="h-9 w-24 mb-1" />
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold">{doctorStats && 'totalDoctors' in doctorStats ? doctorStats.totalDoctors : 0}</div>
                  <div className="p-2 bg-primary-100 rounded-full">
                    <Stethoscope className="h-5 w-5 text-primary" />
                  </div>
                </div>
                <div className="flex items-center text-xs text-neutral-500 mt-1">
                  {getTrendIcon(5.2)}
                  <span className="ml-1 text-green-500">5.2% more than last month</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
        
        <Card className="shadow-sm bg-white dark:bg-card hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Active Doctors</CardTitle>
          </CardHeader>
          <CardContent className="pb-4">
            {isLoadingDoctorStats ? (
              <Skeleton className="h-9 w-24 mb-1" />
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold">{doctorStats && 'activeDoctors' in doctorStats ? doctorStats.activeDoctors : 0}</div>
                  <div className="p-2 bg-green-100 rounded-full">
                    <UserCheck className="h-5 w-5 text-green-500" />
                  </div>
                </div>
                <div className="flex items-center text-xs text-neutral-500 mt-1">
                  {getTrendIcon(0)}
                  <span className="ml-1">No change from last week</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
        
        <Card className="shadow-sm bg-white dark:bg-card hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Today's Appointments</CardTitle>
          </CardHeader>
          <CardContent className="pb-4">
            {isLoadingDoctorStats ? (
              <Skeleton className="h-9 w-24 mb-1" />
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold">{doctorStats?.todayAppointments || 0}</div>
                  <div className="p-2 bg-blue-100 rounded-full">
                    <Calendar className="h-5 w-5 text-blue-500" />
                  </div>
                </div>
                <div className="flex items-center text-xs text-neutral-500 mt-1">
                  {getTrendIcon(12.5)}
                  <span className="ml-1 text-green-500">12.5% more than yesterday</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
        
        <Card className="shadow-sm bg-white dark:bg-card hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Doctors on Leave</CardTitle>
          </CardHeader>
          <CardContent className="pb-4">
            {isLoadingDoctorStats ? (
              <Skeleton className="h-9 w-24 mb-1" />
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold">{doctorStats?.onLeave || 0}</div>
                  <div className="p-2 bg-amber-100 rounded-full">
                    <Clock className="h-5 w-5 text-amber-500" />
                  </div>
                </div>
                <div className="flex items-center text-xs text-neutral-500 mt-1">
                  {getTrendIcon(-8.3)}
                  <span className="ml-1 text-red-500">8.3% more than last week</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Middle Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Appointments by department */}
        <Card className="shadow-sm lg:col-span-1">
          <CardHeader>
            <CardTitle>Appointments by Department</CardTitle>
            <CardDescription>Distribution across specialties</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={appointmentsPieData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {appointmentsPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        {/* Patient growth */}
        <Card className="shadow-sm lg:col-span-2">
          <CardHeader>
            <CardTitle>Patient Growth</CardTitle>
            <CardDescription>Monthly patient registrations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={patientGrowthData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="patients" 
                    stroke="#8884d8" 
                    activeDot={{ r: 8 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <Card className="shadow-sm">
          <CardHeader className="pb-3">
            <div className="flex justify-between items-center">
              <CardTitle>Recent Activity</CardTitle>
              <Link href="/admin/activities">
                <Button variant="ghost" size="sm" className="text-primary">
                  View All
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-5">
              {isLoadingActivities ? (
                Array(5).fill(0).map((_, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                  </div>
                ))
              ) : (
                formattedActivities.map((activity: any) => (
                  <div key={activity.id} className="flex items-start space-x-4">
                    {getActivityIcon(activity.type)}
                    <div>
                      <p
                        className="text-sm text-neutral-700 dark:text-neutral-300"
                        dangerouslySetInnerHTML={{ __html: activity.message }}
                      />
                      <p className="text-xs text-neutral-500">{activity.time}</p>
                    </div>
                  </div>
                ))
              )}
              
              {!isLoadingActivities && (!formattedActivities || formattedActivities.length === 0) && (
                <div className="text-center py-8">
                  <Calendar className="h-10 w-10 mx-auto text-neutral-300 mb-3" />
                  <p className="text-lg font-medium text-neutral-900 dark:text-neutral-100">No recent activities</p>
                  <p className="text-neutral-500 dark:text-neutral-400 mt-1">Activities will appear here as they happen</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Today's Schedule */}
        <Card className="shadow-sm">
          <CardHeader className="pb-3">
            <div className="flex justify-between items-center">
              <CardTitle>Today's Schedule</CardTitle>
              <Link href="/admin/appointments">
                <Button variant="ghost" size="sm" className="text-primary">
                  View Calendar
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {upcomingAppointments.length > 0 ? (
              <div className="space-y-4">
                {upcomingAppointments.slice(0, 5).map((appointment) => (
                  <div key={appointment.id} className="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800 pb-4 last:border-0 last:pb-0">
                    <div className="flex items-start space-x-3">
                      <div className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-md px-2 py-1 text-xs font-medium w-16 text-center">
                        {appointment.time}
                      </div>
                      <div>
                        <p className="font-medium">{appointment.patient}</p>
                        <p className="text-sm text-neutral-500">{appointment.doctor}</p>
                      </div>
                    </div>
                    <Badge className={getStatusBadge(appointment.status)}>
                      {appointment.status}
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="h-10 w-10 mx-auto text-neutral-300 mb-3" />
                <p className="text-lg font-medium text-neutral-900 dark:text-neutral-100">No appointments today</p>
                <p className="text-neutral-500 dark:text-neutral-400 mt-1">Enjoy your day off!</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}