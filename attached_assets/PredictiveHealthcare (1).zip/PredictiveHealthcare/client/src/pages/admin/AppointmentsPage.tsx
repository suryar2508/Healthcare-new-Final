import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Filter, 
  Download, 
  Calendar, 
  Plus, 
  List, 
  CalendarDays,
  Search,
  ArrowDownNarrowWide
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import StatsCard from "@/components/stats/StatsCard";
import AppointmentTable from "@/components/appointments/AppointmentTable";
import AppointmentCalendar from "@/components/appointments/AppointmentCalendar";
import AddAppointmentDialog from "@/components/appointments/AddAppointmentDialog";
import { useMobile } from "@/hooks/use-mobile";

export default function AppointmentsPage() {
  const [isAddAppointmentOpen, setIsAddAppointmentOpen] = useState(false);
  const [currentView, setCurrentView] = useState<"list" | "calendar">("list");
  const isMobile = useMobile();
  
  // Fetch appointments data
  const { data: appointments, isLoading: isLoadingAppointments } = useQuery({
    queryKey: ['/api/appointments'],
  });

  // Transform appointments data to match our component props
  const transformedAppointments = Array.isArray(appointments)
    ? appointments.map((appointment: any) => {
        // Parse the date
        const appointmentDate = new Date(appointment.date);
        
        return {
          id: appointment.id,
          patient: {
            id: appointment.patient.id,
            name: `${appointment.patient.user.firstName} ${appointment.patient.user.lastName}`,
            profileImage: appointment.patient.user.profileImage
          },
          doctor: {
            id: appointment.doctor.id,
            name: `Dr. ${appointment.doctor.user.firstName} ${appointment.doctor.user.lastName}`,
            specialization: appointment.doctor.specialization
          },
          date: appointmentDate.toLocaleDateString(),
          time: appointmentDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: appointment.status,
          reason: appointment.reason
        };
      })
    : [];

  // Calculate appointment statistics
  const appointmentStats = {
    totalAppointments: transformedAppointments.length,
    scheduled: transformedAppointments.filter((app: any) => app.status === "scheduled").length,
    completed: transformedAppointments.filter((app: any) => app.status === "completed").length,
    cancelled: transformedAppointments.filter((app: any) => app.status === "cancelled").length
  };

  return (
    <div className="p-6 pb-20 md:pb-6">
      {/* Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
        <div className="flex items-center">
          <div className="relative mr-4 md:hidden">
            <Input
              type="text"
              placeholder="Search appointments..."
              className="pl-10 pr-4 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm w-full"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-300" />
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" className="text-neutral-400">
              <Filter className="h-4 w-4 mr-1" />
              Filter
            </Button>
            <Button variant="outline" size="sm" className="text-neutral-400">
              <ArrowDownNarrowWide className="h-4 w-4 mr-1" />
              Sort
            </Button>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="text-neutral-400">
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
          <Button size="sm" onClick={() => setIsAddAppointmentOpen(true)}>
            <Calendar className="h-4 w-4 mr-1" />
            New Appointment
          </Button>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <StatsCard
          title="Total Appointments"
          value={appointmentStats.totalAppointments}
          trend="+12% this month"
          trendType="up"
          icon="calendar"
          color="primary"
          isLoading={isLoadingAppointments}
        />
        
        <StatsCard
          title="Scheduled"
          value={appointmentStats.scheduled}
          trend="Upcoming"
          trendType="neutral"
          icon="calendar-clock"
          color="secondary"
          isLoading={isLoadingAppointments}
        />
        
        <StatsCard
          title="Completed"
          value={appointmentStats.completed}
          trend="This month"
          trendType="up"
          icon="calendar-check"
          color="accent"
          isLoading={isLoadingAppointments}
        />
        
        <StatsCard
          title="Cancelled"
          value={appointmentStats.cancelled}
          trend="Lower than avg"
          trendType="down"
          icon="calendar-x"
          color="warning"
          isLoading={isLoadingAppointments}
        />
      </div>
      
      {/* Appointment View Tabs */}
      <Card className="shadow-card overflow-hidden mb-6">
        <div className="px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <h2 className="text-lg font-semibold text-neutral-500 dark:text-neutral-200">Appointments</h2>
          <Tabs 
            defaultValue="list" 
            value={currentView}
            onValueChange={(value) => setCurrentView(value as "list" | "calendar")}
            className="w-[300px]"
          >
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="list" className="flex items-center">
                <List className="h-4 w-4 mr-2" />
                List View
              </TabsTrigger>
              <TabsTrigger value="calendar" className="flex items-center">
                <CalendarDays className="h-4 w-4 mr-2" />
                Calendar
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        
        <div className="p-4">
          {currentView === "list" ? (
            <AppointmentTable appointments={transformedAppointments} isLoading={isLoadingAppointments} />
          ) : (
            <AppointmentCalendar appointments={transformedAppointments} isLoading={isLoadingAppointments} />
          )}
        </div>
      </Card>
      
      {/* Add Appointment Dialog */}
      <AddAppointmentDialog open={isAddAppointmentOpen} onOpenChange={setIsAddAppointmentOpen} />
    </div>
  );
}
