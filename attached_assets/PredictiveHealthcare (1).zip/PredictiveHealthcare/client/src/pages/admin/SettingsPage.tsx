import { useState } from "react";
import { 
  Check, 
  Settings, 
  User, 
  Bell, 
  Shield, 
  Server, 
  Palette,
  CloudOff,
  Save,
  Lock,
  Mail
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Switch,
  Switch as SwitchComponent
} from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useTheme } from "@/hooks/use-theme";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

export default function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  
  // General Settings
  const [systemName, setSystemName] = useState("MediCare+ Healthcare System");
  const [allowRegistration, setAllowRegistration] = useState(true);
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  
  // User Settings
  const [fullName, setFullName] = useState("Sarah Johnson");
  const [email, setEmail] = useState("sarah.johnson@example.com");
  const [role, setRole] = useState("administrator");
  
  // Notification Settings
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [appointmentReminders, setAppointmentReminders] = useState(true);
  const [systemAlerts, setSystemAlerts] = useState(true);
  const [inventoryAlerts, setInventoryAlerts] = useState(true);
  
  // Security Settings
  const [twoFactorAuth, setTwoFactorAuth] = useState(false);
  const [sessionTimeout, setSessionTimeout] = useState("30");
  const [passwordExpiry, setPasswordExpiry] = useState("90");
  
  // Theme Settings
  const [colorScheme, setColorScheme] = useState(theme);
  const [animation, setAnimation] = useState(true);
  const [compactMode, setCompactMode] = useState(false);

  // System Settings
  const [backupFrequency, setBackupFrequency] = useState("daily");
  const [logLevel, setLogLevel] = useState("info");
  const [apiEndpoint, setApiEndpoint] = useState("https://api.healthcare-system.example");
  
  // Handle save settings
  const handleSaveSettings = (section: string) => {
    toast({
      title: "Settings updated",
      description: `Your ${section} settings have been saved successfully.`,
      duration: 3000,
    });
  };

  return (
    <div className="p-6 pb-20 md:pb-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 sm:mb-0">Settings</h1>
      </div>
      
      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid grid-cols-3 md:grid-cols-6 w-full mb-6">
          <TabsTrigger value="general" className="flex items-center justify-center gap-2">
            <Settings className="h-4 w-4" />
            <span className="hidden md:inline">General</span>
          </TabsTrigger>
          <TabsTrigger value="user" className="flex items-center justify-center gap-2">
            <User className="h-4 w-4" />
            <span className="hidden md:inline">User Profile</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center justify-center gap-2">
            <Bell className="h-4 w-4" />
            <span className="hidden md:inline">Notifications</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center justify-center gap-2">
            <Shield className="h-4 w-4" />
            <span className="hidden md:inline">Security</span>
          </TabsTrigger>
          <TabsTrigger value="theme" className="flex items-center justify-center gap-2">
            <Palette className="h-4 w-4" />
            <span className="hidden md:inline">Theme</span>
          </TabsTrigger>
          <TabsTrigger value="system" className="flex items-center justify-center gap-2">
            <Server className="h-4 w-4" />
            <span className="hidden md:inline">System</span>
          </TabsTrigger>
        </TabsList>
        
        {/* General Settings */}
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>
                Configure basic system settings and preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="system-name">System Name</Label>
                <Input 
                  id="system-name" 
                  value={systemName} 
                  onChange={(e) => setSystemName(e.target.value)} 
                />
                <p className="text-sm text-neutral-500 dark:text-neutral-400">
                  This name will appear in system notifications and reports
                </p>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Allow User Registration</Label>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Enable new user registrations
                    </p>
                  </div>
                  <Switch 
                    checked={allowRegistration} 
                    onCheckedChange={setAllowRegistration} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Maintenance Mode</Label>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Put system in maintenance mode (only admins can access)
                    </p>
                  </div>
                  <Switch 
                    checked={maintenanceMode} 
                    onCheckedChange={setMaintenanceMode} 
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSaveSettings("general")}>
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* User Profile Settings */}
        <TabsContent value="user">
          <Card>
            <CardHeader>
              <CardTitle>User Profile</CardTitle>
              <CardDescription>
                Manage your personal information and preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center space-x-4">
                <div className="h-20 w-20 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-500 font-medium text-xl">
                  {fullName.split(" ").map(n => n[0]).join("")}
                </div>
                <Button variant="outline" size="sm">Change Avatar</Button>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="full-name">Full Name</Label>
                    <Input 
                      id="full-name" 
                      value={fullName} 
                      onChange={(e) => setFullName(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      value={email} 
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="role">Role</Label>
                  <Select value={role} onValueChange={setRole}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="administrator">Administrator</SelectItem>
                      <SelectItem value="doctor">Doctor</SelectItem>
                      <SelectItem value="nurse">Nurse</SelectItem>
                      <SelectItem value="receptionist">Receptionist</SelectItem>
                      <SelectItem value="pharmacist">Pharmacist</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label htmlFor="current-password">Current Password</Label>
                <Input id="current-password" type="password" />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="new-password">New Password</Label>
                  <Input id="new-password" type="password" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirm Password</Label>
                  <Input id="confirm-password" type="password" />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSaveSettings("user profile")}>
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Notification Settings */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Configure how and when you receive notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Email Notifications</Label>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Receive notifications via email
                    </p>
                  </div>
                  <Switch 
                    checked={emailNotifications} 
                    onCheckedChange={setEmailNotifications} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Appointment Reminders</Label>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Get notified about upcoming appointments
                    </p>
                  </div>
                  <Switch 
                    checked={appointmentReminders} 
                    onCheckedChange={setAppointmentReminders} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>System Alerts</Label>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Receive alerts about system updates and maintenance
                    </p>
                  </div>
                  <Switch 
                    checked={systemAlerts} 
                    onCheckedChange={setSystemAlerts} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Inventory Alerts</Label>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Get notified about low stock and expiring medications
                    </p>
                  </div>
                  <Switch 
                    checked={inventoryAlerts} 
                    onCheckedChange={setInventoryAlerts} 
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSaveSettings("notification")}>
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Security Settings */}
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>
                Manage security preferences and access controls
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Two-Factor Authentication</Label>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">
                    Require a verification code in addition to password
                  </p>
                </div>
                <Switch 
                  checked={twoFactorAuth} 
                  onCheckedChange={setTwoFactorAuth} 
                />
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="session-timeout">Session Timeout (minutes)</Label>
                  <Select value={sessionTimeout} onValueChange={setSessionTimeout}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select timeout period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                      <SelectItem value="120">2 hours</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">
                    Automatically log out after period of inactivity
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password-expiry">Password Expiry (days)</Label>
                  <Select value={passwordExpiry} onValueChange={setPasswordExpiry}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select expiry period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="60">60 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="180">180 days</SelectItem>
                      <SelectItem value="never">Never</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">
                    Force password change after specified period
                  </p>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start" type="button">
                  <Lock className="h-4 w-4 mr-2" />
                  View Active Sessions
                </Button>
                <Button variant="outline" className="w-full justify-start" type="button">
                  <CloudOff className="h-4 w-4 mr-2" />
                  Log Out From All Devices
                </Button>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSaveSettings("security")}>
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Theme Settings */}
        <TabsContent value="theme">
          <Card>
            <CardHeader>
              <CardTitle>Theme Settings</CardTitle>
              <CardDescription>
                Customize the appearance of the application
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Color Scheme</Label>
                <div className="grid grid-cols-3 gap-2">
                  <Button 
                    variant={colorScheme === "light" ? "default" : "outline"}
                    className={`justify-start px-4 py-2 h-auto ${colorScheme === "light" ? "" : "hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
                    onClick={() => {
                      setColorScheme("light");
                      setTheme("light");
                    }}
                  >
                    <div className="w-10 h-6 rounded bg-white border border-neutral-200 mr-2"></div>
                    Light
                  </Button>
                  <Button 
                    variant={colorScheme === "dark" ? "default" : "outline"}
                    className={`justify-start px-4 py-2 h-auto ${colorScheme === "dark" ? "" : "hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
                    onClick={() => {
                      setColorScheme("dark");
                      setTheme("dark");
                    }}
                  >
                    <div className="w-10 h-6 rounded bg-neutral-900 border border-neutral-700 mr-2"></div>
                    Dark
                  </Button>
                  <Button 
                    variant={colorScheme === "system" ? "default" : "outline"}
                    className={`justify-start px-4 py-2 h-auto ${colorScheme === "system" ? "" : "hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
                    onClick={() => {
                      setColorScheme("system");
                      setTheme("system");
                    }}
                  >
                    <div className="w-10 h-6 rounded bg-gradient-to-r from-white to-neutral-900 border border-neutral-200 mr-2"></div>
                    System
                  </Button>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Animation Effects</Label>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Enable animations for smoother transitions
                    </p>
                  </div>
                  <Switch 
                    checked={animation} 
                    onCheckedChange={setAnimation} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Compact Mode</Label>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Reduce spacing to fit more content on screen
                    </p>
                  </div>
                  <Switch 
                    checked={compactMode} 
                    onCheckedChange={setCompactMode} 
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSaveSettings("theme")}>
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* System Settings */}
        <TabsContent value="system">
          <Card>
            <CardHeader>
              <CardTitle>System Settings</CardTitle>
              <CardDescription>
                Configure system-wide technical settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="backup-frequency">Backup Frequency</Label>
                <Select value={backupFrequency} onValueChange={setBackupFrequency}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select backup frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-neutral-500 dark:text-neutral-400">
                  How often the system database is backed up
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="log-level">Log Level</Label>
                <Select value={logLevel} onValueChange={setLogLevel}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select log level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="error">Error</SelectItem>
                    <SelectItem value="warn">Warning</SelectItem>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="debug">Debug</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-neutral-500 dark:text-neutral-400">
                  Detail level of system logs
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="api-endpoint">API Endpoint</Label>
                <Input 
                  id="api-endpoint" 
                  value={apiEndpoint} 
                  onChange={(e) => setApiEndpoint(e.target.value)} 
                />
                <p className="text-sm text-neutral-500 dark:text-neutral-400">
                  Base URL for API connections
                </p>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start" type="button">
                  <Server className="h-4 w-4 mr-2" />
                  Clear Application Cache
                </Button>
                <Button variant="outline" className="w-full justify-start" type="button">
                  <Mail className="h-4 w-4 mr-2" />
                  Test Email Configuration
                </Button>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSaveSettings("system")}>
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}