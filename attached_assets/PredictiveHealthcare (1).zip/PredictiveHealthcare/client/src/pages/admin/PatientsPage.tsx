import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Filter, Download, Plus, Search, ArrowDownNarrowWide, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import StatsCard from "@/components/stats/StatsCard";
import PatientTable from "@/components/patients/PatientTable";
import AddPatientDialog from "@/components/patients/AddPatientDialog";
import ActivityItem from "@/components/activity/ActivityItem";
import { useMobile } from "@/hooks/use-mobile";

export default function PatientsPage() {
  const [isAddPatientOpen, setIsAddPatientOpen] = useState(false);
  const isMobile = useMobile();
  
  // Fetch patients data
  const { data: patients, isLoading: isLoadingPatients } = useQuery({
    queryKey: ['/api/patients'],
  });
  
  // Fetch activities
  const { data: activities, isLoading: isLoadingActivities } = useQuery({
    queryKey: ['/api/activities'],
  });

  // Transform patients data to match our component props
  const transformedPatients = Array.isArray(patients) 
    ? patients.map((patient: any) => ({
        id: patient.id,
        name: `${patient.user.firstName} ${patient.user.lastName}`,
        email: patient.user.email,
        phone: patient.user.phone,
        age: patient.dateOfBirth 
          ? new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear() 
          : undefined,
        bloodGroup: patient.bloodGroup,
        assignedDoctor: patient.assignedDoctor 
          ? { 
              id: patient.assignedDoctor.id,
              name: `Dr. ${patient.assignedDoctor.user.firstName} ${patient.assignedDoctor.user.lastName}`
            } 
          : undefined,
        lastVisit: "N/A", // This would come from appointments in a real implementation
        status: patient.user.status || "active"
      }))
    : [];

  // Calculate patient stats
  const patientStats = {
    totalPatients: Array.isArray(patients) ? patients.length : 0,
    activePatients: Array.isArray(patients) 
      ? patients.filter((p: any) => p.user.status === "active").length 
      : 0,
    newPatients: Math.floor(Math.random() * 20) + 5, // Just for demo
    pendingAppointments: Math.floor(Math.random() * 30) + 10 // Just for demo
  };

  return (
    <div className="p-6 pb-20 md:pb-6">
      {/* Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
        <div className="flex items-center">
          <div className="relative mr-4 md:hidden">
            <Input
              type="text"
              placeholder="Search patients..."
              className="pl-10 pr-4 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm w-full"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-300" />
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" className="text-neutral-400">
              <Filter className="h-4 w-4 mr-1" />
              Filter
            </Button>
            <Button variant="outline" size="sm" className="text-neutral-400">
              <ArrowDownNarrowWide className="h-4 w-4 mr-1" />
              Sort
            </Button>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="text-neutral-400">
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
          <Button size="sm" onClick={() => setIsAddPatientOpen(true)}>
            <UserPlus className="h-4 w-4 mr-1" />
            Add Patient
          </Button>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <StatsCard
          title="Total Patients"
          value={patientStats.totalPatients}
          trend="+5% this month"
          trendType="up"
          icon="users"
          color="primary"
          isLoading={isLoadingPatients}
        />
        
        <StatsCard
          title="Active Patients"
          value={patientStats.activePatients}
          trend="95% active rate"
          trendType="up"
          icon="user-check"
          color="secondary"
          isLoading={isLoadingPatients}
        />
        
        <StatsCard
          title="New Patients"
          value={patientStats.newPatients}
          trend="This month"
          trendType="neutral"
          icon="user-plus"
          color="accent"
          isLoading={isLoadingPatients}
        />
        
        <StatsCard
          title="Pending Appointments"
          value={patientStats.pendingAppointments}
          trend="Needs attention"
          trendType="down"
          icon="calendar-clock"
          color="warning"
          isLoading={isLoadingPatients}
        />
      </div>
      
      {/* Patients List */}
      <Card className="shadow-card overflow-hidden mb-6">
        <div className="px-6 py-4 border-b border-neutral-200 dark:border-neutral-800">
          <h2 className="text-lg font-semibold text-neutral-500 dark:text-neutral-200">Patients Directory</h2>
        </div>
        
        <PatientTable patients={transformedPatients} isLoading={isLoadingPatients} />
      </Card>
      
      {/* Recent Activity Log */}
      <Card className="shadow-card overflow-hidden">
        <div className="px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-neutral-500 dark:text-neutral-200">Recent Patient Activity</h2>
          <div className="flex items-center text-sm">
            <span className="text-neutral-400 dark:text-neutral-500 mr-2">Today</span>
            <Button variant="ghost" size="icon" className="text-neutral-300">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="p-4">
          <ul className="divide-y divide-neutral-200 dark:divide-neutral-800">
            {isLoadingActivities ? (
              // Skeleton loader for activities
              Array(4).fill(0).map((_, i) => (
                <ActivityItem key={i} isLoading={true} />
              ))
            ) : (
              // Filter only patient-related activities
              Array.isArray(activities) 
                ? activities.filter((activity: any) => 
                    activity.entityType === 'patient' ||
                    activity.message.toLowerCase().includes('patient')
                  ).slice(0, 4).map((activity: any, i: number) => (
                    <ActivityItem
                      key={i}
                      type={activity.type}
                      message={activity.message}
                      time={activity.time}
                      isLoading={false}
                    />
                  ))
                : (
                  // Fallback if no patient activities
                  <div className="py-4 text-center text-neutral-500 dark:text-neutral-400">
                    No recent patient activities
                  </div>
                )
            )}
          </ul>
          
          <div className="mt-2 text-center">
            <Button variant="link" className="text-primary text-sm font-medium">
              View All Activity
            </Button>
          </div>
        </div>
      </Card>
      
      {/* Add Patient Dialog */}
      <AddPatientDialog open={isAddPatientOpen} onOpenChange={setIsAddPatientOpen} />
    </div>
  );
}
