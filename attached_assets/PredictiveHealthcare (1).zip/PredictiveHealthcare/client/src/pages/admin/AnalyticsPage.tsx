import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  BarChart3, 
  Calendar, 
  Users, 
  Download,
  ArrowDown,
  ArrowUp,
  Minus,
  Stethoscope,
  Pill,
  UserPlus,
  Package,
  DollarSign
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

// Sample data for charts
const appointmentsByDayData = [
  { day: 'Mon', appointments: 10 },
  { day: 'Tue', appointments: 15 },
  { day: 'Wed', appointments: 8 },
  { day: 'Thu', appointments: 12 },
  { day: 'Fri', appointments: 20 },
  { day: 'Sat', appointments: 5 },
  { day: 'Sun', appointments: 3 },
];

const patientDemographicsData = [
  { name: '0-18', value: 200 },
  { name: '19-35', value: 300 },
  { name: '36-50', value: 250 },
  { name: '51-65', value: 180 },
  { name: '65+', value: 120 },
];

const medicationUsageData = [
  { name: 'Antibiotics', value: 300 },
  { name: 'Pain Relief', value: 250 },
  { name: 'Cardiovascular', value: 180 },
  { name: 'Respiratory', value: 120 },
  { name: 'Others', value: 150 },
];

const revenueTrendData = [
  { month: 'Jan', revenue: 5000 },
  { month: 'Feb', revenue: 6200 },
  { month: 'Mar', revenue: 7800 },
  { month: 'Apr', revenue: 7200 },
  { month: 'May', revenue: 8100 },
  { month: 'Jun', revenue: 9000 },
];

const doctorPerformanceData = [
  { doctor: 'Dr. Smith', patients: 45, appointments: 56 },
  { doctor: 'Dr. Johnson', patients: 38, appointments: 42 },
  { doctor: 'Dr. Williams', patients: 55, appointments: 60 },
  { doctor: 'Dr. Brown', patients: 40, appointments: 48 },
  { doctor: 'Dr. Davis', patients: 36, appointments: 40 },
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];
const DEMOGRAPHICS_COLORS = ['#82ca9d', '#8dd1e1', '#82b1ff', '#d0ed57', '#ffc658'];

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("week");
  
  // Mock loading state - would be connected to actual API in production
  const isLoading = false;

  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value);
  };

  // Statistics calculations
  const totalPatients = 1050;
  const totalAppointments = 324;
  const totalDoctors = 12;
  const totalRevenue = 42500;
  
  // Calculate percent change (would be from actual data in production)
  const patientChange = 6.4;  // positive percentage
  const appointmentChange = 12.8;  // positive percentage
  const doctorChange = 0;  // no change
  const revenueChange = -2.3;  // negative percentage

  // Function to return trend icon based on percentage
  const getTrendIcon = (percentage: number) => {
    if (percentage > 0) {
      return <ArrowUp className="h-4 w-4 text-green-500" />;
    } else if (percentage < 0) {
      return <ArrowDown className="h-4 w-4 text-red-500" />;
    }
    return <Minus className="h-4 w-4 text-neutral-500" />;
  };

  return (
    <div className="p-6 pb-20 md:pb-6">
      {/* Header with time filter */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 sm:mb-0">Analytics Dashboard</h1>
        <div className="flex items-center space-x-2">
          <Select
            value={timeRange}
            onValueChange={handleTimeRangeChange}
          >
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        {/* Total Patients Card */}
        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="flex justify-between items-center text-sm font-medium text-neutral-500">
              Total Patients
              <Users className="h-4 w-4 text-primary" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-9 w-24 mb-1" />
            ) : (
              <>
                <div className="text-2xl font-bold">{totalPatients.toLocaleString()}</div>
                <div className="flex items-center text-xs text-neutral-500 mt-1">
                  {getTrendIcon(patientChange)}
                  <span className={`ml-1 ${patientChange > 0 ? 'text-green-500' : patientChange < 0 ? 'text-red-500' : ''}`}>
                    {Math.abs(patientChange)}% from last {timeRange}
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Total Appointments Card */}
        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="flex justify-between items-center text-sm font-medium text-neutral-500">
              Total Appointments
              <Calendar className="h-4 w-4 text-secondary" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-9 w-24 mb-1" />
            ) : (
              <>
                <div className="text-2xl font-bold">{totalAppointments.toLocaleString()}</div>
                <div className="flex items-center text-xs text-neutral-500 mt-1">
                  {getTrendIcon(appointmentChange)}
                  <span className={`ml-1 ${appointmentChange > 0 ? 'text-green-500' : appointmentChange < 0 ? 'text-red-500' : ''}`}>
                    {Math.abs(appointmentChange)}% from last {timeRange}
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Total Doctors Card */}
        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="flex justify-between items-center text-sm font-medium text-neutral-500">
              Total Doctors
              <Stethoscope className="h-4 w-4 text-accent" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-9 w-24 mb-1" />
            ) : (
              <>
                <div className="text-2xl font-bold">{totalDoctors.toLocaleString()}</div>
                <div className="flex items-center text-xs text-neutral-500 mt-1">
                  {getTrendIcon(doctorChange)}
                  <span className={`ml-1 ${doctorChange > 0 ? 'text-green-500' : doctorChange < 0 ? 'text-red-500' : ''}`}>
                    {Math.abs(doctorChange)}% from last {timeRange}
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Total Revenue Card */}
        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="flex justify-between items-center text-sm font-medium text-neutral-500">
              Total Revenue
              <DollarSign className="h-4 w-4 text-green-500" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-9 w-24 mb-1" />
            ) : (
              <>
                <div className="text-2xl font-bold">${totalRevenue.toLocaleString()}</div>
                <div className="flex items-center text-xs text-neutral-500 mt-1">
                  {getTrendIcon(revenueChange)}
                  <span className={`ml-1 ${revenueChange > 0 ? 'text-green-500' : revenueChange < 0 ? 'text-red-500' : ''}`}>
                    {Math.abs(revenueChange)}% from last {timeRange}
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Appointments by Day */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Appointments by Day</CardTitle>
            <CardDescription>Number of appointments scheduled each day</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-[300px] flex items-center justify-center">
                <Skeleton className="h-full w-full" />
              </div>
            ) : (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={appointmentsByDayData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="appointments" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Revenue Trend */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Revenue Trend</CardTitle>
            <CardDescription>Monthly revenue trend</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-[300px] flex items-center justify-center">
                <Skeleton className="h-full w-full" />
              </div>
            ) : (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueTrendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="revenue" fill="#82ca9d" stroke="#82ca9d" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Patient Demographics */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Patient Demographics</CardTitle>
            <CardDescription>Age distribution of patients</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-[300px] flex items-center justify-center">
                <Skeleton className="h-full w-full" />
              </div>
            ) : (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={patientDemographicsData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {patientDemographicsData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={DEMOGRAPHICS_COLORS[index % DEMOGRAPHICS_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Medication Usage */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Medication Usage</CardTitle>
            <CardDescription>Most prescribed medications by category</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-[300px] flex items-center justify-center">
                <Skeleton className="h-full w-full" />
              </div>
            ) : (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={medicationUsageData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {medicationUsageData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Doctor Performance */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Doctor Performance</CardTitle>
            <CardDescription>Patient load and appointment count</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-[300px] flex items-center justify-center">
                <Skeleton className="h-full w-full" />
              </div>
            ) : (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={doctorPerformanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="doctor" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="patients" fill="#8884d8" />
                    <Bar dataKey="appointments" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Additional Analysis */}
      <div className="grid grid-cols-1 gap-6">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Key Insights and Recommendations</CardTitle>
            <CardDescription>Automated analysis from the system</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <h3 className="font-medium text-blue-700 dark:text-blue-300 mb-2">Operational Efficiency</h3>
              <p className="text-sm text-neutral-700 dark:text-neutral-300">
                Peak appointment times are between 9am-11am and 2pm-4pm. Consider optimizing staff scheduling during these hours to minimize wait times.
              </p>
            </div>
            
            <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <h3 className="font-medium text-green-700 dark:text-green-300 mb-2">Patient Satisfaction</h3>
              <p className="text-sm text-neutral-700 dark:text-neutral-300">
                The cardiology department has the highest patient satisfaction scores (94%). Review their patient care protocols for potential implementation in other departments.
              </p>
            </div>
            
            <div className="p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
              <h3 className="font-medium text-amber-700 dark:text-amber-300 mb-2">Inventory Alert</h3>
              <p className="text-sm text-neutral-700 dark:text-neutral-300">
                5 critical medications are running low on stock. Check the Inventory page for detailed information and reorder suggestions.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}