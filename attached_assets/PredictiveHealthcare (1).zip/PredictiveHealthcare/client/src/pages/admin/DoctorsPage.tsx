import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Filter, Download, Plus, Search, ArrowDownNarrowWide } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import StatsCard from "@/components/stats/StatsCard";
import DoctorTable from "@/components/doctors/DoctorTable";
import AddDoctorDialog from "@/components/doctors/AddDoctorDialog";
import ActivityItem from "@/components/activity/ActivityItem";
import DepartmentChart from "@/components/charts/DepartmentChart";
import { useMobile } from "@/hooks/use-mobile";

export default function DoctorsPage() {
  const [isAddDoctorOpen, setIsAddDoctorOpen] = useState(false);
  const isMobile = useMobile();
  
  // Fetch doctors data
  const { data: doctors, isLoading: isLoadingDoctors } = useQuery({
    queryKey: ['/api/doctors'],
  });
  
  // Fetch stats data
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['/api/doctors/stats'],
  });
  
  // Fetch recent activities
  const { data: activities, isLoading: isLoadingActivities } = useQuery({
    queryKey: ['/api/activities'],
  });

  return (
    <div className="p-6 pb-20 md:pb-6">
      {/* Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
        <div className="flex items-center">
          <div className="relative mr-4 md:hidden">
            <Input
              type="text"
              placeholder="Search doctors..."
              className="pl-10 pr-4 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm w-full"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-300" />
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" className="text-neutral-400">
              <Filter className="h-4 w-4 mr-1" />
              Filter
            </Button>
            <Button variant="outline" size="sm" className="text-neutral-400">
              <ArrowDownNarrowWide className="h-4 w-4 mr-1" />
              Sort
            </Button>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="text-neutral-400">
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
          <Button size="sm" onClick={() => setIsAddDoctorOpen(true)}>
            <Plus className="h-4 w-4 mr-1" />
            Add Doctor
          </Button>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <StatsCard
          title="Total Doctors"
          value={stats?.totalDoctors || 42}
          trend="+2 this month"
          trendType="up"
          icon="user-star"
          color="primary"
          isLoading={isLoadingStats}
        />
        
        <StatsCard
          title="Active Doctors"
          value={stats?.activeDoctors || 38}
          trend="90% active rate"
          trendType="up"
          icon="user-follow"
          color="secondary"
          isLoading={isLoadingStats}
        />
        
        <StatsCard
          title="On Leave"
          value={stats?.onLeave || 4}
          trend="Return within 7 days"
          trendType="neutral"
          icon="rest-time"
          color="warning"
          isLoading={isLoadingStats}
        />
        
        <StatsCard
          title="Today's Appointments"
          value={stats?.todayAppointments || 78}
          trend="+12% vs last week"
          trendType="up"
          icon="calendar-check"
          color="accent"
          isLoading={isLoadingStats}
        />
      </div>
      
      {/* Doctors List */}
      <Card className="shadow-card overflow-hidden mb-6">
        <div className="px-6 py-4 border-b border-neutral-200 dark:border-neutral-800">
          <h2 className="text-lg font-semibold text-neutral-500 dark:text-neutral-200">Doctors Directory</h2>
        </div>
        
        <DoctorTable doctors={doctors} isLoading={isLoadingDoctors} />
      </Card>
      
      {/* Analytics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Distribution Chart */}
        <Card className="shadow-card overflow-hidden">
          <div className="px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-neutral-500 dark:text-neutral-200">Appointments by Department</h2>
            <div className="flex items-center text-sm">
              <span className="text-neutral-400 dark:text-neutral-500 mr-2">Last 30 days</span>
              <Button variant="ghost" size="icon" className="text-neutral-300">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div className="p-6">
            <DepartmentChart />
          </div>
        </Card>
        
        {/* Recent Activity Log */}
        <Card className="shadow-card overflow-hidden">
          <div className="px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-neutral-500 dark:text-neutral-200">Recent Activity</h2>
            <div className="flex items-center text-sm">
              <span className="text-neutral-400 dark:text-neutral-500 mr-2">Today</span>
              <Button variant="ghost" size="icon" className="text-neutral-300">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div className="p-4">
            <ul className="divide-y divide-neutral-200 dark:divide-neutral-800">
              {isLoadingActivities ? (
                // Skeleton loader for activities
                Array(4).fill(0).map((_, i) => (
                  <ActivityItem key={i} isLoading={true} />
                ))
              ) : (
                // Real activity items
                activities?.slice(0, 4).map((activity, i) => (
                  <ActivityItem
                    key={i}
                    type={activity.type}
                    message={activity.message}
                    time={activity.time}
                    isLoading={false}
                  />
                )) || (
                  // Fallback data
                  [
                    {
                      type: "user-add",
                      message: "<span class='font-medium'>Dr. Emily Wilson</span> was added to the system",
                      time: "10:23 AM"
                    },
                    {
                      type: "calendar-check",
                      message: "<span class='font-medium'>12 new appointments</span> were scheduled",
                      time: "9:45 AM"
                    },
                    {
                      type: "rest-time",
                      message: "<span class='font-medium'>Dr. Michael Chen</span> requested leave",
                      time: "Yesterday, 5:30 PM"
                    },
                    {
                      type: "user-follow",
                      message: "<span class='font-medium'>8 patients</span> were assigned to Dr. James Rodriguez",
                      time: "Yesterday, 3:15 PM"
                    }
                  ].map((activity, i) => (
                    <ActivityItem
                      key={i}
                      type={activity.type}
                      message={activity.message}
                      time={activity.time}
                      isLoading={false}
                    />
                  ))
                )
              )}
            </ul>
            
            <div className="mt-2 text-center">
              <Button variant="link" className="text-primary text-sm font-medium">
                View All Activity
              </Button>
            </div>
          </div>
        </Card>
      </div>
      
      {/* Add Doctor Dialog */}
      <AddDoctorDialog open={isAddDoctorOpen} onOpenChange={setIsAddDoctorOpen} />
    </div>
  );
}
