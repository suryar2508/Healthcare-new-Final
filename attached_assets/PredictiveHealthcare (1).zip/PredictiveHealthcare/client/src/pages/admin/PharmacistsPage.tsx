import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Filter, 
  Download, 
  Plus, 
  Search, 
  ArrowDownNarrowWide, 
  Pill 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import StatsCard from "@/components/stats/StatsCard";
import { useMobile } from "@/hooks/use-mobile";
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function PharmacistsPage() {
  const [isAddPharmacistOpen, setIsAddPharmacistOpen] = useState(false);
  const isMobile = useMobile();
  
  // Fetch pharmacists data
  const { data: pharmacists, isLoading: isLoadingPharmacists } = useQuery({
    queryKey: ['/api/pharmacists'],
  });

  // Transform pharmacists data to match our component props
  const transformedPharmacists = Array.isArray(pharmacists) 
    ? pharmacists.map((pharmacist: any) => ({
        id: pharmacist.id,
        name: `${pharmacist.user.firstName} ${pharmacist.user.lastName}`,
        email: pharmacist.user.email,
        phone: pharmacist.user.phone,
        licenseNumber: pharmacist.licenseNumber,
        experience: pharmacist.experience,
        status: pharmacist.user.status || "active"
      }))
    : [];

  // Calculate pharmacist stats
  const pharmacistStats = {
    totalPharmacists: Array.isArray(pharmacists) ? pharmacists.length : 0,
    activePharmacists: Array.isArray(pharmacists) 
      ? pharmacists.filter((p: any) => p.user.status === "active").length 
      : 0,
    pendingOrders: Math.floor(Math.random() * 20) + 5, // Demo value
    stockAlerts: Math.floor(Math.random() * 10) + 2, // Demo value
  };

  // Render skeleton loader for pharmacist table
  const renderSkeletonRows = () => {
    return Array(5).fill(0).map((_, index) => (
      <TableRow key={index}>
        <TableCell>
          <div className="flex items-center space-x-3">
            <Skeleton className="h-10 w-10 rounded-full" />
            <div>
              <Skeleton className="h-4 w-[120px] mb-2" />
              <Skeleton className="h-3 w-[80px]" />
            </div>
          </div>
        </TableCell>
        <TableCell><Skeleton className="h-4 w-[150px]" /></TableCell>
        <TableCell><Skeleton className="h-4 w-[100px]" /></TableCell>
        <TableCell><Skeleton className="h-4 w-[80px]" /></TableCell>
        <TableCell><Skeleton className="h-6 w-[70px] rounded-full" /></TableCell>
        <TableCell><Skeleton className="h-8 w-[100px]" /></TableCell>
      </TableRow>
    ));
  };

  // Render table with pharmacist data
  const renderPharmacistsTable = () => {
    if (isLoadingPharmacists) {
      return renderSkeletonRows();
    }

    if (!transformedPharmacists.length) {
      return (
        <TableRow>
          <TableCell colSpan={6} className="text-center py-10">
            <Pill className="h-10 w-10 mx-auto text-neutral-300 mb-3" />
            <p className="text-lg font-medium text-neutral-900 dark:text-neutral-100">No pharmacists found</p>
            <p className="text-neutral-500 dark:text-neutral-400 mt-1">Add a new pharmacist to see it here</p>
          </TableCell>
        </TableRow>
      );
    }

    return transformedPharmacists.map((pharmacist) => (
      <TableRow key={pharmacist.id}>
        <TableCell>
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-500 font-medium">
              {pharmacist.name[0]}
            </div>
            <div>
              <p className="font-medium">{pharmacist.name}</p>
              <p className="text-sm text-neutral-500">{pharmacist.email}</p>
            </div>
          </div>
        </TableCell>
        <TableCell>{pharmacist.phone || "N/A"}</TableCell>
        <TableCell>{pharmacist.licenseNumber || "N/A"}</TableCell>
        <TableCell>{pharmacist.experience} yrs</TableCell>
        <TableCell>
          <Badge
            className={
              pharmacist.status === "active"
                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
                : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100"
            }
          >
            {pharmacist.status}
          </Badge>
        </TableCell>
        <TableCell>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">Edit</Button>
            <Button variant="outline" size="sm" className="text-destructive hover:text-destructive">Delete</Button>
          </div>
        </TableCell>
      </TableRow>
    ));
  };

  return (
    <div className="p-6 pb-20 md:pb-6">
      {/* Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
        <div className="flex items-center">
          <div className="relative mr-4 md:hidden">
            <Input
              type="text"
              placeholder="Search pharmacists..."
              className="pl-10 pr-4 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm w-full"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-300" />
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" className="text-neutral-400">
              <Filter className="h-4 w-4 mr-1" />
              Filter
            </Button>
            <Button variant="outline" size="sm" className="text-neutral-400">
              <ArrowDownNarrowWide className="h-4 w-4 mr-1" />
              Sort
            </Button>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="text-neutral-400">
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
          <Button size="sm" onClick={() => setIsAddPharmacistOpen(true)}>
            <Plus className="h-4 w-4 mr-1" />
            Add Pharmacist
          </Button>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <StatsCard
          title="Total Pharmacists"
          value={pharmacistStats.totalPharmacists}
          trend="+3% this month"
          trendType="up"
          icon="pill"
          color="primary"
          isLoading={isLoadingPharmacists}
        />
        
        <StatsCard
          title="Active Pharmacists"
          value={pharmacistStats.activePharmacists}
          trend="96% active rate"
          trendType="up"
          icon="user-check"
          color="secondary"
          isLoading={isLoadingPharmacists}
        />
        
        <StatsCard
          title="Pending Orders"
          value={pharmacistStats.pendingOrders}
          trend="Needs attention"
          trendType="neutral"
          icon="package"
          color="accent"
          isLoading={isLoadingPharmacists}
        />
        
        <StatsCard
          title="Stock Alerts"
          value={pharmacistStats.stockAlerts}
          trend="Low inventory"
          trendType="down"
          icon="alert-triangle"
          color="warning"
          isLoading={isLoadingPharmacists}
        />
      </div>
      
      {/* Pharmacists List */}
      <Card className="shadow-card overflow-hidden">
        <div className="px-6 py-4 border-b border-neutral-200 dark:border-neutral-800">
          <h2 className="text-lg font-semibold text-neutral-500 dark:text-neutral-200">Pharmacists Directory</h2>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>License #</TableHead>
                <TableHead>Experience</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {renderPharmacistsTable()}
            </TableBody>
          </Table>
        </div>
      </Card>
      
      {/* Add Pharmacist Dialog - would be implemented in the future */}
      {/* <AddPharmacistDialog open={isAddPharmacistOpen} onOpenChange={setIsAddPharmacistOpen} /> */}
    </div>
  );
}