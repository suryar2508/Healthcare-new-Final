import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Filter, 
  Download, 
  Plus, 
  Search, 
  ArrowDownNarrowWide, 
  Package,
  AlertTriangle,
  FileDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import StatsCard from "@/components/stats/StatsCard";
import { useMobile } from "@/hooks/use-mobile";
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

export default function InventoryPage() {
  const [isAddMedicineOpen, setIsAddMedicineOpen] = useState(false);
  const [currentView, setCurrentView] = useState<"all" | "low" | "expired">("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const isMobile = useMobile();
  
  // Fetch medications data
  const { data: medications, isLoading: isLoadingMedications } = useQuery({
    queryKey: ['/api/medications'],
  });

  // Transform medications data
  const transformedMedications = Array.isArray(medications) 
    ? medications.map((medication: any) => ({
        id: medication.id,
        name: medication.name,
        category: medication.category,
        manufacturer: medication.manufacturer,
        batchNumber: medication.batchNumber,
        quantity: medication.quantity,
        unit: medication.unit,
        expiryDate: new Date(medication.expiryDate),
        price: medication.price,
        status: medication.quantity < 10 ? "low" : 
                (new Date(medication.expiryDate) < new Date() ? "expired" : "available")
      }))
    : [];

  // Filter medications based on selected view and category
  const filteredMedications = transformedMedications.filter(med => {
    const matchesCategory = categoryFilter === "all" || med.category === categoryFilter;
    const matchesStatus = currentView === "all" || med.status === currentView;
    return matchesCategory && matchesStatus;
  });

  // Get unique categories for the filter dropdown
  const uniqueCategories = Array.from(
    new Set(transformedMedications.map(med => med.category))
  );

  // Calculate inventory stats
  const inventoryStats = {
    totalMedicines: transformedMedications.length,
    lowStock: transformedMedications.filter(med => med.status === "low").length,
    expired: transformedMedications.filter(med => med.status === "expired").length,
    totalValue: transformedMedications.reduce((sum, med) => sum + (med.price * med.quantity), 0)
  };

  // Render skeleton loader for medications table
  const renderSkeletonRows = () => {
    return Array(5).fill(0).map((_, index) => (
      <TableRow key={index}>
        <TableCell><Skeleton className="h-4 w-[150px]" /></TableCell>
        <TableCell><Skeleton className="h-4 w-[80px]" /></TableCell>
        <TableCell><Skeleton className="h-4 w-[100px]" /></TableCell>
        <TableCell><Skeleton className="h-4 w-[60px]" /></TableCell>
        <TableCell><Skeleton className="h-4 w-[80px]" /></TableCell>
        <TableCell><Skeleton className="h-6 w-[70px] rounded-full" /></TableCell>
        <TableCell><Skeleton className="h-8 w-[100px]" /></TableCell>
      </TableRow>
    ));
  };

  // Format price with currency symbol
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  // Format date to readable string
  const formatDate = (date: Date) => {
    return date.toLocaleDateString();
  };

  // Get status badge styling
  const getStatusBadge = (status: string) => {
    switch(status) {
      case "available":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100";
      case "low":
        return "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100";
      case "expired":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100";
      default:
        return "bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-100";
    }
  };

  // Render table with medications data
  const renderMedicationsTable = () => {
    if (isLoadingMedications) {
      return renderSkeletonRows();
    }

    if (!filteredMedications.length) {
      return (
        <TableRow>
          <TableCell colSpan={7} className="text-center py-10">
            <Package className="h-10 w-10 mx-auto text-neutral-300 mb-3" />
            <p className="text-lg font-medium text-neutral-900 dark:text-neutral-100">
              {transformedMedications.length > 0 
                ? "No medications match the selected filters" 
                : "No medications found"}
            </p>
            <p className="text-neutral-500 dark:text-neutral-400 mt-1">
              {transformedMedications.length > 0 
                ? "Try changing your filters" 
                : "Add a new medication to see it here"}
            </p>
          </TableCell>
        </TableRow>
      );
    }

    return filteredMedications.map((medication) => (
      <TableRow key={medication.id}>
        <TableCell>
          <div>
            <p className="font-medium">{medication.name}</p>
            <p className="text-sm text-neutral-500">{medication.manufacturer}</p>
          </div>
        </TableCell>
        <TableCell>{medication.category}</TableCell>
        <TableCell>{medication.batchNumber}</TableCell>
        <TableCell>
          <span className="font-medium">{medication.quantity}</span>
          <span className="text-xs text-neutral-500 ml-1">{medication.unit}</span>
        </TableCell>
        <TableCell>{formatDate(medication.expiryDate)}</TableCell>
        <TableCell>
          <Badge className={getStatusBadge(medication.status)}>
            {medication.status}
          </Badge>
        </TableCell>
        <TableCell>{formatPrice(medication.price)}</TableCell>
        <TableCell>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">Edit</Button>
            <Button variant="outline" size="sm">Order</Button>
          </div>
        </TableCell>
      </TableRow>
    ));
  };

  return (
    <div className="p-6 pb-20 md:pb-6">
      {/* Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
        <div className="flex items-center">
          <div className="relative mr-4 md:hidden">
            <Input
              type="text"
              placeholder="Search medications..."
              className="pl-10 pr-4 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm w-full"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-300" />
          </div>
          <div className="flex space-x-2">
            <Select 
              value={categoryFilter} 
              onValueChange={setCategoryFilter}
            >
              <SelectTrigger className="w-[180px] h-9">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {uniqueCategories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="text-neutral-400">
            <FileDown className="h-4 w-4 mr-1" />
            Export Report
          </Button>
          <Button size="sm" onClick={() => setIsAddMedicineOpen(true)}>
            <Plus className="h-4 w-4 mr-1" />
            Add Medicine
          </Button>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <StatsCard
          title="Total Medicines"
          value={inventoryStats.totalMedicines}
          trend="In inventory"
          trendType="neutral"
          icon="package"
          color="primary"
          isLoading={isLoadingMedications}
        />
        
        <StatsCard
          title="Low Stock Items"
          value={inventoryStats.lowStock}
          trend="Need reordering"
          trendType="down"
          icon="alert-triangle"
          color="warning"
          isLoading={isLoadingMedications}
        />
        
        <StatsCard
          title="Expired Items"
          value={inventoryStats.expired}
          trend="Need disposal"
          trendType="down"
          icon="x-circle"
          color="error"
          isLoading={isLoadingMedications}
        />
        
        <StatsCard
          title="Total Value"
          value={formatPrice(inventoryStats.totalValue)}
          trend="Current inventory"
          trendType="up"
          icon="dollar-sign"
          color="accent"
          isLoading={isLoadingMedications}
        />
      </div>
      
      {/* Medications Table with tabs */}
      <Card className="shadow-card overflow-hidden">
        <div className="px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <h2 className="text-lg font-semibold text-neutral-500 dark:text-neutral-200">Medicine Inventory</h2>
          
          <Tabs 
            value={currentView}
            onValueChange={(value) => setCurrentView(value as "all" | "low" | "expired")}
            className="w-full sm:w-auto"
          >
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="low" className="flex items-center">
                <AlertTriangle className="h-3 w-3 mr-1" />
                Low Stock
              </TabsTrigger>
              <TabsTrigger value="expired">Expired</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Batch #</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Expiry Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {renderMedicationsTable()}
            </TableBody>
          </Table>
        </div>
      </Card>
      
      {/* Add Medicine Dialog - would be implemented in the future */}
      {/* <AddMedicineDialog open={isAddMedicineOpen} onOpenChange={setIsAddMedicineOpen} /> */}
    </div>
  );
}