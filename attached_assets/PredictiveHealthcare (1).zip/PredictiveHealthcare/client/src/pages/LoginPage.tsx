import { useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, Mail, Lock, User, Stethoscope, Pill } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Define the form schema for validation
const formSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters")
});

// Type for credentials
interface Credentials {
  email: string;
  password: string;
  role: string;
  name: string;
}

// Default credentials for testing
const CREDENTIALS: Credentials[] = [
  {
    email: "admin@medicare.com",
    password: "admin123",
    role: "admin",
    name: "Admin User"
  },
  {
    email: "doctor@medicare.com",
    password: "doctor123",
    role: "doctor",
    name: "Dr. James Wilson"
  },
  {
    email: "patient@medicare.com",
    password: "patient123",
    role: "patient",
    name: "Sarah Johnson"
  },
  {
    email: "pharmacist@medicare.com",
    password: "pharmacist123",
    role: "pharmacist",
    name: "John Davis"
  }
];

type FormValues = z.infer<typeof formSchema>;

export default function LoginPage() {
  const [selectedRole, setSelectedRole] = useState<string>("admin");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Initialize the form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: ""
    }
  });

  // Handle form submission
  const onSubmit = (values: FormValues) => {
    setIsLoading(true);
    
    // Simulate authentication delay
    setTimeout(() => {
      const credential = CREDENTIALS.find(
        cred => cred.email === values.email && cred.password === values.password && cred.role === selectedRole
      );
      
      if (credential) {
        // Store user role in localStorage (in a real app, this would be a secure JWT token)
        localStorage.setItem("userRole", credential.role);
        localStorage.setItem("userName", credential.name);
        
        toast({
          title: "Login Successful",
          description: `Welcome back, ${credential.name}!`,
        });
        
        // Redirect based on role
        switch (credential.role) {
          case "admin":
            navigate("/admin/dashboard");
            break;
          case "doctor":
            navigate("/doctor/dashboard");
            break;
          case "patient":
            navigate("/patient/dashboard");
            break;
          case "pharmacist":
            navigate("/pharmacist/dashboard");
            break;
          default:
            navigate("/admin/dashboard");
        }
      } else {
        toast({
          title: "Login Failed",
          description: "Invalid email or password for the selected role.",
          variant: "destructive"
        });
      }
      setIsLoading(false);
    }, 1000);
  };

  // Quick login function (for development/testing)
  const quickLogin = (role: string) => {
    const credential = CREDENTIALS.find(cred => cred.role === role);
    if (credential) {
      form.setValue("email", credential.email);
      form.setValue("password", credential.password);
      setSelectedRole(role);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-neutral-50 to-neutral-100 dark:from-neutral-900 dark:to-neutral-800 flex flex-col items-center justify-center p-4">
      <div className="flex items-center mb-8">
        <div className="h-12 w-12 rounded-xl bg-primary flex items-center justify-center">
          <AlertTriangle className="h-6 w-6 text-white" />
        </div>
        <h1 className="text-2xl md:text-3xl font-bold ml-3">MediCare+</h1>
      </div>
      
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="pb-4">
          <CardTitle className="text-2xl text-center">Log in to your account</CardTitle>
          <CardDescription className="text-center">
            Enter your email and password to access the system
          </CardDescription>
        </CardHeader>
        
        <Tabs value={selectedRole} onValueChange={setSelectedRole} className="w-full">
          <div className="px-6">
            <TabsList className="grid grid-cols-4 mb-4">
              <TabsTrigger value="admin" className="flex flex-col items-center py-2">
                <User className="h-4 w-4 mb-1" />
                <span className="text-xs">Admin</span>
              </TabsTrigger>
              <TabsTrigger value="doctor" className="flex flex-col items-center py-2">
                <Stethoscope className="h-4 w-4 mb-1" />
                <span className="text-xs">Doctor</span>
              </TabsTrigger>
              <TabsTrigger value="patient" className="flex flex-col items-center py-2">
                <User className="h-4 w-4 mb-1" />
                <span className="text-xs">Patient</span>
              </TabsTrigger>
              <TabsTrigger value="pharmacist" className="flex flex-col items-center py-2">
                <Pill className="h-4 w-4 mb-1" />
                <span className="text-xs">Pharmacist</span>
              </TabsTrigger>
            </TabsList>
          </div>
          
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <TabsContent value="admin">
                  <div className="text-sm mb-4 p-3 bg-neutral-50 dark:bg-neutral-800 rounded-md">
                    <p className="font-medium">Admin Module Features:</p>
                    <ul className="list-disc pl-5 mt-1 text-neutral-600 dark:text-neutral-400">
                      <li>Manage doctors, patients, and pharmacists</li>
                      <li>View appointments and schedule management</li>
                      <li>Access analytics and reporting dashboard</li>
                      <li>System settings and configuration</li>
                    </ul>
                  </div>
                </TabsContent>
                
                <TabsContent value="doctor">
                  <div className="text-sm mb-4 p-3 bg-neutral-50 dark:bg-neutral-800 rounded-md">
                    <p className="font-medium">Doctor Module Features:</p>
                    <ul className="list-disc pl-5 mt-1 text-neutral-600 dark:text-neutral-400">
                      <li>Manage patient appointments</li>
                      <li>Access patient medical records</li>
                      <li>Prescription management</li>
                      <li>Lab results and diagnostics</li>
                    </ul>
                  </div>
                </TabsContent>
                
                <TabsContent value="patient">
                  <div className="text-sm mb-4 p-3 bg-neutral-50 dark:bg-neutral-800 rounded-md">
                    <p className="font-medium">Patient Module Features:</p>
                    <ul className="list-disc pl-5 mt-1 text-neutral-600 dark:text-neutral-400">
                      <li>Book and manage appointments</li>
                      <li>View prescriptions and medical history</li>
                      <li>Upload prescription images (OCR support)</li>
                      <li>Health tracking and monitoring</li>
                    </ul>
                  </div>
                </TabsContent>
                
                <TabsContent value="pharmacist">
                  <div className="text-sm mb-4 p-3 bg-neutral-50 dark:bg-neutral-800 rounded-md">
                    <p className="font-medium">Pharmacist Module Features:</p>
                    <ul className="list-disc pl-5 mt-1 text-neutral-600 dark:text-neutral-400">
                      <li>Process and verify prescriptions</li>
                      <li>Manage inventory and medication stock</li>
                      <li>Handle medication orders</li>
                      <li>Patient medication records</li>
                    </ul>
                  </div>
                </TabsContent>
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Mail className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
                          <Input
                            placeholder={`${selectedRole}@medicare.com`}
                            className="pl-9"
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Lock className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
                          <Input
                            type="password"
                            placeholder="••••••"
                            className="pl-9"
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button type="submit" className="w-full mt-2" disabled={isLoading}>
                  {isLoading ? "Logging in..." : "Log in"}
                </Button>
              </form>
            </Form>
          </CardContent>
          
          <CardFooter className="flex flex-col text-center">
            <p className="text-sm text-neutral-500 mb-2">Quick Login (for demo purposes)</p>
            <div className="flex flex-wrap gap-2 justify-center">
              <Button
                variant="outline"
                size="sm"
                onClick={() => quickLogin("admin")}
              >
                Admin
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => quickLogin("doctor")}
              >
                Doctor
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => quickLogin("patient")}
              >
                Patient
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => quickLogin("pharmacist")}
              >
                Pharmacist
              </Button>
            </div>
            <p className="text-xs text-neutral-400 mt-6">
              For demonstration purposes only. Default credentials provided for each user role.
            </p>
          </CardFooter>
        </Tabs>
      </Card>
    </div>
  );
}