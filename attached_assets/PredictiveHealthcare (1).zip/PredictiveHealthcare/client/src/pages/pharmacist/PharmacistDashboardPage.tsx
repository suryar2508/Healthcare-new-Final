import { useState } from "react";
import { 
  Calendar, 
  Clock, 
  Users, 
  AlertTriangle,
  LogOut,
  User,
  Settings,
  FileText,
  PackageCheck,
  Pill,
  Bell,
  Package,
  Truck,
  FileUp,
  Search,
  CheckCircle,
  XCircle,
  BarChart,
  ChevronDown,
  ChevronUp,
  Stethoscope
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { useLocation } from "wouter";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";

// Type for prescription
interface Prescription {
  id: number;
  patientName: string;
  patientId: number;
  doctorName: string;
  date: string;
  medications: Medication[];
  status: "pending" | "processing" | "ready" | "delivered" | "cancelled";
  source: "doctor" | "patient-upload";
  uploadedImage?: string;
}

// Type for medication
interface Medication {
  id: number;
  name: string;
  dosage: string;
  frequency: string;
  instructions?: string;
  quantity: number;
  inStock: boolean;
  alternativesAvailable: boolean;
}

// Type for inventory item
interface InventoryItem {
  id: number;
  name: string;
  category: string;
  stock: number;
  unit: string;
  batchNumber: string;
  expiryDate: string;
  location: string;
  status: "in-stock" | "low-stock" | "expired" | "out-of-stock";
  price: number;
}

// Sample prescriptions data
const prescriptionsData: Prescription[] = [
  {
    id: 1,
    patientName: "Sarah Johnson",
    patientId: 101,
    doctorName: "Dr. James Wilson",
    date: "2023-11-01T14:30:00",
    medications: [
      { id: 1, name: "Amoxicillin", dosage: "500mg", frequency: "3 times a day", instructions: "Take with food", quantity: 30, inStock: true, alternativesAvailable: true },
      { id: 2, name: "Ibuprofen", dosage: "400mg", frequency: "As needed", instructions: "Maximum 3 tablets per day", quantity: 20, inStock: true, alternativesAvailable: true }
    ],
    status: "pending",
    source: "doctor"
  },
  {
    id: 2,
    patientName: "Michael Brown",
    patientId: 102,
    doctorName: "Dr. Emma Davis",
    date: "2023-11-01T16:15:00",
    medications: [
      { id: 3, name: "Lisinopril", dosage: "10mg", frequency: "Once daily", instructions: "Take in the morning", quantity: 30, inStock: true, alternativesAvailable: true },
      { id: 4, name: "Metformin", dosage: "500mg", frequency: "Twice daily", instructions: "Take with meals", quantity: 60, inStock: false, alternativesAvailable: true }
    ],
    status: "processing",
    source: "doctor"
  },
  {
    id: 3,
    patientName: "Emily Davis",
    patientId: 103,
    doctorName: "Self-uploaded",
    date: "2023-11-01T12:45:00",
    medications: [
      { id: 5, name: "Loratadine", dosage: "10mg", frequency: "Once daily", instructions: "Take in the morning", quantity: 30, inStock: true, alternativesAvailable: true }
    ],
    status: "ready",
    source: "patient-upload",
    uploadedImage: "prescription_image_3.jpg"
  }
];

// Sample inventory data
const inventoryData: InventoryItem[] = [
  { id: 1, name: "Amoxicillin", category: "Antibiotics", stock: 250, unit: "tablets", batchNumber: "AMX-2023-001", expiryDate: "2025-06-15", location: "Shelf A1", status: "in-stock", price: 0.5 },
  { id: 2, name: "Ibuprofen", category: "Pain Relief", stock: 180, unit: "tablets", batchNumber: "IBU-2023-054", expiryDate: "2024-12-10", location: "Shelf B3", status: "in-stock", price: 0.3 },
  { id: 3, name: "Lisinopril", category: "Cardiovascular", stock: 120, unit: "tablets", batchNumber: "LIS-2023-021", expiryDate: "2025-03-22", location: "Shelf C2", status: "in-stock", price: 0.8 },
  { id: 4, name: "Metformin", category: "Diabetes", stock: 5, unit: "tablets", batchNumber: "MET-2023-010", expiryDate: "2024-10-05", location: "Shelf D1", status: "low-stock", price: 0.4 },
  { id: 5, name: "Loratadine", category: "Allergy", stock: 75, unit: "tablets", batchNumber: "LOR-2023-033", expiryDate: "2025-02-18", location: "Shelf B2", status: "in-stock", price: 0.6 },
  { id: 6, name: "Atorvastatin", category: "Cardiovascular", stock: 0, unit: "tablets", batchNumber: "ATO-2023-008", expiryDate: "2024-11-30", location: "Shelf C1", status: "out-of-stock", price: 1.2 },
  { id: 7, name: "Cephalexin", category: "Antibiotics", stock: 45, unit: "capsules", batchNumber: "CEP-2023-042", expiryDate: "2023-12-05", location: "Shelf A2", status: "expired", price: 0.9 }
];

export default function PharmacistDashboardPage() {
  const [, navigate] = useLocation();
  const [currentTab, setCurrentTab] = useState("prescriptions");
  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null);
  const [isPrescriptionDialogOpen, setIsPrescriptionDialogOpen] = useState(false);
  const [inventoryFilter, setInventoryFilter] = useState<string>("all");
  const { toast } = useToast();
  
  // Process prescription
  const handleProcessPrescription = (prescription: Prescription) => {
    setSelectedPrescription(prescription);
    setIsPrescriptionDialogOpen(true);
  };
  
  // Update prescription status
  const updatePrescriptionStatus = (id: number, newStatus: Prescription['status']) => {
    // In a real app, this would update the database
    
    let statusMessage = "";
    switch(newStatus) {
      case "processing":
        statusMessage = "Prescription marked as processing";
        break;
      case "ready":
        statusMessage = "Prescription marked as ready for pickup";
        break;
      case "delivered":
        statusMessage = "Prescription marked as delivered";
        break;
      case "cancelled":
        statusMessage = "Prescription has been cancelled";
        break;
    }
    
    toast({
      title: "Status Updated",
      description: statusMessage
    });
    
    setIsPrescriptionDialogOpen(false);
  };
  
  // Send notification to patient
  const sendNotification = (prescriptionId: number, message: string) => {
    toast({
      title: "Notification Sent",
      description: `Patient has been notified about prescription #${prescriptionId}`
    });
  };
  
  // Filter inventory items based on selected filter
  const filteredInventory = inventoryData.filter(item => {
    if (inventoryFilter === "all") return true;
    return item.status === inventoryFilter;
  });
  
  // Handle logout
  const handleLogout = () => {
    localStorage.removeItem("userRole");
    navigate("/");
  };
  
  // Calculate total value of inventory
  const totalInventoryValue = inventoryData.reduce((total, item) => {
    return total + (item.stock * item.price);
  }, 0);
  
  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-900 flex flex-col">
      {/* Header */}
      <header className="bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 py-4 px-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
              <AlertTriangle className="h-5 w-5 text-white" />
            </div>
            <h1 className="text-xl font-bold ml-3">MediCare+ <span className="text-primary">Pharmacist</span></h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={() => {}}>
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/pharmacist/settings")}>
              <Settings className="h-5 w-5" />
            </Button>
            <div className="flex items-center">
              <Avatar>
                <AvatarImage src="https://randomuser.me/api/portraits/men/42.jpg" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div className="ml-3 hidden md:block">
                <p className="text-sm font-medium">John Davis</p>
                <p className="text-xs text-neutral-500">Senior Pharmacist</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className="w-20 md:w-64 bg-white dark:bg-neutral-800 border-r border-neutral-200 dark:border-neutral-700 p-4 hidden md:block">
          <nav className="space-y-2">
            <Button 
              variant={currentTab === "prescriptions" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("prescriptions")}
            >
              <FileText className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Prescriptions</span>
            </Button>
            <Button 
              variant={currentTab === "inventory" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("inventory")}
            >
              <Package className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Inventory</span>
            </Button>
            <Button 
              variant={currentTab === "orders" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("orders")}
            >
              <Truck className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Orders</span>
            </Button>
            <Button 
              variant={currentTab === "patients" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("patients")}
            >
              <Users className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Patients</span>
            </Button>
            <Button 
              variant={currentTab === "reports" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("reports")}
            >
              <BarChart className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Reports</span>
            </Button>
            <Separator className="my-4" />
            <Button 
              variant="ghost" 
              className="w-full justify-start text-neutral-500"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Logout</span>
            </Button>
          </nav>
        </aside>
        
        {/* Content Area */}
        <main className="flex-1 p-6 overflow-auto">
          <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full">
            {/* Prescriptions Tab */}
            <TabsContent value="prescriptions" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">Prescription Queue</h2>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
                    <Input 
                      placeholder="Search prescriptions..." 
                      className="pl-9 w-[250px]"
                    />
                  </div>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[160px]">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="processing">Processing</SelectItem>
                      <SelectItem value="ready">Ready</SelectItem>
                      <SelectItem value="delivered">Delivered</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              {/* Prescription stats cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-100 dark:border-blue-800">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm font-medium text-blue-800 dark:text-blue-300">Pending</p>
                        <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">1</p>
                      </div>
                      <div className="p-3 bg-blue-100 dark:bg-blue-800/50 rounded-full">
                        <FileUp className="h-5 w-5 text-blue-700 dark:text-blue-300" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-amber-50 dark:bg-amber-900/20 border-amber-100 dark:border-amber-800">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm font-medium text-amber-800 dark:text-amber-300">Processing</p>
                        <p className="text-2xl font-bold text-amber-900 dark:text-amber-100">1</p>
                      </div>
                      <div className="p-3 bg-amber-100 dark:bg-amber-800/50 rounded-full">
                        <Pill className="h-5 w-5 text-amber-700 dark:text-amber-300" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-green-50 dark:bg-green-900/20 border-green-100 dark:border-green-800">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm font-medium text-green-800 dark:text-green-300">Ready</p>
                        <p className="text-2xl font-bold text-green-900 dark:text-green-100">1</p>
                      </div>
                      <div className="p-3 bg-green-100 dark:bg-green-800/50 rounded-full">
                        <PackageCheck className="h-5 w-5 text-green-700 dark:text-green-300" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-purple-50 dark:bg-purple-900/20 border-purple-100 dark:border-purple-800">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm font-medium text-purple-800 dark:text-purple-300">Delivered</p>
                        <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">0</p>
                      </div>
                      <div className="p-3 bg-purple-100 dark:bg-purple-800/50 rounded-full">
                        <Truck className="h-5 w-5 text-purple-700 dark:text-purple-300" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Prescriptions Table */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Prescriptions</CardTitle>
                  <CardDescription>Manage and process patient prescriptions</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Patient</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Source</TableHead>
                        <TableHead>Medications</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {prescriptionsData.map(prescription => (
                        <TableRow key={prescription.id}>
                          <TableCell className="font-medium">#{prescription.id}</TableCell>
                          <TableCell>
                            <div className="font-medium">{prescription.patientName}</div>
                            <div className="text-sm text-neutral-500">ID: {prescription.patientId}</div>
                          </TableCell>
                          <TableCell>
                            {new Date(prescription.date).toLocaleDateString()} 
                            <div className="text-sm text-neutral-500">
                              {new Date(prescription.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={
                                prescription.status === "pending"
                                  ? "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"
                                  : prescription.status === "processing"
                                  ? "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300"
                                  : prescription.status === "ready"
                                  ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
                                  : prescription.status === "delivered"
                                  ? "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300"
                                  : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
                              }
                            >
                              {prescription.status.charAt(0).toUpperCase() + prescription.status.slice(1)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={
                              prescription.source === "doctor" 
                                ? "border-blue-200 text-blue-800 dark:border-blue-800 dark:text-blue-300"
                                : "border-green-200 text-green-800 dark:border-green-800 dark:text-green-300"
                            }>
                              {prescription.source === "doctor" ? "Doctor" : "Patient Upload"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-col gap-1">
                              {prescription.medications.map((med, i) => (
                                <div key={i} className="text-sm flex items-center">
                                  <div className={`h-2 w-2 rounded-full mr-1 ${med.inStock ? 'bg-green-500' : 'bg-red-500'}`}></div>
                                  {med.name}
                                </div>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleProcessPrescription(prescription)}
                            >
                              {prescription.status === "pending" ? "Process" : "View Details"}
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Inventory Tab */}
            <TabsContent value="inventory" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">Inventory Management</h2>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
                    <Input 
                      placeholder="Search medications..." 
                      className="pl-9 w-[250px]"
                    />
                  </div>
                  <Button>
                    <Package className="h-4 w-4 mr-2" />
                    Add Stock
                  </Button>
                </div>
              </div>
              
              {/* Inventory Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm font-medium text-neutral-500">Total Items</p>
                        <p className="text-2xl font-bold">{inventoryData.length}</p>
                      </div>
                      <div className="p-3 bg-neutral-100 dark:bg-neutral-800 rounded-full">
                        <Package className="h-5 w-5 text-neutral-500" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm font-medium text-neutral-500">Low Stock</p>
                        <p className="text-2xl font-bold">{inventoryData.filter(i => i.status === "low-stock").length}</p>
                      </div>
                      <div className="p-3 bg-amber-100 dark:bg-amber-900/20 rounded-full">
                        <AlertTriangle className="h-5 w-5 text-amber-500" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm font-medium text-neutral-500">Expired</p>
                        <p className="text-2xl font-bold">{inventoryData.filter(i => i.status === "expired").length}</p>
                      </div>
                      <div className="p-3 bg-red-100 dark:bg-red-900/20 rounded-full">
                        <XCircle className="h-5 w-5 text-red-500" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm font-medium text-neutral-500">Total Value</p>
                        <p className="text-2xl font-bold">${totalInventoryValue.toFixed(2)}</p>
                      </div>
                      <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-full">
                        <BarChart className="h-5 w-5 text-green-500" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Inventory Filter */}
              <div className="flex space-x-2 mb-4">
                <Button 
                  variant={inventoryFilter === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setInventoryFilter("all")}
                >
                  All Items
                </Button>
                <Button 
                  variant={inventoryFilter === "low-stock" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setInventoryFilter("low-stock")}
                  className={inventoryFilter === "low-stock" ? "" : "text-amber-500"}
                >
                  Low Stock
                </Button>
                <Button 
                  variant={inventoryFilter === "expired" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setInventoryFilter("expired")}
                  className={inventoryFilter === "expired" ? "" : "text-red-500"}
                >
                  Expired
                </Button>
                <Button 
                  variant={inventoryFilter === "out-of-stock" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setInventoryFilter("out-of-stock")}
                  className={inventoryFilter === "out-of-stock" ? "" : "text-neutral-500"}
                >
                  Out of Stock
                </Button>
              </div>
              
              {/* Inventory Table */}
              <Card>
                <CardHeader>
                  <CardTitle>Medication Inventory</CardTitle>
                  <CardDescription>Track and manage medication stock levels</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Stock</TableHead>
                        <TableHead>Batch #</TableHead>
                        <TableHead>Expiry Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredInventory.map(item => (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">{item.name}</TableCell>
                          <TableCell>{item.category}</TableCell>
                          <TableCell>
                            {item.stock} {item.unit}
                            {item.status === "low-stock" && (
                              <Badge className="ml-2 bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300">Low</Badge>
                            )}
                          </TableCell>
                          <TableCell>{item.batchNumber}</TableCell>
                          <TableCell>
                            {new Date(item.expiryDate).toLocaleDateString()} 
                            {new Date(item.expiryDate) < new Date() && (
                              <Badge className="ml-2 bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300">Expired</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={
                                item.status === "in-stock"
                                  ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
                                  : item.status === "low-stock"
                                  ? "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300"
                                  : item.status === "expired"
                                  ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
                                  : "bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-300"
                              }
                            >
                              {item.status === "in-stock" ? "In Stock" : 
                               item.status === "low-stock" ? "Low Stock" :
                               item.status === "expired" ? "Expired" : "Out of Stock"}
                            </Badge>
                          </TableCell>
                          <TableCell>${item.price.toFixed(2)}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end space-x-2">
                              <Button variant="outline" size="sm">Update</Button>
                              <Button variant="outline" size="sm">Order</Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Other tabs (Orders, Patients, Reports) would be implemented similarly */}
            <TabsContent value="orders" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">Medication Orders</h2>
              </div>
              
              <Card className="shadow-md">
                <CardContent className="p-8 text-center">
                  <Truck className="h-16 w-16 mx-auto text-neutral-300 mb-4" />
                  <h3 className="text-xl font-medium">Orders Management</h3>
                  <p className="text-neutral-500 mt-2 mb-6">Track and manage medication orders from suppliers</p>
                  <Button>Create New Order</Button>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="patients" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">Patient Management</h2>
              </div>
              
              <Card className="shadow-md">
                <CardContent className="p-8 text-center">
                  <Users className="h-16 w-16 mx-auto text-neutral-300 mb-4" />
                  <h3 className="text-xl font-medium">Patient Records</h3>
                  <p className="text-neutral-500 mt-2 mb-6">View patient medication history and manage records</p>
                  <Button>Search Patients</Button>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="reports" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">Reports & Analytics</h2>
              </div>
              
              <Card className="shadow-md">
                <CardContent className="p-8 text-center">
                  <BarChart className="h-16 w-16 mx-auto text-neutral-300 mb-4" />
                  <h3 className="text-xl font-medium">Pharmacy Analytics</h3>
                  <p className="text-neutral-500 mt-2 mb-6">Generate reports and view pharmacy performance metrics</p>
                  <Button>Generate Report</Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
      
      {/* Prescription Details Dialog */}
      <Dialog open={isPrescriptionDialogOpen} onOpenChange={setIsPrescriptionDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Prescription #{selectedPrescription?.id}</DialogTitle>
            <DialogDescription>
              Prescription details and processing options
            </DialogDescription>
          </DialogHeader>
          
          {selectedPrescription && (
            <div className="space-y-6">
              {/* Patient & Doctor Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border border-neutral-200 dark:border-neutral-700 rounded-md">
                  <h3 className="font-medium mb-2 flex items-center">
                    <User className="h-4 w-4 mr-1" />
                    Patient Information
                  </h3>
                  <p><span className="text-neutral-500">Name:</span> {selectedPrescription.patientName}</p>
                  <p><span className="text-neutral-500">ID:</span> {selectedPrescription.patientId}</p>
                </div>
                
                <div className="p-4 border border-neutral-200 dark:border-neutral-700 rounded-md">
                  <h3 className="font-medium mb-2 flex items-center">
                    <Stethoscope className="h-4 w-4 mr-1" />
                    Prescription Details
                  </h3>
                  <p>
                    <span className="text-neutral-500">Doctor:</span> {
                      selectedPrescription.source === "doctor" 
                        ? selectedPrescription.doctorName 
                        : "Self-uploaded by patient"
                    }
                  </p>
                  <p>
                    <span className="text-neutral-500">Date:</span> {
                      new Date(selectedPrescription.date).toLocaleDateString() + " " +
                      new Date(selectedPrescription.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
                    }
                  </p>
                  <div className="flex items-center mt-1">
                    <span className="text-neutral-500 mr-2">Status:</span>
                    <Badge
                      className={
                        selectedPrescription.status === "pending"
                          ? "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"
                          : selectedPrescription.status === "processing"
                          ? "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300"
                          : selectedPrescription.status === "ready"
                          ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
                          : selectedPrescription.status === "delivered"
                          ? "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300"
                          : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
                      }
                    >
                      {selectedPrescription.status.charAt(0).toUpperCase() + selectedPrescription.status.slice(1)}
                    </Badge>
                  </div>
                </div>
              </div>
              
              {/* Prescription Image (if uploaded by patient) */}
              {selectedPrescription.source === "patient-upload" && selectedPrescription.uploadedImage && (
                <div className="p-4 border border-neutral-200 dark:border-neutral-700 rounded-md">
                  <h3 className="font-medium mb-2 flex items-center">
                    <FileUp className="h-4 w-4 mr-1" />
                    Uploaded Prescription Image
                  </h3>
                  <div className="bg-neutral-100 dark:bg-neutral-800 p-3 rounded-md text-center">
                    <p className="text-neutral-500">Prescription image would be displayed here</p>
                  </div>
                </div>
              )}
              
              {/* Medications List */}
              <div className="border border-neutral-200 dark:border-neutral-700 rounded-md">
                <div className="p-4 border-b border-neutral-200 dark:border-neutral-700">
                  <h3 className="font-medium flex items-center">
                    <Pill className="h-4 w-4 mr-1" />
                    Prescribed Medications
                  </h3>
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Medication</TableHead>
                      <TableHead>Dosage</TableHead>
                      <TableHead>Frequency</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Instructions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedPrescription.medications.map((med, i) => (
                      <TableRow key={i}>
                        <TableCell className="font-medium">{med.name}</TableCell>
                        <TableCell>{med.dosage}</TableCell>
                        <TableCell>{med.frequency}</TableCell>
                        <TableCell>{med.quantity}</TableCell>
                        <TableCell>
                          {med.inStock ? (
                            <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
                              In Stock
                            </Badge>
                          ) : (
                            <Badge className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300">
                              Out of Stock
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{med.instructions || "No special instructions"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Stock Issues Warning */}
              {selectedPrescription.medications.some(med => !med.inStock) && (
                <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-4 rounded-md">
                  <div className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400 mr-2 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-amber-800 dark:text-amber-300">Stock Issues Detected</h4>
                      <p className="text-sm text-amber-700 dark:text-amber-300 mt-1">
                        Some medications are out of stock. You can suggest alternatives or place an order.
                      </p>
                      <div className="mt-2">
                        <Button size="sm" variant="outline" className="border-amber-300 bg-amber-100 text-amber-800 hover:bg-amber-200 dark:border-amber-700 dark:bg-amber-900/30 dark:text-amber-300">
                          Suggest Alternatives
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Notes & Comments */}
              <div className="space-y-3">
                <Label htmlFor="notes">Notes for Processing</Label>
                <Textarea 
                  id="notes" 
                  placeholder="Add notes or special instructions for processing this prescription..."
                  className="h-20"
                />
              </div>
              
              {/* Actions based on status */}
              <DialogFooter className="flex flex-col sm:flex-row gap-2">
                {selectedPrescription.status === "pending" && (
                  <>
                    <Button variant="outline" onClick={() => updatePrescriptionStatus(selectedPrescription.id, "cancelled")}>
                      <XCircle className="h-4 w-4 mr-2" />
                      Reject
                    </Button>
                    <Button onClick={() => updatePrescriptionStatus(selectedPrescription.id, "processing")}>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Begin Processing
                    </Button>
                  </>
                )}
                
                {selectedPrescription.status === "processing" && (
                  <>
                    <Button variant="outline" onClick={() => updatePrescriptionStatus(selectedPrescription.id, "cancelled")}>
                      <XCircle className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                    <Button onClick={() => updatePrescriptionStatus(selectedPrescription.id, "ready")}>
                      <PackageCheck className="h-4 w-4 mr-2" />
                      Mark as Ready
                    </Button>
                  </>
                )}
                
                {selectedPrescription.status === "ready" && (
                  <>
                    <Button variant="outline" onClick={() => sendNotification(selectedPrescription.id, "Your prescription is ready for pickup")}>
                      <Bell className="h-4 w-4 mr-2" />
                      Notify Patient
                    </Button>
                    <Button onClick={() => updatePrescriptionStatus(selectedPrescription.id, "delivered")}>
                      <Truck className="h-4 w-4 mr-2" />
                      Mark as Delivered
                    </Button>
                  </>
                )}
                
                {(selectedPrescription.status === "delivered" || selectedPrescription.status === "cancelled") && (
                  <Button variant="outline" onClick={() => setIsPrescriptionDialogOpen(false)}>
                    Close
                  </Button>
                )}
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}