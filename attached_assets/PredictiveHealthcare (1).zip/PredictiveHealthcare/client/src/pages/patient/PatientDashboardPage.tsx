import { useState, useMemo, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { BookAppointmentDialog } from "@/components/appointments/BookAppointmentDialog";
import { 
  Calendar, 
  Clock, 
  Users, 
  AlertTriangle,
  LogOut,
  User,
  Settings,
  FileText,
  PlusCircle,
  Camera,
  UploadCloud,
  Pill,
  Bell,
  CalendarClock,
  FileUp,
  Stethoscope,
  Heart,
  Apple,
  XCircle,
  Check,
  ArrowDown,
  ArrowUp,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { useLocation } from "wouter";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

// Type for OCR-extracted medication
interface ExtractedMedication {
  name: string;
  dosage: string;
  frequency: string;
  instructions?: string;
  confidence: number;
}

// Sample patient data
const patientData = {
  name: "Sarah Johnson",
  age: 35,
  gender: "Female",
  bloodType: "A+",
  contact: "+1 (555) 987-6543",
  email: "sarah.johnson@example.com",
  address: "456 Oak St, San Francisco, CA 94107",
  allergies: ["Peanuts", "Penicillin"],
  chronicConditions: ["Asthma", "Migraine"],
  nextAppointment: {
    date: "2023-11-20T10:30:00",
    doctor: "Dr. James Wilson",
    purpose: "Regular checkup"
  }
};

// Sample appointments data
const appointmentsData = [
  { id: 1, date: "2023-11-20T10:30:00", doctor: "Dr. James Wilson", specialty: "Cardiology", status: "upcoming", purpose: "Regular checkup" },
  { id: 2, date: "2023-12-05T14:00:00", doctor: "Dr. Emma Davis", specialty: "Neurology", status: "upcoming", purpose: "Migraine follow-up" },
  { id: 3, date: "2023-10-15T09:00:00", doctor: "Dr. Michael Chen", specialty: "Pulmonology", status: "completed", purpose: "Asthma management" },
];

// Sample medication schedule
const medicationScheduleData = [
  { id: 1, name: "Albuterol", dosage: "2 puffs", schedule: "Every 6 hours as needed", refillDate: "2023-12-01", status: "active" },
  { id: 2, name: "Amitriptyline", dosage: "25mg", schedule: "Once daily at bedtime", refillDate: "2023-11-25", status: "active" },
  { id: 3, name: "Vitamin D", dosage: "1000 IU", schedule: "Once daily with food", refillDate: "2024-01-10", status: "active" }
];

// Sample prescription history
const prescriptionHistoryData = [
  { id: 1, date: "2023-10-15", doctor: "Dr. Michael Chen", medications: ["Albuterol", "Singulair"], status: "active" },
  { id: 2, date: "2023-09-22", doctor: "Dr. Emma Davis", medications: ["Amitriptyline", "Sumatriptan"], status: "active" },
  { id: 3, date: "2023-07-10", doctor: "Dr. James Wilson", medications: ["Lisinopril"], status: "completed" }
];

// Sample diet plans
const dietPlansData = [
  { id: 1, name: "Asthma Management Diet", description: "Foods that help reduce inflammation and support respiratory health", foods: ["Fatty fish", "Apples", "Leafy greens", "Ginger", "Turmeric"] },
  { id: 2, name: "Migraine Prevention", description: "Foods that help prevent migraine triggers", foods: ["Whole grains", "Yogurt", "Spinach", "Sweet potatoes", "Chicken"] }
];

// Sample health tracking data
const healthTrackingData = {
  steps: [7500, 9200, 6800, 10400, 8300, 7600, 9100],
  sleep: [7.2, 6.8, 7.5, 8.0, 6.5, 7.1, 7.9],
  weight: [145, 145, 144, 144, 143, 143, 142],
  bloodPressure: [
    { systolic: 125, diastolic: 82 },
    { systolic: 122, diastolic: 80 },
    { systolic: 128, diastolic: 83 },
    { systolic: 120, diastolic: 79 },
    { systolic: 126, diastolic: 81 },
  ]
};

// Mock OCR function to extract text from prescription images
// In a real app, this would call a cloud OCR service like Google Cloud Vision, AWS Textract, or Tesseract.js
const extractTextFromImage = async (file: File): Promise<ExtractedMedication[]> => {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 1500));

  // Mock OCR results
  return [
    {
      name: "Amoxicillin",
      dosage: "500mg",
      frequency: "3 times a day",
      instructions: "Take with food",
      confidence: 0.94
    },
    {
      name: "Ibuprofen",
      dosage: "400mg",
      frequency: "As needed",
      instructions: "Maximum 3 tablets per day",
      confidence: 0.88
    },
    {
      name: "Loratadine",
      dosage: "10mg",
      frequency: "Once daily",
      instructions: "Take in the morning",
      confidence: 0.92
    }
  ];
};

const AppointmentList = ({ appointments }: { appointments: any[] }) => {
  return (
    <div className="space-y-4">
      {appointments.map(appointment => (
        <div key={appointment.id} className="flex flex-col md:flex-row md:items-center justify-between p-4 border border-neutral-200 dark:border-neutral-700 rounded-md">
          <div className="flex items-start mb-3 md:mb-0">
            <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-md mr-4">
              <Stethoscope className="h-5 w-5 text-blue-700 dark:text-blue-300" />
            </div>
            <div>
              <p className="font-medium">{appointment.doctor}</p>
              <p className="text-sm text-neutral-500">{appointment.specialty}</p>
              <Badge className="mt-1 bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-300">
                {appointment.purpose}
              </Badge>
            </div>
          </div>

          <div className="flex flex-col md:items-end">
            <div className="flex items-center">
              <Calendar className="h-4 w-4 text-neutral-500 mr-1" />
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                {new Date(appointment.date).toLocaleDateString()}
              </p>
            </div>
            <div className="flex items-center mt-1">
              <Clock className="h-4 w-4 text-neutral-500 mr-1" />
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                {new Date(appointment.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
              </p>
            </div>
            <Badge
              className={
                appointment.status === "upcoming"
                  ? "mt-2 bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"
                  : appointment.status === "completed"
                  ? "mt-2 bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
                  : "mt-2 bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
              }
            >
              {appointment.status}
            </Badge>
          </div>

          <div className="mt-3 md:mt-0 flex md:flex-col gap-2">
            {appointment.status === "upcoming" && (
              <>
                <Button variant="outline" size="sm">Reschedule</Button>
                <Button variant="outline" size="sm" className="text-red-500 hover:text-red-600">Cancel</Button>
              </>
            )}
            {appointment.status === "completed" && (
              <Button variant="outline" size="sm">View Summary</Button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};


export default function PatientDashboardPage() {
  const [, navigate] = useLocation();
  const [currentTab, setCurrentTab] = useState("dashboard");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [showBookingDialog, setShowBookingDialog] = useState(false);

  // Fetch appointments data using React Query
  const { data: fetchedAppointments = [], isLoading } = useQuery({
    queryKey: ['appointments'],
    queryFn: async () => {
      const response = await fetch('/api/appointments');
      if (!response.ok) {
        throw new Error('Failed to fetch appointments');
      }
      const data = await response.json();
      return data.data || [];
    },
  });

  // Filter and sort appointments efficiently
  const { 
    filteredAppointments, 
    upcomingAppointments, 
    completedAppointments,
    cancelledAppointments,
    appointmentStats 
  } = useMemo(() => {
    const appointments = fetchedAppointments.length ? fetchedAppointments : appointmentsData;

    const filtered = selectedStatus === "all" 
      ? appointments
      : appointments.filter(a => a.status === selectedStatus);

    const upcoming = appointments
      .filter(a => a.status === "upcoming")
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    const completed = appointments.filter(a => a.status === "completed");
    const cancelled = appointments.filter(a => a.status === "cancelled");

    const stats = {
      upcoming: upcoming.length,
      completed: completed.length,
      cancelled: cancelled.length,
      total: appointments.length
    };

    return {
      filteredAppointments: filtered,
      upcomingAppointments: upcoming,
      completedAppointments: completed,
      cancelledAppointments: cancelled,
      appointmentStats: stats
    };
  }, [fetchedAppointments, selectedStatus, appointmentsData]);

  const { toast } = useToast();

  // OCR state
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedMedications, setExtractedMedications] = useState<ExtractedMedication[]>([]);
  const [showEditForm, setShowEditForm] = useState(false);


  // Handle file selection
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
    }
  };

  // Handle file upload
  const handleUpload = async () => {
    if (!selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select an image of your prescription to upload",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);

    try {
      // Extract text using OCR
      const extractedMeds = await extractTextFromImage(selectedFile);
      setExtractedMedications(extractedMeds);
      setShowEditForm(true);

      toast({
        title: "Prescription Processed",
        description: `Successfully extracted ${extractedMeds.length} medications from your prescription.`,
      });
    } catch (error) {
      toast({
        title: "Processing Failed",
        description: "Failed to extract text from the image. Please try again or manually enter your prescription.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle submit OCR results
  const handleSubmitOcrResults = () => {
    toast({
      title: "Prescription Submitted",
      description: "Your prescription has been sent to the pharmacy.",
    });

    setIsUploadDialogOpen(false);
    setSelectedFile(null);
    setExtractedMedications([]);
    setShowEditForm(false);
  };

  // Handle book appointment
  const handleBookAppointment = () => {
    setShowBookingDialog(true);
  };

  // Handle logout
  const handleLogout = () => {
    localStorage.removeItem("userRole");
    navigate("/");
  };

  // Use the filtered and sorted appointments

  // Function to format date and time
  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return {
      date: date.toLocaleDateString(),
      time: date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
  };


  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-900 flex flex-col">
      {/* Header */}
      <header className="bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 py-4 px-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
              <AlertTriangle className="h-5 w-5 text-white" />
            </div>
            <h1 className="text-xl font-bold ml-3">MediCare+ <span className="text-primary">Patient</span></h1>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={() => {}}>
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/patient/settings")}>
              <Settings className="h-5 w-5" />
            </Button>
            <div className="flex items-center">
              <Avatar>
                <AvatarImage src="https://randomuser.me/api/portraits/women/32.jpg" />
                <AvatarFallback>SJ</AvatarFallback>
              </Avatar>
              <div className="ml-3 hidden md:block">
                <p className="text-sm font-medium">{patientData.name}</p>
                <p className="text-xs text-neutral-500">{patientData.age} years • {patientData.bloodType}</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className="w-20 md:w-64 bg-white dark:bg-neutral-800 border-r border-neutral-200 dark:border-neutral-700 p-4 hidden md:block">
          <nav className="space-y-2">
            <Button 
              variant={currentTab === "dashboard" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("dashboard")}
            >
              <Users className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Dashboard</span>
            </Button>
            <Button 
              variant={currentTab === "appointments" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("appointments")}
            >
              <Calendar className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Appointments</span>
            </Button>
            <Button 
              variant={currentTab === "medications" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("medications")}
            >
              <Pill className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Medications</span>
            </Button>
            <Button 
              variant={currentTab === "prescriptions" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("prescriptions")}
            >
              <FileText className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Prescriptions</span>
            </Button>
            <Button 
              variant={currentTab === "diet" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("diet")}
            >
              <Apple className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Diet Plans</span>
            </Button>
            <Button 
              variant={currentTab === "health" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setCurrentTab("health")}
            >
              <Heart className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Health Tracking</span>
            </Button>
            <Separator className="my-4" />
            <Button 
              variant="ghost" 
              className="w-full justify-start text-neutral-500"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Logout</span>
            </Button>
          </nav>
        </aside>

        {/* Content Area */}
        <main className="flex-1 p-6 overflow-auto">
          <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full">
            {/* Dashboard Tab */}
            <TabsContent value="dashboard" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">Patient Dashboard</h2>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" onClick={() => setIsUploadDialogOpen(true)}>
                    <UploadCloud className="h-4 w-4 mr-2" />
                    Upload Prescription
                  </Button>
                  <Button onClick={handleBookAppointment}>
                    <Calendar className="h-4 w-4 mr-2" />
                    Book Appointment
                  </Button>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-100 dark:border-blue-800/50">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <div className="bg-blue-100 dark:bg-blue-800/50 p-3 rounded-full mr-4">
                        <CalendarClock className="h-6 w-6 text-blue-700 dark:text-blue-300" />
                      </div>
                      <div>
                        <h3 className="font-medium text-lg text-blue-800 dark:text-blue-300">Next Appointment</h3>
                        <p className="text-blue-700 dark:text-blue-400 text-sm mb-3">
                          {new Date(patientData.nextAppointment.date).toLocaleDateString()} at {
                            new Date(patientData.nextAppointment.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
                          }
                        </p>
                        <p className="text-sm text-blue-600 dark:text-blue-400">{patientData.nextAppointment.doctor}</p>
                        <p className="text-sm text-blue-600 dark:text-blue-400">{patientData.nextAppointment.purpose}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-green-50 dark:bg-green-900/20 border-green-100 dark:border-green-800/50">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <div className="bg-green-100 dark:bg-green-800/50 p-3 rounded-full mr-4">
                        <Pill className="h-6 w-6 text-green-700 dark:text-green-300" />
                      </div>
                      <div>
                        <h3 className="font-medium text-lg text-green-800 dark:text-green-300">Medication Reminder</h3>
                        <p className="text-green-700 dark:text-green-400 text-sm mb-3">Next doses due today</p>
                        <div className="space-y-1">
                          <p className="text-sm text-green-600 dark:text-green-400">Albuterol - 2 puffs - 6:00 PM</p>
                          <p className="text-sm text-green-600 dark:text-green-400">Amitriptyline - 25mg - 10:00 PM</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-purple-50 dark:bg-purple-900/20 border-purple-100 dark:border-purple-800/50">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <div className="bg-purple-100 dark:bg-purple-800/50 p-3 rounded-full mr-4">
                        <FileUp className="h-6 w-6 text-purple-700 dark:text-purple-300" />
                      </div>
                      <div>
                        <h3 className="font-medium text-lg text-purple-800 dark:text-purple-300">Quick Upload</h3>
                        <p className="text-purple-700 dark:text-purple-400 text-sm mb-3">Use our AI to scan your prescription</p>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="bg-white dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-700"
                          onClick={() => setIsUploadDialogOpen(true)}
                        >
                          <Camera className="h-4 w-4 mr-1" />
                          Scan Now
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Health Summary */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Patient Profile */}
                <Card className="lg:col-span-1">
                  <CardHeader>
                    <CardTitle>Patient Profile</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-center mb-4">
                      <Avatar className="h-24 w-24">
                        <AvatarImage src="https://randomuser.me/api/portraits/women/32.jpg" />
                        <AvatarFallback className="text-lg">{patientData.name.split(" ").map(n => n[0]).join("")}</AvatarFallback>
                      </Avatar>
                    </div>

                    <div>
                      <p className="text-sm font-medium text-neutral-500">Full Name</p>
                      <p>{patientData.name}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium text-neutral-500">Age</p>
                        <p>{patientData.age} years</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-neutral-500">Blood Type</p>
                        <p>{patientData.bloodType}</p>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <p className="text-sm font-medium text-neutral-500">Allergies</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {patientData.allergies.map((allergy, i) => (
                          <Badge key={i} variant="outline" className="bg-red-50 text-red-700 border-red-200">
                            {allergy}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium text-neutral-500">Chronic Conditions</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {patientData.chronicConditions.map((condition, i) => (
                          <Badge key={i} variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                            {condition}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Appointments Summary */}
                <Card className="lg:col-span-2">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Upcoming Appointments</CardTitle>
                      <CardDescription>Your scheduled doctor visits</CardDescription>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => setCurrentTab("appointments")}>View All</Button>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {fetchedAppointments.filter(a => a.status === "upcoming").slice(0, 2).map(appointment => (
                        <div key={appointment.id} className="flex items-start p-3 border border-neutral-200 dark:border-neutral-700 rounded-md">
                          <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-md mr-4">
                            <Calendar className="h-5 w-5 text-blue-700 dark:text-blue-300" />
                          </div>
                          <div className="flex-1">
                            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                              <div>
                                <p className="font-medium">{appointment.doctor}</p>
                                <p className="text-sm text-neutral-500">{appointment.specialty}</p>
                              </div>
                              <div className="mt-2 md:mt-0">
                                <p className="text-sm font-medium text-neutral-600 dark:text-neutral-300">
                                  {new Date(appointment.date).toLocaleDateString()} at {
                                    new Date(appointment.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
                                  }
                                </p>
                                <Badge className="mt-1 bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">
                                  {appointment.purpose}
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="border-t border-neutral-200 dark:border-neutral-700 pt-4">
                    <Button className="w-full" onClick={handleBookAppointment}>
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Book New Appointment
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            {/* Appointments Tab */}
            <TabsContent value="appointments" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">My Appointments</h2>
                <Button onClick={() => setShowBookingDialog(true)}>
                  <Calendar className="h-4 w-4 mr-2" />
                  Book Appointment
                </Button>
              </div>

              <Tabs defaultValue="all" className="w-full">
                <TabsList>
                  <TabsTrigger value="all">All Appointments</TabsTrigger>
                  <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                  <TabsTrigger value="completed">Completed</TabsTrigger>
                  <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
                </TabsList>

                <TabsContent value="all">
                  {filteredAppointments.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">No appointments found</p>
                  ) : (
                    <AppointmentList appointments={filteredAppointments} />
                  )}
                </TabsContent>

                <TabsContent value="upcoming">
                  {upcomingAppointments.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">No upcoming appointments found</p>
                  ) : (
                    <AppointmentList appointments={upcomingAppointments} />
                  )}
                </TabsContent>

                <TabsContent value="completed">
                  {completedAppointments.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">No completed appointments yet</p>
                  ) : (
                    <AppointmentList appointments={completedAppointments} />
                  )}
                </TabsContent>

                <TabsContent value="cancelled">
                  {cancelledAppointments.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">No cancelled appointments recorded</p>
                  ) : (
                    <AppointmentList appointments={cancelledAppointments} />
                  )}
                </TabsContent>
              </Tabs>
            </TabsContent>

            {/* Medications Tab */}
            <TabsContent value="medications" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">My Medications</h2>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" onClick={() => setIsUploadDialogOpen(true)}>
                    <UploadCloud className="h-4 w-4 mr-2" />
                    Upload Prescription
                  </Button>
                </div>
              </div>

              {/* Medication Schedule */}
              <Card>
                <CardHeader>
                  <CardTitle>Medication Schedule</CardTitle>
                  <CardDescription>Track your daily medication intake</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {medicationScheduleData.map(medication => (
                      <div key={medication.id} className="p-4 border borderneutral-200 dark:border-neutral-700 rounded-md">
                        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                          <div className="flex items-start">
                            <div className="p-2 mr-4 rounded-full bg-green-100 dark:bg-green-900/20">
                              <Pill className="h-5 w-5 text-green-700 dark:text-green-300" />
                            </div>
                            <div>
                              <p className="font-medium">{medication.name}</p>
                              <p className="text-sm text-neutral-500">{medication.dosage}</p>
                              <Badge className="mt-1 bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
                                {medication.status}
                              </Badge>
                            </div>
                          </div>

                          <div className="mt-3 md:mt-0">
                            <p className="text-sm font-medium">Schedule</p>
                            <p className="text-sm text-neutral-500">{medication.schedule}</p>
                          </div>

                          <div className="mt-3 md:mt-0">
                            <p className="text-sm font-medium">Next Refill</p>
                            <p className="text-sm text-neutral-500">{new Date(medication.refillDate).toLocaleDateString()}</p>
                          </div>

                          <div className="mt-3 md:mt-0">
                            <Button size="sm">
                              <Bell className="h-4 w-4 mr-1" />
                              Set Reminder
                            </Button>
                          </div>
                        </div>

                        {/* Progress for today's doses */}
                        <div className="mt-4">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Today's doses</span>
                            <span>3/4 taken</span>
                          </div>
                          <Progress value={75} className="h-2" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Prescriptions Tab */}
            <TabsContent value="prescriptions" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">Prescription History</h2>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" onClick={() => setIsUploadDialogOpen(true)}>
                    <UploadCloud className="h-4 w-4 mr-2" />
                    Upload Prescription
                  </Button>
                </div>
              </div>

              {/* Prescription List */}
              <Card>
                <CardHeader>
                  <CardTitle>Prescriptions</CardTitle>
                  <CardDescription>History of your prescriptions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {prescriptionHistoryData.map(prescription => (
                      <div key={prescription.id} className="p-4 border border-neutral-200 dark:border-neutral-700 rounded-md">
                        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                          <div>
                            <div className="flex items-center">
                              <FileText className="h-5 w-5 text-neutral-500 mr-2" />
                              <p className="font-medium">Prescription {prescription.id}</p>
                            </div>
                            <p className="text-sm text-neutral-500 mt-1">Prescribed by {prescription.doctor}</p>
                            <p className="text-sm text-neutral-500">Date: {new Date(prescription.date).toLocaleDateString()}</p>
                          </div>

                          <div className="mt-3 md:mt-0">
                            <p className="text-sm font-medium">Medications</p>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {prescription.medications.map((med, i) => (
                                <Badge key={i} variant="outline" className="bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-300">
                                  {med}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div className="mt-3 md:mt-0 flex flex-col gap-2">
                            <Button size="sm">Download PDF</Button>
                            <Button variant="outline" size="sm">Refill Request</Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Diet Plans Tab */}
            <TabsContent value="diet" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">Diet Plans</h2>
                <div className="flex items-center space-x-2">
                  <Button>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Download Meal Planner
                  </Button>
                </div>
              </div>

              {/* Diet Plans */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {dietPlansData.map(plan => (
                  <Card key={plan.id}>
                    <CardHeader>
                      <CardTitle>{plan.name}</CardTitle>
                      <CardDescription>{plan.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <h3 className="font-medium mb-2">Recommended Foods</h3>
                      <div className="grid grid-cols-2 gap-2">
                        {plan.foods.map((food, i) => (
                          <div key={i} className="flex items-center p-2 border border-neutral-200 dark:border-neutral-700 rounded-md">
                            <Check className="h-4 w-4 text-green-500 mr-2" />
                            <span>{food}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                    <CardFooter className="border-t border-neutral-200 dark:border-neutral-700 pt-4">
                      <Button className="w-full">View Full Plan</Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Health Tracking Tab */}
            <TabsContent value="health" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold mb-4 sm:mb-0">Health Tracking</h2>
                <div className="flex items-center space-x-2">
                  <Button>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Add New Entry
                  </Button>
                </div>
              </div>

              {/* Health Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Daily Activity</CardTitle>
                    <CardDescription>Your steps and activity levels</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <h3 className="font-medium">Today's Steps</h3>
                          <span className="font-semibold">{healthTrackingData.steps[6].toLocaleString()}</span>
                        </div>
                        <Progress value={(healthTrackingData.steps[6] / 10000) * 100} className="h-2" />
                        <p className="text-xs text-right mt-1 text-neutral-500">{Math.round((healthTrackingData.steps[6] / 10000) * 100)}% of 10,000 goal</p>
                      </div>

                      <div>
                        <h3 className="font-medium mb-2">Weekly Steps</h3>
                        <div className="h-40 flex space-x-1">
                          {healthTrackingData.steps.map((steps, i) => {
                            const day = new Date();
                            day.setDate(day.getDate() - (6 - i));
                            const dayName = day.toLocaleDateString('en-US', { weekday: 'short' });
                            const heightPercentage = (steps / 12000) * 100;

                            return (
                              <div key={i} className="flex flex-col items-center flex-1">
                                <div className="flex-1 w-full flex items-end">
                                  <div
                                    className="w-full bg-primary-100 dark:bg-primary-900/20"
                                    style={{ height: `${heightPercentage}%` }}
                                  ></div>
                                </div>
                                <span className="text-xs mt-1">{dayName}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Vital Statistics</CardTitle>
                    <CardDescription>Track your health metrics</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-medium mb-2">Blood Pressure</h3>
                        <div className="space-y-2">
                          {healthTrackingData.bloodPressure.slice(0, 3).map((bp, i) => {
                            const date = new Date();
                            date.setDate(date.getDate() - i);

                            return (
                              <div key={i} className="flex justify-between items-center p-2 border border-neutral-200 dark:border-neutral-700 rounded-md">
                                <span className="text-sm text-neutral-500">{date.toLocaleDateString()}</span>
                                <span className="font-medium">{bp.systolic}/{bp.diastolic} mmHg</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h3 className="font-medium mb-2">Weight</h3>
                          <div className="p-3 border border-neutral-200 dark:border-neutral-700 rounded-md">
                            <p className="text-2xl font-semibold text-center">{healthTrackingData.weight[6]} lbs</p>
                            <div className="flex items-center justify-center mt-1">
                              {healthTrackingData.weight[6] < healthTrackingData.weight[0] ? (
                                <div className="flex items-center text-green-500 text-sm">
                                  <ArrowDown className="h-3 w-3 mr-1" />
                                  <span>{healthTrackingData.weight[0] - healthTrackingData.weight[6]} lbs</span>
                                </div>
                              ) : (
                                <div className="flex items-center text-red-500 text-sm">
                                  <ArrowUp className="h-3 w-3 mr-1" />
                                  <span>{healthTrackingData.weight[6] - healthTrackingData.weight[0]} lbs</span>
                                </div>
                              )}
                              <span className="text-xs text-neutral-500 ml-1">past week</span>
                            </div>
                          </div>
                        </div>

                        <div>
                          <h3 className="font-medium mb-2">Sleep</h3>
                          <div className="p-3 border border-neutral-200 dark:border-neutral-700 rounded-md">
                            <p className="text-2xl font-semibold text-center">{healthTrackingData.sleep[6]} hrs</p>
                            <p className="text-xs text-center text-neutral-500 mt-1">Last night</p>
                            <div className="mt-2">
                              <div className="flex justify-between text-xs mb-1">
                                <span>Weekly average</span>
                                <span>{(healthTrackingData.sleep.reduce((a, b) => a + b, 0) / 7).toFixed(1)} hrs</span>
                              </div>
                              <Progress value={(healthTrackingData.sleep[6] / 9) * 100} className="h-1" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>

      {/* OCR Prescription Upload Dialog */}
      <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Upload Prescription</DialogTitle>
            <DialogDescription>
              Upload an image of your prescription and our AI will extract the details
            </DialogDescription>
          </DialogHeader>

          {!showEditForm ? (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-neutral-300 dark:border-neutral-700 rounded-lg p-6 text-center">
                {selectedFile ? (
                  <div className="space-y-2">
                    <div className="flex items-center justify-center">
                      <div className="bg-green-100 dark:bg-green-900/20 p-3 rounded-full">
                        <FileText className="h-6 w-6 text-green-700 dark:text-green-300" />
                      </div>
                    </div>
                    <p className="font-medium">{selectedFile.name}</p>
                    <p className="text-sm text-neutral-500">{(selectedFile.size / 1024).toFixed(2)} KB</p>
                    <div className="flex justify-center space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setSelectedFile(null)}
                      >
                        <XCircle className="h-4 w-4 mr-1" />
                        Remove
                      </Button>
                      <Button 
                        size="sm"
                        onClick={handleUpload}
                        disabled={isProcessing}
                      >
                        {isProcessing ? (
                          <span>Processing...</span>
                        ) : (
                          <>
                            <UploadCloud className="h-4 w-4 mr-1" />
                            Process Image
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="flex items-center justify-center">
                      <div className="bg-blue-100 dark:bg-blue-900/20 p-3 rounded-full">
                        <UploadCloud className="h-6 w-6 text-blue-700 dark:text-blue-300" />
                      </div>
                    </div>
                    <p className="font-medium">Drag and drop your prescription image</p>
                    <p className="text-sm text-neutral-500">Or click to browse your files</p>
                    <Input 
                      type="file" 
                      accept="image/*" 
                      className="mt-2 mx-auto max-w-xs"
                      onChange={handleFileSelect}
                    />
                  </div>
                )}
              </div>

              <div className="border border-neutral-200 dark:border-neutral-700 rounded-lg p-4">
                <h3 className="font-medium mb-2 flex items-center">
                  <Camera className="h-4 w-4 mr-1" />
                  Take a Photo of Your Prescription
                </h3>
                <p className="text-sm text-neutral-500 mb-3">Take a clear photo of your paper prescription</p>
                <Button className="w-full">
                  <Camera className="h-4 w-4 mr-2" />
                  Open Camera
                </Button>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
                  Cancel
                </Button>
              </DialogFooter>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="border border-neutral-200 dark:border-neutral-700 rounded-lg p-4">
                <h3 className="font-medium mb-2">Extracted Medications</h3>
                <p className="text-sm text-neutral-500 mb-3">Our AI has extracted the following medications from your prescription. Please review and edit if needed.</p>

                <div className="space-y-3">
                  {extractedMedications.map((med, i) => (
                    <div key={i} className="p-3 border border-neutral-200 dark:border-neutral-700 rounded-md">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center">
                            <Pill className="h-4 w-4 text-primary mr-2" />
                            <p className="font-medium">{med.name}</p>
                            {med.confidence > 0.9 && (
                              <Badge className="ml-2 bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
                                High Confidence
                              </Badge>
                            )}
                          </div>
                          <div className="mt-2 space-y-1">
                            <div className="flex">
                              <span className="text-sm text-neutral-500 w-24">Dosage:</span>
                              <span className="text-sm">{med.dosage}</span>
                            </div>
                            <div className="flex">
                              <span className="text-sm text-neutral-500 w-24">Frequency:</span>
                              <span className="text-sm">{med.frequency}</span>
                            </div>
                            {med.instructions && (
                              <div className="flex">
                                <span className="text-sm text-neutral-500 w-24">Instructions:</span>
                                <span className="text-sm">{med.instructions}</span>
                              </div>
                            )}
                          </div>
                        </div>
                        <Button variant="outline" size="sm">Edit</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border border-neutral-200 dark:border-neutral-700 rounded-lg p-4">
                <h3 className="font-medium mb-2">Additional Notes</h3>
                <Textarea
                  placeholder="Add any additional notes or instructions for the pharmacist..."
                  className="h-20"
                />
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSubmitOcrResults}>
                  Submit to Pharmacy
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
      
      {/* Booking Dialog */}
      <BookAppointmentDialog 
        open={showBookingDialog} 
        onOpenChange={setShowBookingDialog}
      />
    />
  );
}


// Placeholder for BookAppointmentDialog component.  Replace with actual implementation.
const BookAppointmentDialog = ({ open, onOpenChange }) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Book New Appointment</DialogTitle>
          <DialogDescription>
            Select a date and time for your appointment.
          </DialogDescription>
        </DialogHeader>
        <div>
          {/* Appointment booking form would go here */}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button>Book Appointment</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}