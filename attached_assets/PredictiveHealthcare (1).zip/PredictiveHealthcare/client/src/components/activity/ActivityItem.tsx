import { ReactNode } from "react";
import { 
  Calendar, 
  UserPlus, 
  Clock, 
  User, 
  UserCog, 
  ShoppingBag, 
  FileEdit 
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface ActivityItemProps {
  type?: string;
  message?: string;
  time?: string;
  isLoading: boolean;
}

export default function ActivityItem({ type, message, time, isLoading }: ActivityItemProps) {
  if (isLoading) {
    return (
      <li className="py-3 flex">
        <div className="relative mr-4">
          <Skeleton className="h-9 w-9 rounded-full" />
          <Skeleton className="absolute bottom-0 right-0 rounded-full w-3 h-3" />
        </div>
        <div className="flex-1">
          <Skeleton className="h-4 w-full max-w-[250px] rounded-md" />
          <Skeleton className="h-3 w-16 rounded-md mt-1" />
        </div>
      </li>
    );
  }

  // Get icon and background color based on activity type
  const getActivityIcon = () => {
    switch (type) {
      case "user-add":
        return {
          icon: <UserPlus />,
          bgClass: "bg-primary-light/10 text-primary dark:text-primary-light"
        };
      case "calendar-check":
        return {
          icon: <Calendar />,
          bgClass: "bg-accent-light/10 text-accent dark:text-accent-light"
        };
      case "rest-time":
        return {
          icon: <Clock />,
          bgClass: "bg-status-warning/10 text-status-warning"
        };
      case "user-follow":
        return {
          icon: <UserCog />,
          bgClass: "bg-secondary-light/10 text-secondary dark:text-secondary-light"
        };
      case "medicine":
        return {
          icon: <ShoppingBag />,
          bgClass: "bg-status-error/10 text-status-error"
        };
      case "edit":
        return {
          icon: <FileEdit />,
          bgClass: "bg-status-info/10 text-accent dark:text-accent-light"
        };
      default:
        return {
          icon: <User />,
          bgClass: "bg-primary-light/10 text-primary dark:text-primary-light"
        };
    }
  };

  const { icon, bgClass } = getActivityIcon();

  return (
    <li className="py-3 flex">
      <div className="relative mr-4">
        <div className={`h-9 w-9 rounded-full ${bgClass} flex items-center justify-center`}>
          {icon}
        </div>
        <div className="absolute bottom-0 right-0 rounded-full w-3 h-3 bg-white dark:bg-card flex items-center justify-center">
          <div className="rounded-full w-2 h-2 bg-status-success"></div>
        </div>
      </div>
      <div>
        <p className="text-sm text-neutral-500 dark:text-neutral-300" dangerouslySetInnerHTML={{ __html: message || "" }}></p>
        <p className="text-xs text-neutral-300 dark:text-neutral-500 mt-1">{time}</p>
      </div>
    </li>
  );
}
