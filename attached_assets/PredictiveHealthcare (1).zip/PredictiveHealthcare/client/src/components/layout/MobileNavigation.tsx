import { Link, useLocation } from "wouter";
import { User, Calendar, BarChart3, Menu, UserCog } from "lucide-react";

export default function MobileNavigation() {
  const [location] = useLocation();

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-card border-t border-neutral-200 dark:border-neutral-800 z-30">
      <div className="flex justify-around">
        <Link
          href="/admin/doctors"
          className={`flex flex-col items-center py-2 ${
            location === "/" || location === "/admin/doctors"
              ? "text-primary"
              : "text-neutral-400 dark:text-neutral-500"
          }`}
        >
          <UserCog className="text-xl" />
          <span className="text-xs mt-1">Doctors</span>
        </Link>
        <Link
          href="/admin/patients"
          className={`flex flex-col items-center py-2 ${
            location === "/admin/patients"
              ? "text-primary"
              : "text-neutral-400 dark:text-neutral-500"
          }`}
        >
          <User className="text-xl" />
          <span className="text-xs mt-1">Patients</span>
        </Link>
        <Link
          href="/admin/appointments"
          className={`flex flex-col items-center py-2 ${
            location === "/admin/appointments"
              ? "text-primary"
              : "text-neutral-400 dark:text-neutral-500"
          }`}
        >
          <Calendar className="text-xl" />
          <span className="text-xs mt-1">Appointments</span>
        </Link>
        <Link
          href="/admin/analytics"
          className={`flex flex-col items-center py-2 ${
            location === "/admin/analytics"
              ? "text-primary"
              : "text-neutral-400 dark:text-neutral-500"
          }`}
        >
          <BarChart3 className="text-xl" />
          <span className="text-xs mt-1">Analytics</span>
        </Link>
        <button className="flex flex-col items-center py-2 text-neutral-400 dark:text-neutral-500">
          <Menu className="text-xl" />
          <span className="text-xs mt-1">More</span>
        </button>
      </div>
    </div>
  );
}
