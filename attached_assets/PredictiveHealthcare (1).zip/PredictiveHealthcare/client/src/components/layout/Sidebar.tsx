import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useMobile } from "@/hooks/use-mobile";
import {
  AlertTriangle,
  BarChart3,
  Calendar,
  ChevronLeft,
  ChevronRight,
  LayoutDashboard,
  Package,
  Pill,
  Settings,
  Stethoscope,
  User,
  UserCog,
  UserPlus,
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const isMobile = useMobile();
  const [mobileOpen, setMobileOpen] = useState(false);

  // Define navigation items
  const navItems = [
    {
      category: "Dashboard",
      items: [
        {
          name: "Overview",
          icon: <LayoutDashboard className="text-xl" />,
          path: "/admin/dashboard",
        },
      ],
    },
    {
      category: "Management",
      items: [
        {
          name: "Manage Doctors",
          icon: <Stethoscope className="text-xl" />,
          path: "/admin/doctors",
        },
        {
          name: "Manage Pharmacists",
          icon: <Pill className="text-xl" />,
          path: "/admin/pharmacists",
        },
        {
          name: "Manage Patients",
          icon: <UserPlus className="text-xl" />,
          path: "/admin/patients",
        },
        {
          name: "Appointments",
          icon: <Calendar className="text-xl" />,
          path: "/admin/appointments",
        },
        {
          name: "Inventory/Medicine",
          icon: <Package className="text-xl" />,
          path: "/admin/inventory",
        },
      ],
    },
    {
      category: "Analytics",
      items: [
        {
          name: "Analytics Dashboard",
          icon: <BarChart3 className="text-xl" />,
          path: "/admin/analytics",
        },
      ],
    },
    {
      category: "System",
      items: [
        {
          name: "Settings",
          icon: <Settings className="text-xl" />,
          path: "/admin/settings",
        },
      ],
    },
  ];

  const toggleCollapsed = () => {
    setCollapsed(!collapsed);
  };

  const toggleMobileMenu = () => {
    setMobileOpen(!mobileOpen);
  };

  // Handle mobile sidebar visibility
  const sidebarClasses = isMobile
    ? `fixed inset-0 z-40 transform ${
        mobileOpen ? "translate-x-0" : "-translate-x-full"
      } transition-transform duration-300 ease-in-out md:relative md:translate-x-0`
    : "hidden md:flex flex-col";

  return (
    <>
      {/* Mobile overlay */}
      {isMobile && mobileOpen && (
        <div
          className="fixed inset-0 bg-neutral-900 bg-opacity-50 z-30"
          onClick={toggleMobileMenu}
        />
      )}

      <aside
        id="sidebar"
        className={`${sidebarClasses} bg-white dark:bg-sidebar-background w-64 shadow-md transition-all duration-300 ease-in-out z-20 ${
          collapsed && !isMobile ? "w-20" : "w-64"
        }`}
        data-collapsed={collapsed.toString()}
      >
        {/* Logo and Brand */}
        <div className="p-4 flex items-center justify-between border-b border-neutral-200 dark:border-sidebar-border">
          <div className="flex items-center space-x-2 overflow-hidden">
            <div className="flex-shrink-0 bg-primary rounded-lg p-2">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            {!collapsed && (
              <span className="text-lg font-semibold text-neutral-500 dark:text-sidebar-foreground whitespace-nowrap">
                MediCare+
              </span>
            )}
          </div>
          {!isMobile && (
            <button
              id="collapse-sidebar"
              className="text-neutral-400 hover:text-neutral-500 dark:text-neutral-400 dark:hover:text-neutral-300"
              onClick={toggleCollapsed}
            >
              {collapsed ? (
                <ChevronRight className="text-xl" />
              ) : (
                <ChevronLeft className="text-xl" />
              )}
            </button>
          )}
          {isMobile && (
            <button
              className="text-neutral-400 hover:text-neutral-500 dark:text-neutral-400 dark:hover:text-neutral-300"
              onClick={toggleMobileMenu}
            >
              <ChevronLeft className="text-xl" />
            </button>
          )}
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 overflow-y-auto scrollbar-hide pt-4">
          {navItems.map((category) => (
            <div key={category.category}>
              {!collapsed && (
                <div className="px-4 mb-2 text-xs font-semibold text-neutral-300 dark:text-neutral-500 uppercase tracking-wider">
                  {category.category}
                </div>
              )}
              {category.items.map((item) => {
                const isActive = location === item.path || location === (item.path === '/admin/doctors' ? '/' : null);
                return (
                  <Link
                    key={item.path}
                    href={item.path}
                    className={`flex items-center px-4 py-3 ${
                      isActive
                        ? "text-primary bg-primary-light/10 border-r-4 border-primary dark:text-sidebar-primary dark:bg-sidebar-primary/10 dark:border-sidebar-primary"
                        : "text-neutral-400 hover:bg-neutral-100 transition-colors dark:text-neutral-400 dark:hover:bg-sidebar-accent/5"
                    }`}
                  >
                    <div className="mr-3">{item.icon}</div>
                    {!collapsed && <span>{item.name}</span>}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        {/* User Profile Section */}
        <div className="border-t border-neutral-200 dark:border-sidebar-border p-4">
          <div className="flex items-center">
            <img
              className="h-10 w-10 rounded-full bg-neutral-200"
              src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80"
              alt="Admin profile"
            />
            {!collapsed && (
              <div className="ml-3 overflow-hidden">
                <p className="text-sm font-medium text-neutral-500 dark:text-sidebar-foreground truncate">
                  Sarah Johnson
                </p>
                <p className="text-xs text-neutral-300 dark:text-neutral-500 truncate">
                  System Administrator
                </p>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
}