import { ReactNode } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";
import MobileNavigation from "./MobileNavigation";
import { useMobile } from "@/hooks/use-mobile";

interface AppLayoutProps {
  children: ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const isMobile = useMobile();

  return (
    <div className="flex h-screen overflow-hidden" id="app-container">
      <Sidebar />
      
      <main className="flex-1 overflow-y-auto bg-background">
        <Header />
        {children}
      </main>
      
      {isMobile && <MobileNavigation />}
    </div>
  );
}
