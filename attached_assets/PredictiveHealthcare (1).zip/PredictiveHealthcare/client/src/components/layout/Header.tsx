import { useState } from "react";
import { useLocation } from "wouter";
import { useTheme } from "@/hooks/use-theme";
import { useMobile } from "@/hooks/use-mobile";
import { Menu, Search, Bell, Sun, Moon, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";

export default function Header() {
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();
  const isMobile = useMobile();
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  // Function to get page title from location
  const getPageTitle = () => {
    if (location === "/" || location === "/admin/doctors") return "Manage Doctors";
    if (location === "/admin/pharmacists") return "Manage Pharmacists";
    if (location === "/admin/patients") return "Manage Patients";
    if (location === "/admin/appointments") return "View All Appointments";
    if (location === "/admin/inventory") return "Inventory/Medicine";
    if (location === "/admin/analytics") return "Analytics Dashboard";
    if (location === "/admin/settings") return "Settings";
    return "Dashboard";
  };

  const toggleMobileMenu = () => {
    // This is a placeholder - we'll dispatch an event to toggle the sidebar from the app layout
    const event = new CustomEvent("toggle-mobile-menu");
    window.dispatchEvent(event);
  };

  return (
    <header className="bg-white dark:bg-card shadow-sm py-4 px-6 flex items-center justify-between sticky top-0 z-10">
      <div className="flex items-center">
        {isMobile && (
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-neutral-400 mr-4"
            onClick={toggleMobileMenu}
          >
            <Menu className="h-6 w-6" />
          </Button>
        )}
        <h1 className="text-xl font-semibold text-neutral-500 dark:text-foreground">
          {getPageTitle()}
        </h1>
      </div>

      <div className="flex items-center space-x-4">
        {/* Search Bar - hidden on mobile */}
        <div className="hidden md:block relative">
          <Input
            type="text"
            placeholder="Search..."
            className="pl-10 pr-4 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm"
          />
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-300" />
        </div>

        {/* Theme Toggle */}
        <Button
          variant="outline"
          size="icon"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="p-1.5 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-400"
        >
          {theme === "dark" ? (
            <Moon className="h-4 w-4" />
          ) : (
            <Sun className="h-4 w-4" />
          )}
        </Button>

        {/* Notifications */}
        <Button
          variant="outline"
          size="icon"
          className="p-1.5 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-400 relative"
        >
          <Bell className="h-4 w-4" />
          <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-status-error transform translate-x-1 -translate-y-1"></span>
        </Button>

        {/* User Menu */}
        <DropdownMenu open={userMenuOpen} onOpenChange={setUserMenuOpen}>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              className="flex items-center focus:outline-none"
            >
              <img
                className="h-8 w-8 rounded-full object-cover"
                src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80"
                alt="User"
              />
              <span className="ml-2 text-sm font-medium text-neutral-500 dark:text-neutral-300 hidden md:block">
                Sarah Johnson
              </span>
              <User className="ml-1 text-neutral-400 hidden md:block h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem>Settings</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Logout</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
