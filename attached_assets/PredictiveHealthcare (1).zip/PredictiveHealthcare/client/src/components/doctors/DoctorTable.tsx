import { useState } from "react";
import { Eye, Pencil, Trash2, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";

interface Doctor {
  id: number;
  name: string;
  email: string;
  specialization: string;
  patients: number;
  status: string;
  nextAvailability: string;
  profileImage?: string;
}

interface DoctorTableProps {
  doctors?: Doctor[];
  isLoading?: boolean;
}

export default function DoctorTable({ doctors, isLoading = false }: DoctorTableProps) {
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(4);
  
  // Mock data for skeleton or when no real data is available
  const mockDoctors = [
    {
      id: 1,
      name: "Dr. Emily Wilson",
      email: "emily.wilson@medicare.com",
      specialization: "Cardiology",
      patients: 32,
      status: "Available",
      nextAvailability: "Today, 2:00 PM",
      profileImage: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80"
    },
    {
      id: 2,
      name: "Dr. Michael Chen",
      email: "michael.chen@medicare.com",
      specialization: "Neurology",
      patients: 28,
      status: "On Leave",
      nextAvailability: "May 28, 9:00 AM",
      profileImage: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80"
    },
    {
      id: 3,
      name: "Dr. Sarah Johnson",
      email: "sarah.johnson@medicare.com",
      specialization: "Pediatrics",
      patients: 45,
      status: "Available",
      nextAvailability: "Today, 4:30 PM",
      profileImage: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80"
    },
    {
      id: 4,
      name: "Dr. James Rodriguez",
      email: "james.rodriguez@medicare.com",
      specialization: "Orthopedics",
      patients: 37,
      status: "Unavailable",
      nextAvailability: "May 25, 10:00 AM",
      profileImage: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80"
    }
  ];

  // Use real data or mock data
  const displayDoctors = doctors || mockDoctors;
  const totalDoctors = 42; // Would come from API in a real app
  
  // Calculate pagination info
  const totalPages = Math.ceil(totalDoctors / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  
  // Status badge styles
  const getStatusBadgeClass = (status: string) => {
    switch (status.toLowerCase()) {
      case "available":
        return "bg-status-success/10 text-status-success";
      case "unavailable":
        return "bg-status-error/10 text-status-error";
      case "on leave":
        return "bg-status-warning/10 text-status-warning";
      default:
        return "bg-neutral-100 text-neutral-500";
    }
  };
  
  // Pagination handlers
  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };
  
  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };
  
  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  return (
    <div>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-neutral-100 dark:bg-neutral-800">
            <TableRow>
              <TableHead className="text-xs font-medium text-neutral-400 uppercase tracking-wider">Doctor</TableHead>
              <TableHead className="text-xs font-medium text-neutral-400 uppercase tracking-wider">Specialization</TableHead>
              <TableHead className="text-xs font-medium text-neutral-400 uppercase tracking-wider">Patients</TableHead>
              <TableHead className="text-xs font-medium text-neutral-400 uppercase tracking-wider">Status</TableHead>
              <TableHead className="text-xs font-medium text-neutral-400 uppercase tracking-wider">Next Availability</TableHead>
              <TableHead className="text-xs font-medium text-neutral-400 uppercase tracking-wider text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="bg-white dark:bg-neutral-900 divide-y divide-neutral-200 dark:divide-neutral-800">
            {isLoading ? (
              // Skeleton loader for table rows
              Array(4).fill(0).map((_, index) => (
                <TableRow key={index} className="hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors">
                  <TableCell className="py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <div className="ml-4">
                        <Skeleton className="h-4 w-32 rounded-md" />
                        <Skeleton className="h-3 w-24 rounded-md mt-1" />
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    <Skeleton className="h-4 w-20 rounded-md" />
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    <Skeleton className="h-4 w-16 rounded-md" />
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    <Skeleton className="h-6 w-20 rounded-full" />
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    <Skeleton className="h-4 w-24 rounded-md" />
                  </TableCell>
                  <TableCell className="whitespace-nowrap text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <Skeleton className="h-8 w-8 rounded-md" />
                      <Skeleton className="h-8 w-8 rounded-md" />
                      <Skeleton className="h-8 w-8 rounded-md" />
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              // Actual data rows
              displayDoctors.map((doctor) => (
                <TableRow key={doctor.id} className="hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors">
                  <TableCell className="py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={doctor.profileImage} alt={doctor.name} />
                        <AvatarFallback>{doctor.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-neutral-500 dark:text-neutral-300">{doctor.name}</div>
                        <div className="text-sm text-neutral-300 dark:text-neutral-500">{doctor.email}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    <div className="text-sm text-neutral-500 dark:text-neutral-300">{doctor.specialization}</div>
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    <div className="text-sm text-neutral-500 dark:text-neutral-300">{doctor.patients} Active</div>
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    <span className={`px-2.5 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(doctor.status)}`}>
                      {doctor.status}
                    </span>
                  </TableCell>
                  <TableCell className="whitespace-nowrap text-sm text-neutral-400 dark:text-neutral-500">
                    {doctor.nextAvailability}
                  </TableCell>
                  <TableCell className="whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end space-x-2">
                      <Button variant="ghost" size="icon" className="text-neutral-400 hover:text-primary">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-neutral-400 hover:text-primary">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-neutral-400 hover:text-status-error">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      
      {/* Pagination */}
      <div className="px-6 py-4 flex items-center justify-between border-t border-neutral-200 dark:border-neutral-800">
        <div className="flex-1 flex justify-between sm:hidden">
          <Button
            variant="outline"
            size="sm"
            onClick={prevPage}
            disabled={currentPage === 1}
            className="relative inline-flex items-center px-4 py-2 text-sm font-medium rounded-md text-neutral-400 bg-white dark:bg-neutral-900"
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={nextPage}
            disabled={currentPage === totalPages}
            className="ml-3 relative inline-flex items-center px-4 py-2 text-sm font-medium rounded-md text-neutral-400 bg-white dark:bg-neutral-900"
          >
            Next
          </Button>
        </div>
        <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
          <div>
            <p className="text-sm text-neutral-400 dark:text-neutral-500">
              Showing <span className="font-medium">{indexOfFirstItem + 1}</span> to{" "}
              <span className="font-medium">
                {Math.min(indexOfLastItem, totalDoctors)}
              </span>{" "}
              of <span className="font-medium">{totalDoctors}</span> results
            </p>
          </div>
          <div>
            <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
              <Button
                variant="outline"
                size="icon"
                onClick={prevPage}
                disabled={currentPage === 1}
                className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-sm font-medium text-neutral-400"
              >
                <span className="sr-only">Previous</span>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              {/* Page numbers */}
              {[...Array(Math.min(totalPages, 5))].map((_, i) => {
                const pageNumber = i + 1;
                const isActive = pageNumber === currentPage;
                
                return (
                  <Button
                    key={i}
                    variant={isActive ? "default" : "outline"}
                    size="sm"
                    onClick={() => goToPage(pageNumber)}
                    className={`relative inline-flex items-center px-4 py-2 border ${
                      isActive
                        ? "border-primary bg-primary text-white"
                        : "border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-neutral-400"
                    }`}
                  >
                    {pageNumber}
                  </Button>
                );
              })}
              
              {totalPages > 5 && (
                <>
                  <span className="relative inline-flex items-center px-4 py-2 border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-sm font-medium text-neutral-300">
                    ...
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(totalPages)}
                    className="relative inline-flex items-center px-4 py-2 border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-sm font-medium text-neutral-400"
                  >
                    {totalPages}
                  </Button>
                </>
              )}
              
              <Button
                variant="outline"
                size="icon"
                onClick={nextPage}
                disabled={currentPage === totalPages}
                className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-sm font-medium text-neutral-400"
              >
                <span className="sr-only">Next</span>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </nav>
          </div>
        </div>
      </div>
    </div>
  );
}
