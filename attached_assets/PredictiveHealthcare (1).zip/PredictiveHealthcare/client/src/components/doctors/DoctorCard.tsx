import { useState } from "react";
import { Eye, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";

interface DoctorCardProps {
  doctor: {
    id: number;
    name: string;
    email: string;
    specialization: string;
    patients: number;
    status: string;
    nextAvailability: string;
    profileImage?: string;
  };
  isLoading?: boolean;
}

export default function DoctorCard({ doctor, isLoading = false }: DoctorCardProps) {
  if (isLoading) {
    return (
      <Card className="shadow-card overflow-hidden">
        <CardContent className="p-4">
          <div className="flex items-center">
            <Skeleton className="h-10 w-10 rounded-full" />
            <div className="ml-4">
              <Skeleton className="h-4 w-40 rounded-md" />
              <Skeleton className="h-3 w-32 rounded-md mt-2" />
            </div>
          </div>
          <div className="mt-4">
            <Skeleton className="h-4 w-24 rounded-md" />
            <Skeleton className="h-3 w-16 rounded-md mt-2" />
            <Skeleton className="h-6 w-20 rounded-md mt-3" />
            <Skeleton className="h-3 w-28 rounded-md mt-3" />
          </div>
          <div className="mt-4 flex justify-end">
            <Skeleton className="h-8 w-24 rounded-md" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "available":
        return "bg-status-success/10 text-status-success";
      case "unavailable":
        return "bg-status-error/10 text-status-error";
      case "on leave":
        return "bg-status-warning/10 text-status-warning";
      default:
        return "bg-neutral-100 text-neutral-500";
    }
  };

  return (
    <Card className="shadow-card overflow-hidden hover:shadow-lg transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-center">
          <Avatar className="h-10 w-10">
            <AvatarImage src={doctor.profileImage} alt={doctor.name} />
            <AvatarFallback>{doctor.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="ml-4">
            <div className="text-sm font-medium text-neutral-500 dark:text-neutral-300">{doctor.name}</div>
            <div className="text-sm text-neutral-300 dark:text-neutral-500">{doctor.email}</div>
          </div>
        </div>
        
        <div className="mt-3">
          <div className="text-sm text-neutral-500 dark:text-neutral-300">
            {doctor.specialization}
          </div>
          <div className="text-sm text-neutral-500 dark:text-neutral-300 mt-1">
            {doctor.patients} Active Patients
          </div>
          <div className="mt-2">
            <Badge variant="outline" className={`px-2.5 py-1 text-xs leading-5 font-semibold rounded-full ${getStatusColor(doctor.status)}`}>
              {doctor.status}
            </Badge>
          </div>
          <div className="text-sm text-neutral-400 dark:text-neutral-500 mt-2">
            Next available: {doctor.nextAvailability}
          </div>
        </div>
        
        <div className="mt-3 flex justify-end space-x-2">
          <Button variant="ghost" size="icon" className="text-neutral-400 hover:text-primary">
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="text-neutral-400 hover:text-primary">
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="text-neutral-400 hover:text-status-error">
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
