import { ReactNode } from "react";
import { ArrowUp, ArrowDown, Clock, UserRound, UserCheck, Calendar, ShoppingBag } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface StatsCardProps {
  title: string;
  value: number | string;
  trend: string;
  trendType: "up" | "down" | "neutral";
  icon: string;
  color: "primary" | "secondary" | "accent" | "warning" | "error" | "info";
  isLoading?: boolean;
}

export default function StatsCard({
  title,
  value,
  trend,
  trendType,
  icon,
  color,
  isLoading = false,
}: StatsCardProps) {
  if (isLoading) {
    return (
      <div className="bg-white dark:bg-card rounded-xl shadow-card p-4">
        <div className="flex items-start justify-between">
          <div>
            <Skeleton className="h-4 w-24 mb-2" />
            <Skeleton className="h-8 w-16 mb-2" />
            <Skeleton className="h-4 w-20" />
          </div>
          <Skeleton className="h-10 w-10 rounded-full" />
        </div>
      </div>
    );
  }

  // Get trend icon
  const getTrendIcon = () => {
    switch (trendType) {
      case "up":
        return <ArrowUp className="mr-1 h-3 w-3" />;
      case "down":
        return <ArrowDown className="mr-1 h-3 w-3" />;
      case "neutral":
      default:
        return <Clock className="mr-1 h-3 w-3" />;
    }
  };

  // Get trend color class
  const getTrendColorClass = () => {
    switch (trendType) {
      case "up":
        return "text-secondary dark:text-secondary-light";
      case "down":
        return "text-status-error";
      case "neutral":
      default:
        return "text-neutral-300 dark:text-neutral-500";
    }
  };

  // Get icon background color class
  const getIconBgClass = () => {
    switch (color) {
      case "primary":
        return "bg-primary-light/10 text-primary dark:text-primary-light";
      case "secondary":
        return "bg-secondary-light/10 text-secondary dark:text-secondary-light";
      case "accent":
        return "bg-accent-light/10 text-accent dark:text-accent-light";
      case "warning":
        return "bg-status-warning/10 text-status-warning";
      case "error":
        return "bg-status-error/10 text-status-error";
      default:
        return "bg-primary-light/10 text-primary dark:text-primary-light";
    }
  };

  // Get icon component
  const getIconComponent = () => {
    switch (icon) {
      case "user-star":
        return <UserRound className="text-xl" />;
      case "user-follow":
        return <UserCheck className="text-xl" />;
      case "rest-time":
        return <Clock className="text-xl" />;
      case "calendar-check":
        return <Calendar className="text-xl" />;
      case "medicine-bottle":
        return <ShoppingBag className="text-xl" />;
      default:
        return <UserRound className="text-xl" />;
    }
  };

  return (
    <div className="bg-white dark:bg-card rounded-xl shadow-card p-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-neutral-300 dark:text-neutral-500 text-sm">{title}</p>
          <h3 className="text-2xl font-bold text-neutral-500 dark:text-neutral-200 mt-1">
            {value}
          </h3>
          <p className={`${getTrendColorClass()} text-xs flex items-center mt-1`}>
            {getTrendIcon()}
            {trend}
          </p>
        </div>
        <div className={`rounded-full p-2 ${getIconBgClass()}`}>
          {getIconComponent()}
        </div>
      </div>
    </div>
  );
}
