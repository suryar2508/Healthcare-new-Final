
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { Calendar } from "@/components/ui/calendar";

const medicationFormSchema = z.object({
  medicationName: z.string().min(1, "Medication name is required"),
  dosage: z.string().min(1, "Dosage is required"),
  startDate: z.date()
    .min(new Date(), "Start date must be today or in the future"),
  frequency: z.enum(["daily", "twice_daily", "weekly", "monthly"], {
    required_error: "Please select frequency"
  }),
  times: z.array(z.string()).min(1, "At least one time is required"),
  duration: z.number().min(1, "Duration must be at least 1 day"),
  notes: z.string().optional(),
  reminderEnabled: z.boolean().default(true)
});

type ReminderSettings = {
  enabled: boolean;
  notificationTime: number; // minutes before
};

const defaultReminderSettings: ReminderSettings = {
  enabled: true,
  notificationTime: 30
};

export default function MedicationSchedule() {
  const [medications, setMedications] = useState([]);
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof medicationFormSchema>>({
    resolver: zodResolver(medicationFormSchema)
  });

  const onSubmit = async (values: z.infer<typeof medicationFormSchema>) => {
    try {
      // TODO: Replace with actual API call
      await fetch('/api/medications/schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values)
      });

      toast({
        title: "Medication Scheduled",
        description: "You will receive reminders for your medication."
      });
      setOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to schedule medication. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Medication Schedule</CardTitle>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>Add Medication</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Schedule New Medication</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="medicationName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Medication Name</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="dosage"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Dosage</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Start Date</FormLabel>
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) => date < new Date()}
                        />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Time</FormLabel>
                        <FormControl>
                          <Input type="time" {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <Button type="submit">Schedule Medication</Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          {medications.length === 0 ? (
            <p className="text-center text-muted-foreground">No medications scheduled</p>
          ) : (
            <div className="divide-y">
              {medications.map((med: any) => (
                <div key={med.id} className="py-3">
                  <h4 className="font-medium">{med.medicationName}</h4>
                  <p className="text-sm text-muted-foreground">
                    {med.dosage} - {med.time}
                  </p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
