import { useState } from "react";
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ChevronDown,
  ChevronUp,
  Edit,
  Trash,
  Eye,
  UserCog,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

// Define the Patient interface
interface Patient {
  id: number;
  name: string;
  email: string;
  phone?: string;
  age?: number;
  bloodGroup?: string;
  assignedDoctor?: {
    id: number;
    name: string;
  };
  lastVisit?: string;
  status: string;
}

interface PatientTableProps {
  patients?: Patient[];
  isLoading?: boolean;
}

export default function PatientTable({ patients, isLoading = false }: PatientTableProps) {
  const [sortColumn, setSortColumn] = useState<string>("name");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  // Handle sorting
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("asc");
    }
  };

  // Render sort indicators
  const renderSortIndicator = (column: string) => {
    if (sortColumn !== column) return null;
    
    return sortDirection === "asc" ? (
      <ChevronUp className="ml-1 h-4 w-4" />
    ) : (
      <ChevronDown className="ml-1 h-4 w-4" />
    );
  };

  // Function to get status badge color
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100";
      case "inactive":
        return "bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-100";
      case "pending":
        return "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100";
      default:
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100";
    }
  };

  // Loading state UI
  if (isLoading) {
    return (
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Age</TableHead>
              <TableHead>Blood Group</TableHead>
              <TableHead>Assigned Doctor</TableHead>
              <TableHead>Last Visit</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {Array(5)
              .fill(0)
              .map((_, i) => (
                <TableRow key={i}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <Skeleton className="h-4 w-32" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-40" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-10" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-16" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-36" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-24" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-6 w-16 rounded-full" />
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-1">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <Skeleton className="h-8 w-8 rounded-full" />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </div>
    );
  }

  // Empty state UI
  if (!patients || patients.length === 0) {
    return (
      <div className="p-8 text-center">
        <p className="text-neutral-500 dark:text-neutral-400">No patients found</p>
      </div>
    );
  }

  // Data-loaded UI
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead onClick={() => handleSort("name")} className="cursor-pointer">
              <div className="flex items-center">
                Name
                {renderSortIndicator("name")}
              </div>
            </TableHead>
            <TableHead onClick={() => handleSort("email")} className="cursor-pointer">
              <div className="flex items-center">
                Email
                {renderSortIndicator("email")}
              </div>
            </TableHead>
            <TableHead onClick={() => handleSort("age")} className="cursor-pointer">
              <div className="flex items-center">
                Age
                {renderSortIndicator("age")}
              </div>
            </TableHead>
            <TableHead onClick={() => handleSort("bloodGroup")} className="cursor-pointer">
              <div className="flex items-center">
                Blood Group
                {renderSortIndicator("bloodGroup")}
              </div>
            </TableHead>
            <TableHead onClick={() => handleSort("assignedDoctor")} className="cursor-pointer">
              <div className="flex items-center">
                Assigned Doctor
                {renderSortIndicator("assignedDoctor")}
              </div>
            </TableHead>
            <TableHead onClick={() => handleSort("lastVisit")} className="cursor-pointer">
              <div className="flex items-center">
                Last Visit
                {renderSortIndicator("lastVisit")}
              </div>
            </TableHead>
            <TableHead onClick={() => handleSort("status")} className="cursor-pointer">
              <div className="flex items-center">
                Status
                {renderSortIndicator("status")}
              </div>
            </TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {patients.map((patient) => (
            <TableRow key={patient.id}>
              <TableCell className="font-medium">
                <div className="flex items-center space-x-3">
                  <div className="h-10 w-10 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-500 overflow-hidden">
                    {/* Display first letter of name as avatar fallback */}
                    {patient.name ? patient.name.charAt(0).toUpperCase() : "P"}
                  </div>
                  <span>{patient.name}</span>
                </div>
              </TableCell>
              <TableCell>{patient.email}</TableCell>
              <TableCell>{patient.age || "-"}</TableCell>
              <TableCell>{patient.bloodGroup || "-"}</TableCell>
              <TableCell>
                {patient.assignedDoctor ? patient.assignedDoctor.name : "-"}
              </TableCell>
              <TableCell>{patient.lastVisit || "-"}</TableCell>
              <TableCell>
                <Badge className={getStatusColor(patient.status)}>{patient.status}</Badge>
              </TableCell>
              <TableCell>
                <div className="flex space-x-1">
                  <Button variant="ghost" size="icon" className="text-neutral-500">
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-neutral-500">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-neutral-500">
                    <UserCog className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}