import { useState } from "react";
import { format, addDays, startOfWeek, addWeeks, subWeeks } from "date-fns";
import { ChevronLeft, ChevronRight, CalendarDays, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface Appointment {
  id: number;
  patient: {
    id: number;
    name: string;
  };
  doctor: {
    id: number;
    name: string;
  };
  date: string;
  time: string;
  status: string;
}

interface AppointmentCalendarProps {
  appointments?: Appointment[];
  isLoading?: boolean;
}

export default function AppointmentCalendar({ appointments = [], isLoading = false }: AppointmentCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [currentView, setCurrentView] = useState<"week" | "day">("week");

  // Navigate to previous week/day
  const goToPrevious = () => {
    if (currentView === "week") {
      setCurrentDate(subWeeks(currentDate, 1));
    } else {
      setCurrentDate(addDays(currentDate, -1));
    }
  };

  // Navigate to next week/day
  const goToNext = () => {
    if (currentView === "week") {
      setCurrentDate(addWeeks(currentDate, 1));
    } else {
      setCurrentDate(addDays(currentDate, 1));
    }
  };

  // Navigate to today
  const goToToday = () => {
    setCurrentDate(new Date());
  };

  // Generate days for current view
  const generateDays = () => {
    if (currentView === "week") {
      const startDate = startOfWeek(currentDate, { weekStartsOn: 1 }); // Week starts on Monday
      return Array.from({ length: 7 }, (_, i) => addDays(startDate, i));
    } else {
      return [currentDate];
    }
  };

  // Function to get appointments for a specific day
  const getAppointmentsForDay = (date: Date) => {
    const dateString = format(date, "yyyy-MM-dd");
    return appointments.filter(appointment => {
      // Extract date part from appointment date (could be ISO string or other format)
      const appointmentDate = appointment.date.split("T")[0];
      return appointmentDate === dateString;
    });
  };

  // Function to get status color
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "scheduled":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100";
      case "completed":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100";
      case "cancelled":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100";
      case "in_progress":
      case "in progress":
        return "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100";
      default:
        return "bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-100";
    }
  };

  // Generate time slots from 8 AM to 6 PM
  const timeSlots = Array.from({ length: 11 }, (_, i) => {
    const hour = i + 8;
    return `${hour}:00`;
  });

  // Render skeleton loader for calendar
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div className="flex space-x-2">
            <Skeleton className="h-9 w-9 rounded-md" />
            <Skeleton className="h-9 w-9 rounded-md" />
            <Skeleton className="h-9 w-20 rounded-md" />
          </div>
          <Skeleton className="h-9 w-20 rounded-md" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
          {Array.from({ length: currentView === "week" ? 7 : 1 }).map((_, i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-8 w-24 rounded-md" />
              {timeSlots.map((_, slotIndex) => (
                <Skeleton 
                  key={slotIndex} 
                  className="h-16 w-full rounded-md"
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }

  const days = generateDays();

  return (
    <div className="space-y-4">
      {/* Calendar Header */}
      <div className="flex flex-col sm:flex-row justify-between items-center space-y-2 sm:space-y-0">
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" onClick={goToPrevious}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={goToNext}>
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button variant="outline" onClick={goToToday}>
            Today
          </Button>
          <h3 className="text-lg font-semibold ml-2">
            {currentView === "week"
              ? `${format(days[0], "MMM d")} - ${format(days[6], "MMM d, yyyy")}`
              : format(currentDate, "MMMM d, yyyy")}
          </h3>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant={currentView === "day" ? "default" : "outline"}
            onClick={() => setCurrentView("day")}
            size="sm"
          >
            Day
          </Button>
          <Button
            variant={currentView === "week" ? "default" : "outline"}
            onClick={() => setCurrentView("week")}
            size="sm"
          >
            Week
          </Button>
        </div>
      </div>
      
      {/* Calendar Grid */}
      <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
        {days.map((day, dayIndex) => (
          <div key={dayIndex} className="space-y-2">
            {/* Day Header */}
            <div className="text-center p-2 bg-neutral-50 dark:bg-neutral-800 rounded-md">
              <div className="font-medium">{format(day, "EEEE")}</div>
              <div className="text-sm text-neutral-500 dark:text-neutral-400">
                {format(day, "MMM d")}
              </div>
            </div>
            
            {/* Time Slots */}
            <div className="space-y-2">
              {timeSlots.map((timeSlot, slotIndex) => {
                const dayAppointments = getAppointmentsForDay(day);
                // Filter appointments that start at this time slot
                const slotAppointments = dayAppointments.filter(
                  appointment => appointment.time.startsWith(timeSlot.split(":")[0])
                );
                
                return (
                  <div 
                    key={slotIndex} 
                    className="border border-neutral-200 dark:border-neutral-700 rounded-md p-2 min-h-[4rem]"
                  >
                    <div className="text-xs text-neutral-500 dark:text-neutral-400 mb-1 flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {timeSlot}
                    </div>
                    
                    {slotAppointments.length > 0 ? (
                      <div className="space-y-1">
                        {slotAppointments.map(appointment => (
                          <Card 
                            key={appointment.id}
                            className="p-2 text-xs border-l-4 cursor-pointer hover:shadow-md transition-shadow"
                            style={{ 
                              borderLeftColor: 
                                appointment.status === "scheduled" ? "var(--primary)" :
                                appointment.status === "completed" ? "var(--green-600)" :
                                appointment.status === "cancelled" ? "var(--red-600)" :
                                "var(--amber-600)" 
                            }}
                          >
                            <div className="font-medium truncate">
                              {appointment.patient.name}
                            </div>
                            <div className="flex justify-between items-center mt-1">
                              <span className="text-neutral-500 truncate">
                                {appointment.doctor.name}
                              </span>
                              <Badge className={getStatusColor(appointment.status)}>
                                {appointment.status}
                              </Badge>
                            </div>
                          </Card>
                        ))}
                      </div>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}