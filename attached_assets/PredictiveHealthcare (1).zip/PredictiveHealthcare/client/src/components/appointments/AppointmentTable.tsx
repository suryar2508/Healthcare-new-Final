import { useState } from "react";
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ChevronDown,
  ChevronUp,
  Edit,
  Trash,
  Eye,
  Check,
  X,
  Calendar,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

// Define the appointment interface
interface Appointment {
  id: number;
  patient: {
    id: number;
    name: string;
    profileImage?: string;
  };
  doctor: {
    id: number;
    name: string;
    specialization: string;
  };
  date: string;
  time: string;
  status: string;
  reason?: string;
}

interface AppointmentTableProps {
  appointments?: Appointment[];
  isLoading?: boolean;
}

export default function AppointmentTable({ appointments, isLoading = false }: AppointmentTableProps) {
  const [sortColumn, setSortColumn] = useState<string>("date");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  // Handle sorting
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("asc");
    }
  };

  // Render sort indicators
  const renderSortIndicator = (column: string) => {
    if (sortColumn !== column) return null;
    
    return sortDirection === "asc" ? (
      <ChevronUp className="ml-1 h-4 w-4" />
    ) : (
      <ChevronDown className="ml-1 h-4 w-4" />
    );
  };

  // Function to get status badge color
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "scheduled":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100";
      case "completed":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100";
      case "cancelled":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100";
      case "in_progress":
      case "in progress":
        return "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100";
      default:
        return "bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-100";
    }
  };

  // Loading state UI
  if (isLoading) {
    return (
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Patient</TableHead>
              <TableHead>Doctor</TableHead>
              <TableHead>Date & Time</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Reason</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {Array(5)
              .fill(0)
              .map((_, i) => (
                <TableRow key={i}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <Skeleton className="h-4 w-32" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <Skeleton className="h-4 w-32 mb-1" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <Skeleton className="h-4 w-24 mb-1" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-6 w-20 rounded-full" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-40" />
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-1">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <Skeleton className="h-8 w-8 rounded-full" />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </div>
    );
  }

  // Empty state UI
  if (!appointments || appointments.length === 0) {
    return (
      <div className="p-8 text-center">
        <Calendar className="mx-auto h-12 w-12 text-neutral-300 mb-3" />
        <p className="text-lg font-medium text-neutral-900 dark:text-neutral-100">No appointments found</p>
        <p className="text-neutral-500 dark:text-neutral-400 mt-1">Schedule an appointment to see it here</p>
      </div>
    );
  }

  // Data-loaded UI
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead onClick={() => handleSort("patient")} className="cursor-pointer">
              <div className="flex items-center">
                Patient
                {renderSortIndicator("patient")}
              </div>
            </TableHead>
            <TableHead onClick={() => handleSort("doctor")} className="cursor-pointer">
              <div className="flex items-center">
                Doctor
                {renderSortIndicator("doctor")}
              </div>
            </TableHead>
            <TableHead onClick={() => handleSort("date")} className="cursor-pointer">
              <div className="flex items-center">
                Date & Time
                {renderSortIndicator("date")}
              </div>
            </TableHead>
            <TableHead onClick={() => handleSort("status")} className="cursor-pointer">
              <div className="flex items-center">
                Status
                {renderSortIndicator("status")}
              </div>
            </TableHead>
            <TableHead>Reason</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {appointments.map((appointment) => (
            <TableRow key={appointment.id}>
              <TableCell>
                <div className="flex items-center space-x-3">
                  <div className="h-10 w-10 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-500 overflow-hidden">
                    {appointment.patient.profileImage ? (
                      <img 
                        src={appointment.patient.profileImage} 
                        alt={appointment.patient.name} 
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      appointment.patient.name.charAt(0).toUpperCase()
                    )}
                  </div>
                  <span className="font-medium">{appointment.patient.name}</span>
                </div>
              </TableCell>
              <TableCell>
                <div>
                  <p className="font-medium">{appointment.doctor.name}</p>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">
                    {appointment.doctor.specialization}
                  </p>
                </div>
              </TableCell>
              <TableCell>
                <div>
                  <p className="font-medium">
                    {appointment.date}
                  </p>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">
                    {appointment.time}
                  </p>
                </div>
              </TableCell>
              <TableCell>
                <Badge className={getStatusColor(appointment.status)}>
                  {appointment.status}
                </Badge>
              </TableCell>
              <TableCell>
                <div className="max-w-[200px] truncate">
                  {appointment.reason || "General checkup"}
                </div>
              </TableCell>
              <TableCell>
                <div className="flex space-x-1">
                  <Button variant="ghost" size="icon" className="text-neutral-500">
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-neutral-500">
                    <Edit className="h-4 w-4" />
                  </Button>
                  {appointment.status === "scheduled" && (
                    <>
                      <Button variant="ghost" size="icon" className="text-green-500">
                        <Check className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-red-500">
                        <X className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}