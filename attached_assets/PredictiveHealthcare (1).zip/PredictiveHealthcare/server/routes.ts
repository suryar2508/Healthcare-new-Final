import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Doctors routes
  app.get("/api/doctors", async (req, res) => {
    try {
      const doctors = await storage.getDoctors();
      res.json({ success: true, data: doctors });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown error occurred";
      console.error("Error fetching doctors:", error);
      res.status(500).json({ 
        success: false, 
        error: message,
        code: "DOCTORS_FETCH_ERROR"
      });
    }
  });

  // Stats routes
  app.get("/api/doctors/stats", async (req, res) => {
    try {
      const stats = await storage.getDoctorStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching doctor stats:", error);
      res.status(500).json({ message: "Error fetching doctor stats" });
    }
  });

  app.get("/api/doctors/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid doctor ID" });
      }
      
      const doctor = await storage.getDoctorById(id);
      if (doctor) {
        res.json(doctor);
      } else {
        res.status(404).json({ message: "Doctor not found" });
      }
    } catch (error) {
      console.error("Error fetching doctor:", error);
      res.status(500).json({ message: "Error fetching doctor" });
    }
  });

  app.post("/api/doctors", async (req, res) => {
    try {
      const result = await storage.createDoctor(req.body);
      res.status(201).json(result);
    } catch (error) {
      console.error("Error creating doctor:", error);
      res.status(500).json({ message: "Error creating doctor" });
    }
  });

  app.put("/api/doctors/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid doctor ID" });
      }
      
      const result = await storage.updateDoctor(id, req.body);
      if (result) {
        res.json(result);
      } else {
        res.status(404).json({ message: "Doctor not found" });
      }
    } catch (error) {
      console.error("Error updating doctor:", error);
      res.status(500).json({ message: "Error updating doctor" });
    }
  });

  app.delete("/api/doctors/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid doctor ID" });
      }
      
      const result = await storage.deleteDoctor(id);
      if (result) {
        res.json({ message: "Doctor deleted successfully" });
      } else {
        res.status(404).json({ message: "Doctor not found" });
      }
    } catch (error) {
      console.error("Error deleting doctor:", error);
      res.status(500).json({ message: "Error deleting doctor" });
    }
  });

  // Activity routes
  app.get("/api/activities", async (req, res) => {
    try {
      const activities = await storage.getActivities();
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Error fetching activities" });
    }
  });

  // For other modules
  app.get("/api/patients", async (req, res) => {
    try {
      const patients = await storage.getPatients();
      res.json(patients);
    } catch (error) {
      console.error("Error fetching patients:", error);
      res.status(500).json({ message: "Error fetching patients" });
    }
  });

  app.get("/api/pharmacists", async (req, res) => {
    try {
      const pharmacists = await storage.getPharmacists();
      res.json(pharmacists);
    } catch (error) {
      console.error("Error fetching pharmacists:", error);
      res.status(500).json({ message: "Error fetching pharmacists" });
    }
  });

  app.get("/api/appointments", async (req, res) => {
    try {
      const { startDate, endDate, doctorId, patientId } = req.query;
      
      // Input validation
      if (startDate && isNaN(Date.parse(startDate as string))) {
        return res.status(400).json({ 
          success: false,
          error: "Invalid start date format",
          code: "INVALID_DATE_FORMAT"
        });
      }
      
      const appointments = await storage.getAppointments();
      
      // Filter appointments if query parameters are provided
      let filteredAppointments = appointments;
      if (doctorId) {
        filteredAppointments = filteredAppointments.filter(
          app => app.doctorId === Number(doctorId)
        );
      }
      
      if (patientId) {
        filteredAppointments = filteredAppointments.filter(
          app => app.patientId === Number(patientId)
        );
      }
      
      res.json({ 
        success: true, 
        data: filteredAppointments,
        count: filteredAppointments.length
      });
    } catch (error) {
      console.error("Error fetching appointments:", error);
      res.status(500).json({ 
        success: false,
        error: "Failed to fetch appointments",
        code: "APPOINTMENT_FETCH_ERROR"
      });
    }
  });

  app.get("/api/medications", async (req, res) => {
    try {
      const medications = await storage.getMedications();
      res.json(medications);
    } catch (error) {
      console.error("Error fetching medications:", error);
      res.status(500).json({ message: "Error fetching medications" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
