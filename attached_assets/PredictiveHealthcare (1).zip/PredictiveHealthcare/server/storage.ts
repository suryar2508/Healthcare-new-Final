import { dbService } from './services/database.service';
import * as schema from '../shared/schema';
import { eq, and, desc, sql } from 'drizzle-orm';
import bcrypt from "bcrypt";
import type { DoctorWithUser } from '../shared/types';

// Doctor data with joined user info
interface DoctorWithUser {
  id: number;
  userId: number;
  name: string;
  email: string;
  specialization: string;
  status: string;
  patients: number;
  nextAvailability: Date | null;
  profileImage?: string;
}

// Activity data
interface Activity {
  id: number;
  type: string;
  message: string;
  time: string;
}

// Doctor stats
interface DoctorStats {
  totalDoctors: number;
  activeDoctors: number;
  onLeave: number;
  todayAppointments: number;
}

// Storage interface for database operations
class Storage {
  // Doctor operations
  async getDoctors(): Promise<DoctorWithUser[]> {
    try {
      const doctorsWithUsers = await dbService.findMany(schema.doctors, undefined, {
        with: { user: true }
      });

      return doctorsWithUsers.map(({ user, ...doctor }) => ({
        id: doctor.id,
        userId: user.id,
        name: `Dr. ${user.firstName} ${user.lastName}`,
        email: user.email,
        specialization: doctor.specialization,
        status: doctor.status,
        patients: 0, // Will be calculated through a separate query
        nextAvailability: doctor.nextAvailability,
        profileImage: user.profileImage,
      }));
    } catch (error) {
      console.error('Error in getDoctors:', error);
      throw error;
    }
  }

  async getDoctorById(id: number): Promise<DoctorWithUser | null> {
    try {
      const doctorWithUser = await dbService.findById(schema.doctors, id, {
        with: { user: true }
      });

      if (!doctorWithUser) return null;

      const { user, ...doctor } = doctorWithUser;
      const patientCount = await this.getDoctorPatientCount(id);

      return {
        id: doctor.id,
        userId: user.id,
        name: `Dr. ${user.firstName} ${user.lastName}`,
        email: user.email,
        specialization: doctor.specialization,
        status: doctor.status,
        patients: patientCount,
        nextAvailability: doctor.nextAvailability,
        profileImage: user.profileImage,
      };
    } catch (error) {
      console.error('Error in getDoctorById:', error);
      throw error;
    }
  }

  private async getDoctorPatientCount(doctorId: number): Promise<number> {
    try {
      const patients = await dbService.findMany(schema.patients, 
        eq(schema.patients.assignedDoctorId, doctorId)
      );
      return patients.length;
    } catch (error) {
      console.error('Error getting doctor patient count:', error);
      return 0;
    }
  }

  async createDoctor(data: any): Promise<DoctorWithUser> {
    try {
      // Hash password
      const hashedPassword = await bcrypt.hash("password123", 10); // Default password, should be changed on first login

      // Create user
      const [user] = await dbService.insert(schema.users).values({
        username: `${data.firstName.toLowerCase()}.${data.lastName.toLowerCase()}`,
        email: data.email,
        password: hashedPassword,
        firstName: data.firstName,
        lastName: data.lastName,
        phone: data.phone,
        role: schema.UserRole.DOCTOR,
        status: schema.UserStatus.ACTIVE,
      }).returning();

      // Create doctor
      const [doctor] = await dbService.insert(schema.doctors).values({
        userId: user.id,
        specialization: data.specialization,
        status: schema.DoctorStatus.AVAILABLE,
        availableDays: data.availability,
        notes: data.notes,
      }).returning();

      // Log activity
      await dbService.insert(schema.activityLogs).values({
        action: "doctor_added",
        details: `<span class='font-medium'>Dr. ${data.firstName} ${data.lastName}</span> was added to the system`,
        entityType: "doctor",
        entityId: doctor.id,
      });

      return {
        id: doctor.id,
        userId: user.id,
        name: `Dr. ${user.firstName} ${user.lastName}`,
        email: user.email,
        specialization: doctor.specialization,
        status: doctor.status,
        patients: 0,
        nextAvailability: doctor.nextAvailability,
        profileImage: user.profileImage,
      };
    } catch (error) {
      console.error('Error in createDoctor:', error);
      throw error;
    }
  }

  async updateDoctor(id: number, data: any): Promise<DoctorWithUser | null> {
    try {
      const doctor = await dbService.findById(schema.doctors, id, {
        with: { user: true }
      });

      if (!doctor) return null;

      // Update user data
      if (data.firstName || data.lastName || data.email || data.phone) {
        await dbService.update(schema.users)
          .set({
            ...(data.firstName && { firstName: data.firstName }),
            ...(data.lastName && { lastName: data.lastName }),
            ...(data.email && { email: data.email }),
            ...(data.phone && { phone: data.phone }),
          })
          .where(eq(schema.users.id, doctor.userId));
      }

      // Update doctor data
      await dbService.update(schema.doctors)
        .set({
          ...(data.specialization && { specialization: data.specialization }),
          ...(data.status && { status: data.status }),
          ...(data.availableDays && { availableDays: data.availableDays }),
          ...(data.notes && { notes: data.notes }),
        })
        .where(eq(schema.doctors.id, id));

      // Fetch updated doctor
      return this.getDoctorById(id);
    } catch (error) {
      console.error('Error in updateDoctor:', error);
      throw error;
    }
  }

  async deleteDoctor(id: number): Promise<boolean> {
    try {
      const doctor = await dbService.findById(schema.doctors, id);

      if (!doctor) return false;

      // Delete doctor
      await dbService.delete(schema.doctors).where(eq(schema.doctors.id, id));

      // Delete user
      await dbService.delete(schema.users).where(eq(schema.users.id, doctor.userId));

      return true;
    } catch (error) {
      console.error('Error in deleteDoctor:', error);
      throw error;
    }
  }

  // Stats operations
  async getDoctorStats(): Promise<DoctorStats> {
    try {
      // Get total doctors
      const totalDoctorsResult = await dbService.count(schema.doctors);

      // Get active doctors
      const activeDoctorsResult = await dbService.count(schema.doctors, eq(schema.doctors.status, schema.DoctorStatus.AVAILABLE));

      // Get doctors on leave
      const onLeaveResult = await dbService.count(schema.doctors, eq(schema.doctors.status, schema.DoctorStatus.ON_LEAVE));

      // Get today's appointments
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const tomorrow = new Date(today);
      tomorrow.setDate(today.getDate() + 1);

      const todayAppointmentsResult = await dbService.count(schema.appointments, and(
        sql`${schema.appointments.date} >= ${today}`,
        sql`${schema.appointments.date} < ${tomorrow}`
      ));

      return {
        totalDoctors: totalDoctorsResult || 0,
        activeDoctors: activeDoctorsResult || 0,
        onLeave: onLeaveResult || 0,
        todayAppointments: todayAppointmentsResult || 0,
      };
    } catch (error) {
      console.error('Error in getDoctorStats:', error);
      throw error;
    }
  }

  // Activity operations
  async getActivities(): Promise<Activity[]> {
    try {
      const activityLogs = await dbService.findMany(schema.activityLogs, undefined, {
        orderBy: [desc(schema.activityLogs.timestamp)],
        limit: 10,
      });

      return activityLogs.map(log => {
        // Map activity type from action
        let type = "user-add";
        if (log.action.includes("appointment")) type = "calendar-check";
        if (log.action.includes("leave")) type = "rest-time";
        if (log.action.includes("assign")) type = "user-follow";
        if (log.action.includes("medicine") || log.action.includes("medication")) type = "medicine";
        if (log.action.includes("edit")) type = "edit";

        // Format time
        const now = new Date();
        const timestamp = new Date(log.timestamp);
        const isToday = timestamp.toDateString() === now.toDateString();

        let timeString = "";
        if (isToday) {
          timeString = timestamp.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
        } else {
          timeString = `${timestamp.toLocaleDateString([], { month: 'short', day: 'numeric' })}, ${timestamp.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
        }

        return {
          id: log.id,
          type,
          message: log.details,
          time: timeString,
        };
      });
    } catch (error) {
      console.error('Error in getActivities:', error);
      throw error;
    }
  }

  // Other operations
  async getPatients() {
    try {
      return dbService.findMany(schema.patients, undefined, {
        with: {
          user: true,
          assignedDoctor: {
            with: {
              user: true,
            },
          },
        },
      });
    } catch (error) {
      console.error('Error in getPatients:', error);
      throw error;
    }
  }

  async getPharmacists() {
    try {
      return dbService.findMany(schema.pharmacists, undefined, {
        with: { user: true },
      });
    } catch (error) {
      console.error('Error in getPharmacists:', error);
      throw error;
    }
  }

  async getAppointments() {
    try {
      const appointments = await dbService.findMany(schema.appointments);
      if (!appointments) return [];
      
      // Fetch related data in parallel for better performance
      const enrichedAppointments = await Promise.all(
        appointments.map(async (appointment) => {
          const [doctor, patient] = await Promise.all([
            dbService.findById(schema.doctors, appointment.doctorId),
            dbService.findById(schema.patients, appointment.patientId)
          ]);
          
          return {
            ...appointment,
            doctor,
            patient
          };
        })
      );
      
      return enrichedAppointments;
    } catch (error) {
      console.error('Error in getAppointments:', error);
      return [];
    }
  }

  async getMedications() {
    try {
      return dbService.findMany(schema.medications);
    } catch (error) {
      console.error('Error in getMedications:', error);
      throw error;
    }
  }
}

export const storage = new Storage();