import { db } from '../../db';
import { 
  notifications, 
  NotificationType, 
  NotificationStatus, 
  users, 
  medicationReminders, 
  prescriptionItems, 
  prescriptions, 
  medications,
  vitalSigns,
  vitalThresholds,
  patients,
  appointments,
  UserRole
} from '../../shared/schema';
import { eq, and, lt, gt, gte, lte } from 'drizzle-orm';
import * as schedule from 'node-schedule';

interface SendNotificationParams {
  userId: number;
  type: typeof NotificationType[keyof typeof NotificationType];
  title: string;
  message: string;
  entityType?: string;
  entityId?: number;
}

/**
 * Send a notification to a user
 */
export async function sendNotification({
  userId,
  type,
  title,
  message,
  entityType,
  entityId
}: SendNotificationParams): Promise<void> {
  try {
    await db.insert(notifications).values({
      userId,
      type,
      title,
      message,
      status: NotificationStatus.UNREAD,
      entityType,
      entityId,
    });

    // In a real application, this would also send the notification via WebSockets
    // and potentially trigger push notifications, SMS, or emails
    console.log(`Notification sent to user ${userId}: ${title}`);
  } catch (error) {
    console.error('Error sending notification:', error);
    throw new Error(`Failed to send notification: ${error.message}`);
  }
}

/**
 * Check for abnormal vital signs and send alerts if needed
 */
export async function checkVitalSignsAndAlert(): Promise<void> {
  try {
    // Get all recent vital signs
    const recentVitals = await db.query.vitalSigns.findMany({
      where: and(
        gte(vitalSigns.timestamp, new Date(Date.now() - 24 * 60 * 60 * 1000)), // Last 24 hours
        eq(vitalSigns.isAbnormal, true)
      ),
      with: {
        patient: {
          with: {
            user: true,
            assignedDoctor: {
              with: {
                user: true
              }
            }
          }
        }
      }
    });

    for (const vital of recentVitals) {
      // Get the thresholds for this patient and vital type
      const threshold = await db.query.vitalThresholds.findFirst({
        where: and(
          eq(vitalThresholds.patientId, vital.patientId),
          eq(vitalThresholds.type, vital.type)
        )
      });

      if (!threshold) continue;

      // Check if the vital is outside the threshold
      let isOutsideThreshold = false;
      if (threshold.minValue !== null && vital.value < threshold.minValue) {
        isOutsideThreshold = true;
      }
      if (threshold.maxValue !== null && vital.value > threshold.maxValue) {
        isOutsideThreshold = true;
      }

      if (isOutsideThreshold) {
        // Alert the patient
        if (threshold.alertPatientOnAbnormal) {
          await sendNotification({
            userId: vital.patient.userId,
            type: NotificationType.VITAL_ALERT,
            title: `Abnormal ${vital.type} Reading`,
            message: `Your ${vital.type} reading of ${vital.value} ${vital.unit} is outside normal range. Please consult your doctor.`,
            entityType: 'vital_sign',
            entityId: vital.id
          });
        }

        // Alert the doctor
        if (threshold.alertDoctorOnAbnormal && vital.patient.assignedDoctorId) {
          await sendNotification({
            userId: vital.patient.assignedDoctor.userId,
            type: NotificationType.VITAL_ALERT,
            title: `Patient Vital Alert`,
            message: `Patient ${vital.patient.user.firstName} ${vital.patient.user.lastName} has an abnormal ${vital.type} reading of ${vital.value} ${vital.unit}.`,
            entityType: 'vital_sign',
            entityId: vital.id
          });
        }
      }
    }
  } catch (error) {
    console.error('Error checking vital signs:', error);
  }
}

/**
 * Send medication reminders based on schedule
 */
export async function sendMedicationReminders(): Promise<void> {
  try {
    const now = new Date();

    // Get all active medication reminders that are due
    const dueReminders = await db.query.medicationReminders.findMany({
      where: and(
        eq(medicationReminders.isActive, true),
        lte(medicationReminders.nextReminder, now)
      ),
      with: {
        patient: {
          with: {
            user: true
          }
        },
        prescriptionItem: {
          with: {
            medication: true,
            prescription: true
          }
        }
      }
    });

    for (const reminder of dueReminders) {
      // Send the reminder notification
      await sendNotification({
        userId: reminder.patient.userId,
        type: NotificationType.MEDICATION_REMINDER,
        title: 'Medication Reminder',
        message: `Time to take ${reminder.prescriptionItem.medication.name} ${reminder.prescriptionItem.dosage}. ${reminder.prescriptionItem.instructions || ''}`,
        entityType: 'prescription_item',
        entityId: reminder.prescriptionItemId
      });

      // Update the reminder's last sent time and calculate next reminder
      const lastSent = new Date();
      let nextReminder: Date | null = null;

      if (reminder.isRecurring) {
        // Parse the frequency from the prescription item to calculate next reminder
        const frequencyText = reminder.prescriptionItem.frequency.toLowerCase();

        if (frequencyText.includes('daily')) {
          // Daily medication
          const nextDay = new Date(lastSent);
          nextDay.setDate(nextDay.getDate() + 1);

          // Set the time from the reminderTime
          const [hours, minutes] = reminder.reminderTime.split(':').map(Number);
          nextDay.setHours(hours, minutes, 0, 0);

          nextReminder = nextDay;
        } else if (frequencyText.includes('twice') || frequencyText.includes('2 times')) {
          // Twice daily - set next reminder in 12 hours
          const nextTime = new Date(lastSent);
          nextTime.setHours(nextTime.getHours() + 12);
          nextReminder = nextTime;
        } else if (frequencyText.includes('3 times') || frequencyText.includes('three times')) {
          // Three times daily - set next reminder in 8 hours
          const nextTime = new Date(lastSent);
          nextTime.setHours(nextTime.getHours() + 8);
          nextReminder = nextTime;
        } else if (frequencyText.includes('4 times') || frequencyText.includes('four times')) {
          // Four times daily - set next reminder in 6 hours
          const nextTime = new Date(lastSent);
          nextTime.setHours(nextTime.getHours() + 6);
          nextReminder = nextTime;
        } else if (frequencyText.includes('every')) {
          // Pattern like "every X hours"
          const hoursMatch = frequencyText.match(/every\s+(\d+)\s+hours?/i);
          if (hoursMatch && hoursMatch[1]) {
            const hours = parseInt(hoursMatch[1], 10);
            const nextTime = new Date(lastSent);
            nextTime.setHours(nextTime.getHours() + hours);
            nextReminder = nextTime;
          }
        }
      }

      // Update the reminder in the database
      await db.update(medicationReminders)
        .set({
          lastSent,
          nextReminder
        })
        .where(eq(medicationReminders.id, reminder.id));
    }
  } catch (error) {
    console.error('Error sending medication reminders:', error);
  }
}

/**
 * Send appointment reminders
 */
export async function sendAppointmentReminders(): Promise<void> {
  try {
    const now = new Date();
    const oneDayLater = new Date(now);
    oneDayLater.setDate(oneDayLater.getDate() + 1);

    const oneHourLater = new Date(now);
    oneHourLater.setHours(oneHourLater.getHours() + 1);

    // Find appointments within the next day
    const upcomingAppointments = await db.query.appointments.findMany({
      where: and(
        gte(appointments.date, now),
        lte(appointments.date, oneDayLater)
      ),
      with: {
        patient: {
          with: {
            user: true
          }
        },
        doctor: {
          with: {
            user: true
          }
        }
      }
    });

    for (const appointment of upcomingAppointments) {
      const timeUntilAppointment = appointment.date.getTime() - now.getTime();
      const hoursUntil = timeUntilAppointment / (1000 * 60 * 60);

      // Send day-before reminder
      if (hoursUntil >= 23 && hoursUntil <= 24) {
        // Notify patient
        await sendNotification({
          userId: appointment.patient.userId,
          type: NotificationType.APPOINTMENT,
          title: 'Appointment Reminder',
          message: `You have an appointment with ${appointment.doctor.user.firstName} ${appointment.doctor.user.lastName} tomorrow at ${appointment.date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`,
          entityType: 'appointment',
          entityId: appointment.id
        });

        // Notify doctor
        await sendNotification({
          userId: appointment.doctor.userId,
          type: NotificationType.APPOINTMENT,
          title: 'Appointment Reminder',
          message: `You have an appointment with patient ${appointment.patient.user.firstName} ${appointment.patient.user.lastName} tomorrow at ${appointment.date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`,
          entityType: 'appointment',
          entityId: appointment.id
        });
      }

      // Send hour-before reminder
      if (hoursUntil >= 0.9 && hoursUntil <= 1.1) {
        // Notify patient
        await sendNotification({
          userId: appointment.patient.userId,
          type: NotificationType.APPOINTMENT,
          title: 'Upcoming Appointment',
          message: `Your appointment with ${appointment.doctor.user.firstName} ${appointment.doctor.user.lastName} is in 1 hour.`,
          entityType: 'appointment',
          entityId: appointment.id
        });

        // Notify doctor
        await sendNotification({
          userId: appointment.doctor.userId,
          type: NotificationType.APPOINTMENT,
          title: 'Upcoming Appointment',
          message: `Your appointment with patient ${appointment.patient.user.firstName} ${appointment.patient.user.lastName} is in 1 hour.`,
          entityType: 'appointment',
          entityId: appointment.id
        });
      }
    }
  } catch (error) {
    console.error('Error sending appointment reminders:', error);
  }
}

/**
 * Notify pharmacists about new prescriptions
 */
export async function notifyPharmacistsAboutNewPrescriptions(): Promise<void> {
  try {
    // Get all pending prescriptions that haven't been processed
    const pendingPrescriptions = await db.query.prescriptions.findMany({
      where: eq(prescriptions.status, 'pending'),
      with: {
        patient: {
          with: {
            user: true
          }
        },
        doctor: {
          with: {
            user: true
          }
        },
        items: {
          with: {
            medication: true
          }
        }
      }
    });

    if (pendingPrescriptions.length === 0) {
      return;
    }

    // Get all pharmacist users
    const pharmacistUsers = await db.query.users.findMany({
      where: eq(users.role, UserRole.PHARMACIST)
    });

    for (const prescription of pendingPrescriptions) {
      // Notify all pharmacists about the new prescription
      for (const pharmacist of pharmacistUsers) {
        const doctorName = prescription.doctor 
          ? `${prescription.doctor.user.firstName} ${prescription.doctor.user.lastName}`
          : 'Patient Upload';

        await sendNotification({
          userId: pharmacist.id,
          type: NotificationType.PRESCRIPTION,
          title: 'New Prescription',
          message: `New prescription for patient ${prescription.patient.user.firstName} ${prescription.patient.user.lastName} from ${doctorName}.`,
          entityType: 'prescription',
          entityId: prescription.id
        });
      }

      // Update the prescription status to 'processing'
      await db.update(prescriptions)
        .set({ status: 'processing' })
        .where(eq(prescriptions.id, prescription.id));
    }
  } catch (error) {
    console.error('Error notifying pharmacists about new prescriptions:', error);
  }
}

/**
 * Auto-generate follow-up appointments based on diagnosis
 */
export async function suggestFollowUpAppointments(): Promise<void> {
  // This would use a more sophisticated algorithm in a real app
  // For now, we'll suggest follow-ups for completed appointments
  try {
    // Get completed appointments without follow-ups already scheduled
    // (In a real app, we would look at the diagnosis and condition)
    const completedAppointments = await db.query.appointments.findMany({
      where: eq(appointments.status, 'completed'),
      with: {
        patient: {
          with: {
            user: true
          }
        },
        doctor: {
          with: {
            user: true
          }
        }
      }
    });

    for (const appointment of completedAppointments) {
      // Check if a follow-up is already scheduled
      const hasFollowUp = await db.query.appointments.findFirst({
        where: and(
          eq(appointments.patientId, appointment.patientId),
          eq(appointments.doctorId, appointment.doctorId),
          gt(appointments.date, appointment.date)
        )
      });

      if (!hasFollowUp) {
        // Suggest a follow-up in 30 days (this would be more sophisticated in a real app)
        const followUpDate = new Date(appointment.date);
        followUpDate.setDate(followUpDate.getDate() + 30);

        // Notify the patient
        await sendNotification({
          userId: appointment.patient.userId,
          type: NotificationType.APPOINTMENT,
          title: 'Follow-up Appointment Suggested',
          message: `Based on your recent visit, a follow-up with ${appointment.doctor.user.firstName} ${appointment.doctor.user.lastName} is recommended. Would you like to schedule for ${followUpDate.toLocaleDateString()}?`,
          entityType: 'appointment',
          entityId: appointment.id
        });
      }
    }
  } catch (error) {
    console.error('Error suggesting follow-up appointments:', error);
  }
}


// Placeholder for enhanced drug interaction checking.  Replace with actual implementation.
const checkDrugInteractions = (drugs: string[]): {hasInteraction: boolean, interactions: {drugs: string[], severity: string, effect: string}[]} => {
  //  This is a placeholder.  Replace with a robust drug interaction check using an ML model or external API.
  return { hasInteraction: false, interactions: [] };
};


/**
 * Set up all notification schedules
 */
export function initializeNotificationService(): void {
  console.log('Initializing notification service...');

  // Check vital signs every hour
  schedule.scheduleJob('0 * * * *', async () => {
    console.log('Running scheduled task: Check vital signs');
    await checkVitalSignsAndAlert();
  });

  // Send medication reminders every 10 minutes
  schedule.scheduleJob('*/10 * * * *', async () => {
    console.log('Running scheduled task: Medication reminders');
    await sendMedicationReminders();
  });

  // Check for appointment reminders every hour
  schedule.scheduleJob('0 * * * *', async () => {
    console.log('Running scheduled task: Appointment reminders');
    await sendAppointmentReminders();
  });

  // Notify pharmacists about new prescriptions every 5 minutes
  schedule.scheduleJob('*/5 * * * *', async () => {
    console.log('Running scheduled task: Notify pharmacists about new prescriptions');
    await notifyPharmacistsAboutNewPrescriptions();
  });

  // Suggest follow-up appointments daily
  schedule.scheduleJob('0 8 * * *', async () => {
    console.log('Running scheduled task: Suggest follow-up appointments');
    await suggestFollowUpAppointments();
  });

  console.log('Notification service initialized. Scheduled tasks running...');
}