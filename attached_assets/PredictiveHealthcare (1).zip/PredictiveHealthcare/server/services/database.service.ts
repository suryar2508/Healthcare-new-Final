import { db } from '../../db';
import { eq, and, or } from 'drizzle-orm';
import * as schema from '../../shared/schema';

class DatabaseService {
  private handleError(error: any, operation: string): never {
    console.error(`Database ${operation} error:`, error);
    throw new Error(`Database ${operation} failed: ${error.message}`);
  }

  async findById<T extends { id: number }>(
    table: any,
    id: number,
    relations?: { with: any }
  ): Promise<T | null> {
    try {
      if (!table) throw new Error('Table is required');
      return await db.select().from(table).where(eq(table.id, id)).execute();
    } catch (error) {
      this.handleError(error, 'findById');
    }
  }

  async findMany<T>(
    table: any,
    conditions?: any,
    relations?: { with: any }
  ): Promise<T[]> {
    try {
      if (!table) throw new Error('Table is required');
      let query = db.select().from(table);

      if (conditions) {
        query = query.where(conditions);
      }

      if (relations?.with) {
        query = query.leftJoin(relations.with);
      }

      return await query.execute();
    } catch (error) {
      this.handleError(error, 'findMany');
    }
  }

  async create<T>(table: any, data: Partial<T>): Promise<T> {
    try {
      if (!table) throw new Error('Table is required');
      const [result] = await db.insert(table).values(data).returning();
      return result as T;
    } catch (error) {
      this.handleError(error, 'create');
    }
  }

  async update<T>(table: any, id: number, data: Partial<T>): Promise<T> {
    try {
      if (!table) throw new Error('Table is required');
      const [result] = await db
        .update(table)
        .set(data)
        .where(eq(table.id, id))
        .returning();
      return result as T;
    } catch (error) {
      this.handleError(error, 'update');
    }
  }

  async delete(table: any, id: number): Promise<boolean> {
    try {
      if (!table) throw new Error('Table is required');
      const result = await db.delete(table).where(eq(table.id, id));
      return !!result;
    } catch (error) {
      this.handleError(error, 'delete');
    }
  }

  async count(table: any, conditions?: any): Promise<number> {
    try {
      if (!table) throw new Error('Table is required');
      let query = db.select().from(table);

      if (conditions) {
        query = query.where(conditions);
      }

      const result = await query.execute();
      return result.length;
    } catch (error) {
      this.handleError(error, 'count');
    }
  }
}

export const dbService = new DatabaseService();

export const getAppointments = async () => {
  const appointments = await db.query.appointments.findMany();

  // Return sample data if no appointments exist
  if (!appointments.length) {
    return [
      { id: 1, date: new Date().toISOString(), doctor: "Dr. James Wilson", specialty: "Cardiology", status: "upcoming", purpose: "Regular checkup" },
      { id: 2, date: new Date(Date.now() + 86400000).toISOString(), doctor: "Dr. Emma Davis", specialty: "Neurology", status: "upcoming", purpose: "Consultation" }
    ];
  }

  return appointments;
};