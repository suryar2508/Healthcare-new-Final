import * as Tesseract from 'tesseract.js';
import * as tf from '@tensorflow/tfjs-node';
import * as fs from 'fs';
import * as path from 'path';
import { db } from '../../db';
import { prescriptionTrainingData, prescriptions, PrescriptionSource, medications } from '../../shared/schema';
import { eq, desc } from 'drizzle-orm';
import sharp from 'sharp';

interface MedicationExtraction {
  name: string;
  dosage: string;
  frequency: string;
  instructions?: string;
  confidence: number;
}

interface OCRResult {
  medications: MedicationExtraction[];
  overallConfidence: number;
  processingTime: number;
}

// Directory to store uploaded prescription images and training data
const UPLOAD_DIR = path.join(process.cwd(), 'uploads');
const TRAINING_DATA_DIR = path.join(UPLOAD_DIR, 'training');

// Ensure directories exist
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

if (!fs.existsSync(TRAINING_DATA_DIR)) {
  fs.mkdirSync(TRAINING_DATA_DIR, { recursive: true });
}

// Function to preprocess image for better OCR results
async function preprocessImage(imagePath: string): Promise<string> {
  const outputPath = path.join(
    path.dirname(imagePath),
    `processed_${path.basename(imagePath)}`
  );

  await sharp(imagePath)
    .resize(1500) // Resize to reasonable dimensions
    .grayscale() // Convert to grayscale
    .normalize() // Normalize contrast
    .sharpen() // Sharpen for better text recognition
    .threshold(128) // Apply binary threshold
    .toFile(outputPath);

  return outputPath;
}

// Function to extract medication information from OCR text
async function extractMedicationsFromText(text: string): Promise<MedicationExtraction[]> {
  // Load all medication names from database for reference
  const allMedications = await db.query.medications.findMany({
    orderBy: [desc(medications.name)]
  });

  const medicationNames = allMedications.map(med => med.name.toLowerCase());
  
  // Regular expressions for matching medication patterns
  const medicationRegex = /(\w+\s*\w*)\s+(\d+\s*(?:mg|ml|g|mcg|IU))\s+(?:(\d+\s*(?:times|x)\s*(?:daily|a day|per day)|once daily|twice daily|every\s*\d+\s*hours?|as needed|before meals|after meals))/gi;
  
  // Advanced extraction using pattern matching
  const medications: MedicationExtraction[] = [];
  let matches;
  
  while ((matches = medicationRegex.exec(text)) !== null) {
    const name = matches[1].trim();
    const dosage = matches[2].trim();
    const frequency = matches[3] ? matches[3].trim() : "as directed";
    
    // Get instructions if available (text after the matched medication pattern)
    const instructionMatch = text.slice(matches.index + matches[0].length).match(/([^.;]*[.;])/);
    const instructions = instructionMatch ? instructionMatch[1].trim() : undefined;
    
    // Calculate confidence based on whether the medication name matches our database
    const matchedMedication = medicationNames.find(medName => 
      medName.includes(name.toLowerCase()) || name.toLowerCase().includes(medName)
    );
    
    // Higher confidence if medication name matches our database
    const confidence = matchedMedication ? 0.9 : 0.7;
    
    medications.push({
      name,
      dosage,
      frequency,
      instructions,
      confidence
    });
  }
  
  // If pattern matching found nothing, try a more basic approach
  if (medications.length === 0) {
    // Check for any known medications in the text
    for (const medName of medicationNames) {
      const regex = new RegExp(`\\b${medName}\\b`, 'i');
      if (regex.test(text)) {
        // Extract the surrounding context (50 characters before and after)
        const match = text.match(new RegExp(`.{0,50}\\b${medName}\\b.{0,50}`, 'i'));
        if (match) {
          const context = match[0];
          
          // Try to extract dosage and frequency from context
          const dosageMatch = context.match(/\d+\s*(?:mg|ml|g|mcg|IU)/i);
          const frequencyMatch = context.match(/\d+\s*(?:times|x)\s*(?:daily|a day|per day)|once daily|twice daily|every\s*\d+\s*hours?|as needed|before meals|after meals/i);
          
          medications.push({
            name: medName,
            dosage: dosageMatch ? dosageMatch[0] : "Not specified",
            frequency: frequencyMatch ? frequencyMatch[0] : "As directed",
            confidence: 0.6
          });
        }
      }
    }
  }
  
  return medications;
}

// Main OCR function to process prescription images
export async function processPrescriptionImage(
  imagePath: string, 
  patientId: number, 
  saveToTrainingData = false
): Promise<OCRResult> {
  const startTime = Date.now();
  
  try {
    // Preprocess the image for better OCR results
    const processedImagePath = await preprocessImage(imagePath);
    
    // Perform OCR on the preprocessed image
    const result = await Tesseract.recognize(
      processedImagePath,
      'eng',
      {
        logger: m => console.log(m)
      }
    );
    
    // Extract structured medication information from the OCR text
    const extractedMedications = await extractMedicationsFromText(result.data.text);
    
    // Calculate overall confidence
    const overallConfidence = extractedMedications.length > 0
      ? extractedMedications.reduce((acc, med) => acc + med.confidence, 0) / extractedMedications.length
      : 0;
    
    const processingTime = (Date.now() - startTime) / 1000; // in seconds
    
    // If this is a good sample, save it to the training data
    if (saveToTrainingData && overallConfidence > 0.7) {
      await saveTrainingData(imagePath, {
        originalText: result.data.text,
        extractedMedications,
        confidence: overallConfidence
      });
    }
    
    // Save to prescriptions table
    const [prescription] = await db.insert(prescriptions).values({
      patientId,
      source: PrescriptionSource.OCR,
      ocrConfidence: overallConfidence,
      uploadedImagePath: imagePath,
    }).returning();
    
    // Clean up the processed image
    fs.unlinkSync(processedImagePath);
    
    return {
      medications: extractedMedications,
      overallConfidence,
      processingTime
    };
  } catch (error) {
    console.error('Error in OCR processing:', error);
    throw new Error(`OCR processing failed: ${error.message}`);
  }
}

// Function to save training data for improving the OCR model
async function saveTrainingData(imagePath: string, labeledData: any): Promise<void> {
  try {
    // Copy the image to the training data directory
    const filename = path.basename(imagePath);
    const trainingImagePath = path.join(TRAINING_DATA_DIR, filename);
    
    fs.copyFileSync(imagePath, trainingImagePath);
    
    // Save metadata to the database
    await db.insert(prescriptionTrainingData).values({
      imagePath: trainingImagePath,
      labeledData,
      isUsedForTraining: false,
      accuracy: labeledData.confidence,
    });
    
    console.log('Saved training data successfully');
  } catch (error) {
    console.error('Error saving training data:', error);
  }
}

// Function to train the model using saved training data
export async function trainModel(): Promise<void> {
  // This is a placeholder for the actual model training code
  // In a real implementation, you would:
  // 1. Load all training data from the database
  // 2. Preprocess the images and labels
  // 3. Train a TensorFlow.js model
  // 4. Save the model for future use
  
  // Here's a simplified example:
  try {
    const trainingData = await db.query.prescriptionTrainingData.findMany({
      where: eq(prescriptionTrainingData.isUsedForTraining, false)
    });
    
    if (trainingData.length < 10) {
      console.log('Not enough training data. Need at least 10 samples.');
      return;
    }
    
    console.log(`Training model with ${trainingData.length} samples...`);
    
    // In a real implementation, you would:
    // 1. Create a model
    // const model = tf.sequential();
    // model.add(tf.layers.conv2d({ ... }));
    // ...
    
    // 2. Prepare the training data
    // const xs = tf.tensor4d([...]);  // Images
    // const ys = tf.tensor2d([...]);  // Labels
    
    // 3. Train the model
    // await model.fit(xs, ys, { epochs: 10, ... });
    
    // 4. Save the model
    // await model.save('file://./models/prescription-model');
    
    // Mark the data as used for training
    for (const data of trainingData) {
      await db.update(prescriptionTrainingData)
        .set({ isUsedForTraining: true })
        .where(eq(prescriptionTrainingData.id, data.id));
    }
    
    console.log('Model training completed successfully.');
  } catch (error) {
    console.error('Error training model:', error);
    throw new Error(`Model training failed: ${error.message}`);
  }
}

// Initialize the model
export async function initializeOCRService(): Promise<void> {
  console.log('Initializing OCR service...');
  
  // Load the Tesseract worker
  await Tesseract.createWorker('eng');
  
  // Check if we have a trained model and load it
  const modelPath = path.join(process.cwd(), 'models', 'prescription-model');
  
  if (fs.existsSync(modelPath)) {
    try {
      // In a real implementation, you would load your custom model:
      // await tf.loadLayersModel(`file://${modelPath}/model.json`);
      console.log('Custom prescription model loaded successfully.');
    } catch (error) {
      console.error('Error loading model:', error);
      console.log('Falling back to standard OCR processing.');
    }
  } else {
    console.log('No custom model found. Using standard OCR processing.');
  }
}