
import { db } from '../../db';
import { prescriptions, prescriptionItems, medications } from '../../shared/schema';
import { eq, and } from 'drizzle-orm';

interface BillingDetails {
  totalCost: number;
  items: Array<{
    medicationName: string;
    quantity: number;
    unitPrice: number;
    subtotal: number;
  }>;
  taxes?: number;
  discount?: number;
}

export async function calculatePrescriptionCost(prescriptionId: number): Promise<BillingDetails> {
  try {
    const prescription = await db.query.prescriptions.findFirst({
      where: eq(prescriptions.id, prescriptionId),
      with: {
        items: {
          with: {
            medication: true
          }
        }
      }
    });

    if (!prescription) {
      throw new Error('Prescription not found');
    }

    // Calculate total cost from all items
    const totalCost = prescription.items.reduce((sum, item) => {
      return sum + (item.medication.price * item.quantity);
    }, 0);

    // Update prescription with total cost
    await db.update(prescriptions)
      .set({ totalCost })
      .where(eq(prescriptions.id, prescriptionId));

    return totalCost;
  } catch (error) {
    console.error('Error calculating prescription cost:', error);
    throw error;
  }
}
