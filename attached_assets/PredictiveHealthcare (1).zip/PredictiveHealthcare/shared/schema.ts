import { pgTable, text, serial, integer, boolean, timestamp, jsonb, date, real, time } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User roles
export const UserRole = {
  ADMIN: "admin",
  DOCTOR: "doctor",
  PATIENT: "patient",
  PHARMACIST: "pharmacist",
  RECEPTIONIST: "receptionist",
} as const;

// User status
export const UserStatus = {
  ACTIVE: "active",
  INACTIVE: "inactive",
  ON_LEAVE: "on_leave",
  SUSPENDED: "suspended",
} as const;

// Doctor status
export const DoctorStatus = {
  AVAILABLE: "available",
  UNAVAILABLE: "unavailable",
  ON_LEAVE: "on_leave",
} as const;

// Appointment status
export const AppointmentStatus = {
  SCHEDULED: "scheduled",
  COMPLETED: "completed",
  CANCELLED: "cancelled",
  IN_PROGRESS: "in_progress",
} as const;

// Prescription status
export const PrescriptionStatus = {
  PENDING: "pending",
  PROCESSING: "processing",
  READY: "ready",
  DELIVERED: "delivered",
  CANCELLED: "cancelled",
} as const;

// Prescription source
export const PrescriptionSource = {
  DOCTOR: "doctor",
  PATIENT_UPLOAD: "patient_upload",
  OCR: "ocr",
} as const;

// Notification status
export const NotificationStatus = {
  UNREAD: "unread",
  READ: "read",
  DISMISSED: "dismissed",
} as const;

// Notification type
export const NotificationType = {
  APPOINTMENT: "appointment",
  PRESCRIPTION: "prescription",
  MEDICATION_REMINDER: "medication_reminder",
  VITAL_ALERT: "vital_alert",
  SYSTEM: "system",
} as const;

// Vital sign type
export const VitalSignType = {
  BLOOD_PRESSURE: "blood_pressure",
  HEART_RATE: "heart_rate",
  BLOOD_SUGAR: "blood_sugar",
  OXYGEN_LEVEL: "oxygen_level",
  TEMPERATURE: "temperature",
  WEIGHT: "weight",
} as const;

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  phone: text("phone"),
  role: text("role").notNull().default(UserRole.PATIENT),
  status: text("status").notNull().default(UserStatus.ACTIVE),
  profileImage: text("profile_image"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Doctors table
export const doctors = pgTable("doctors", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  specialization: text("specialization").notNull(),
  qualification: text("qualification"),
  experience: integer("experience"),
  status: text("status").notNull().default(DoctorStatus.AVAILABLE),
  availableDays: jsonb("available_days").$type<string[]>(),
  nextAvailability: timestamp("next_availability"),
  notes: text("notes"),
});

// Patients table
export const patients = pgTable("patients", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  dateOfBirth: date("date_of_birth"),
  bloodGroup: text("blood_group"),
  allergies: jsonb("allergies").$type<string[]>(),
  medicalHistory: text("medical_history"),
  emergencyContact: text("emergency_contact"),
  insuranceDetails: text("insurance_details"),
  assignedDoctorId: integer("assigned_doctor_id").references(() => doctors.id),
});

// Pharmacists table
export const pharmacists = pgTable("pharmacists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  qualification: text("qualification"),
  licenseNumber: text("license_number"),
  experience: integer("experience"),
});

// Appointments table
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  doctorId: integer("doctor_id").references(() => doctors.id).notNull(),
  date: timestamp("date").notNull(),
  reason: text("reason"),
  status: text("status").notNull().default(AppointmentStatus.SCHEDULED),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Medications table
export const medications = pgTable("medications", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  dosage: text("dosage").notNull(),
  category: text("category"),
  stock: integer("stock").notNull().default(0),
  manufacturer: text("manufacturer"),
  expiryDate: date("expiry_date"),
  price: integer("price"), // in cents
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Activity Log table
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  action: text("action").notNull(),
  details: text("details"),
  entityType: text("entity_type"),
  entityId: integer("entity_id"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Prescriptions table
export const prescriptions = pgTable("prescriptions", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  doctorId: integer("doctor_id").references(() => doctors.id),
  source: text("source").notNull().default(PrescriptionSource.DOCTOR),
  date: timestamp("date").defaultNow().notNull(),
  status: text("status").notNull().default(PrescriptionStatus.PENDING),
  notes: text("notes"),
  uploadedImagePath: text("uploaded_image_path"),
  ocrConfidence: real("ocr_confidence"),
  totalCost: integer("total_cost"), // in cents
  isPaid: boolean("is_paid").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Prescription Items table (many-to-many between prescriptions and medications)
export const prescriptionItems = pgTable("prescription_items", {
  id: serial("id").primaryKey(),
  prescriptionId: integer("prescription_id").references(() => prescriptions.id).notNull(),
  medicationId: integer("medication_id").references(() => medications.id).notNull(),
  dosage: text("dosage").notNull(),
  frequency: text("frequency").notNull(),
  duration: text("duration"),
  instructions: text("instructions"),
  quantity: integer("quantity").notNull(),
  inStock: boolean("in_stock").default(true),
  alternativesAvailable: boolean("alternatives_available").default(false),
  alternativeMedicationId: integer("alternative_medication_id").references(() => medications.id),
});

// Medication Reminders table
export const medicationReminders = pgTable("medication_reminders", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  prescriptionItemId: integer("prescription_item_id").references(() => prescriptionItems.id).notNull(),
  reminderTime: time("reminder_time").notNull(),
  isActive: boolean("is_active").default(true),
  isRecurring: boolean("is_recurring").default(true),
  lastSent: timestamp("last_sent"),
  nextReminder: timestamp("next_reminder"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Vital Signs table for patient health tracking
export const vitalSigns = pgTable("vital_signs", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  type: text("type").notNull(),
  value: real("value").notNull(),
  unit: text("unit").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  notes: text("notes"),
  isAbnormal: boolean("is_abnormal").default(false),
  deviceSource: text("device_source"),
});

// Vital Thresholds for alerts based on patient conditions
export const vitalThresholds = pgTable("vital_thresholds", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  type: text("type").notNull(),
  minValue: real("min_value"),
  maxValue: real("max_value"),
  unit: text("unit").notNull(),
  alertDoctorOnAbnormal: boolean("alert_doctor_on_abnormal").default(true),
  alertPatientOnAbnormal: boolean("alert_patient_on_abnormal").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Diet Plans table for patient recommendations
export const dietPlans = pgTable("diet_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  conditions: jsonb("conditions").$type<string[]>(),
  foodRecommendations: jsonb("food_recommendations").$type<string[]>(),
  foodRestrictions: jsonb("food_restrictions").$type<string[]>(),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Patient Diet Plans (many-to-many between patients and diet plans)
export const patientDietPlans = pgTable("patient_diet_plans", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  dietPlanId: integer("diet_plan_id").references(() => dietPlans.id).notNull(),
  assignedBy: integer("assigned_by").references(() => users.id),
  assignedAt: timestamp("assigned_at").defaultNow().notNull(),
  isActive: boolean("is_active").default(true),
});

// Notifications table for the system-wide notification system
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  type: text("type").notNull().default(NotificationType.SYSTEM),
  title: text("title").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default(NotificationStatus.UNREAD),
  entityType: text("entity_type"),
  entityId: integer("entity_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  readAt: timestamp("read_at"),
});

// Model Training Data for OCR prescription analysis
export const prescriptionTrainingData = pgTable("prescription_training_data", {
  id: serial("id").primaryKey(),
  imagePath: text("image_path").notNull(),
  labeledData: jsonb("labeled_data").notNull(),
  modelVersion: text("model_version"),
  isUsedForTraining: boolean("is_used_for_training").default(false),
  accuracy: real("accuracy"),
  processingTime: real("processing_time"),
  uploadedBy: integer("uploaded_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Define relationships
export const doctorsRelations = relations(doctors, ({ one }) => ({
  user: one(users, {
    fields: [doctors.userId],
    references: [users.id],
  }),
}));

export const patientsRelations = relations(patients, ({ one }) => ({
  user: one(users, {
    fields: [patients.userId],
    references: [users.id],
  }),
  assignedDoctor: one(doctors, {
    fields: [patients.assignedDoctorId],
    references: [doctors.id],
  }),
}));

export const pharmacistsRelations = relations(pharmacists, ({ one }) => ({
  user: one(users, {
    fields: [pharmacists.userId],
    references: [users.id],
  }),
}));

export const appointmentsRelations = relations(appointments, ({ one }) => ({
  patient: one(patients, {
    fields: [appointments.patientId],
    references: [patients.id],
  }),
  doctor: one(doctors, {
    fields: [appointments.doctorId],
    references: [doctors.id],
  }),
}));

export const prescriptionsRelations = relations(prescriptions, ({ one, many }) => ({
  patient: one(patients, {
    fields: [prescriptions.patientId],
    references: [patients.id],
  }),
  doctor: one(doctors, {
    fields: [prescriptions.doctorId],
    references: [doctors.id],
  }),
  items: many(prescriptionItems),
}));

export const prescriptionItemsRelations = relations(prescriptionItems, ({ one }) => ({
  prescription: one(prescriptions, {
    fields: [prescriptionItems.prescriptionId],
    references: [prescriptions.id],
  }),
  medication: one(medications, {
    fields: [prescriptionItems.medicationId],
    references: [medications.id],
  }),
  alternativeMedication: one(medications, {
    fields: [prescriptionItems.alternativeMedicationId],
    references: [medications.id],
  }),
}));

export const medicationRemindersRelations = relations(medicationReminders, ({ one }) => ({
  patient: one(patients, {
    fields: [medicationReminders.patientId],
    references: [patients.id],
  }),
  prescriptionItem: one(prescriptionItems, {
    fields: [medicationReminders.prescriptionItemId],
    references: [prescriptionItems.id],
  }),
}));

export const vitalSignsRelations = relations(vitalSigns, ({ one }) => ({
  patient: one(patients, {
    fields: [vitalSigns.patientId],
    references: [patients.id],
  }),
}));

export const vitalThresholdsRelations = relations(vitalThresholds, ({ one }) => ({
  patient: one(patients, {
    fields: [vitalThresholds.patientId],
    references: [patients.id],
  }),
}));

export const patientDietPlansRelations = relations(patientDietPlans, ({ one }) => ({
  patient: one(patients, {
    fields: [patientDietPlans.patientId],
    references: [patients.id],
  }),
  dietPlan: one(dietPlans, {
    fields: [patientDietPlans.dietPlanId],
    references: [dietPlans.id],
  }),
  assignedByUser: one(users, {
    fields: [patientDietPlans.assignedBy],
    references: [users.id],
  }),
}));

export const dietPlansRelations = relations(dietPlans, ({ one, many }) => ({
  createdByUser: one(users, {
    fields: [dietPlans.createdBy],
    references: [users.id],
  }),
  patientDietPlans: many(patientDietPlans),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

export const prescriptionTrainingDataRelations = relations(prescriptionTrainingData, ({ one }) => ({
  uploadedByUser: one(users, {
    fields: [prescriptionTrainingData.uploadedBy],
    references: [users.id],
  }),
}));

// Validation schemas
export const insertUserSchema = createInsertSchema(users, {
  email: (schema) => schema.email("Please enter a valid email"),
  firstName: (schema) => schema.min(2, "First name must be at least 2 characters"),
  lastName: (schema) => schema.min(2, "Last name must be at least 2 characters"),
  phone: (schema) => schema.optional(),
  profileImage: (schema) => schema.optional(),
});

export const insertDoctorSchema = createInsertSchema(doctors, {
  specialization: (schema) => schema.min(2, "Specialization must be at least 2 characters"),
  qualification: (schema) => schema.optional(),
  experience: (schema) => schema.optional(),
  availableDays: (schema) => schema.optional(),
  nextAvailability: (schema) => schema.optional(),
  notes: (schema) => schema.optional(),
});

export const insertPatientSchema = createInsertSchema(patients, {
  dateOfBirth: (schema) => schema.optional(),
  bloodGroup: (schema) => schema.optional(),
  allergies: (schema) => schema.optional(),
  medicalHistory: (schema) => schema.optional(),
  emergencyContact: (schema) => schema.optional(),
  insuranceDetails: (schema) => schema.optional(),
  assignedDoctorId: (schema) => schema.optional(),
});

export const insertPharmacistSchema = createInsertSchema(pharmacists, {
  qualification: (schema) => schema.optional(),
  licenseNumber: (schema) => schema.optional(),
  experience: (schema) => schema.optional(),
});

export const insertAppointmentSchema = createInsertSchema(appointments);
export const insertMedicationSchema = createInsertSchema(medications);
export const insertActivityLogSchema = createInsertSchema(activityLogs);

// New validation schemas
export const insertPrescriptionSchema = createInsertSchema(prescriptions, {
  doctorId: (schema) => schema.optional(),
  notes: (schema) => schema.optional(),
  uploadedImagePath: (schema) => schema.optional(),
  ocrConfidence: (schema) => schema.optional(),
  totalCost: (schema) => schema.optional(),
});

export const insertPrescriptionItemSchema = createInsertSchema(prescriptionItems, {
  duration: (schema) => schema.optional(),
  instructions: (schema) => schema.optional(),
  alternativeMedicationId: (schema) => schema.optional(),
});

export const insertMedicationReminderSchema = createInsertSchema(medicationReminders, {
  lastSent: (schema) => schema.optional(),
  nextReminder: (schema) => schema.optional(),
});

export const insertVitalSignSchema = createInsertSchema(vitalSigns, {
  notes: (schema) => schema.optional(),
  deviceSource: (schema) => schema.optional(),
});

export const insertVitalThresholdSchema = createInsertSchema(vitalThresholds, {
  minValue: (schema) => schema.optional(),
  maxValue: (schema) => schema.optional(),
});

export const insertDietPlanSchema = createInsertSchema(dietPlans, {
  conditions: (schema) => schema.optional(),
  foodRestrictions: (schema) => schema.optional(),
  createdBy: (schema) => schema.optional(),
});

export const insertPatientDietPlanSchema = createInsertSchema(patientDietPlans);

export const insertNotificationSchema = createInsertSchema(notifications, {
  entityType: (schema) => schema.optional(),
  entityId: (schema) => schema.optional(),
  readAt: (schema) => schema.optional(),
});

export const insertPrescriptionTrainingDataSchema = createInsertSchema(prescriptionTrainingData, {
  modelVersion: (schema) => schema.optional(),
  accuracy: (schema) => schema.optional(),
  processingTime: (schema) => schema.optional(),
  uploadedBy: (schema) => schema.optional(),
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Doctor = typeof doctors.$inferSelect;
export type InsertDoctor = z.infer<typeof insertDoctorSchema>;

export type Patient = typeof patients.$inferSelect;
export type InsertPatient = z.infer<typeof insertPatientSchema>;

export type Pharmacist = typeof pharmacists.$inferSelect;
export type InsertPharmacist = z.infer<typeof insertPharmacistSchema>;

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;

export type Medication = typeof medications.$inferSelect;
export type InsertMedication = z.infer<typeof insertMedicationSchema>;

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;

// New type exports
export type Prescription = typeof prescriptions.$inferSelect;
export type InsertPrescription = z.infer<typeof insertPrescriptionSchema>;

export type PrescriptionItem = typeof prescriptionItems.$inferSelect;
export type InsertPrescriptionItem = z.infer<typeof insertPrescriptionItemSchema>;

export type MedicationReminder = typeof medicationReminders.$inferSelect;
export type InsertMedicationReminder = z.infer<typeof insertMedicationReminderSchema>;

export type VitalSign = typeof vitalSigns.$inferSelect;
export type InsertVitalSign = z.infer<typeof insertVitalSignSchema>;

export type VitalThreshold = typeof vitalThresholds.$inferSelect;
export type InsertVitalThreshold = z.infer<typeof insertVitalThresholdSchema>;

export type DietPlan = typeof dietPlans.$inferSelect;
export type InsertDietPlan = z.infer<typeof insertDietPlanSchema>;

export type PatientDietPlan = typeof patientDietPlans.$inferSelect;
export type InsertPatientDietPlan = z.infer<typeof insertPatientDietPlanSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type PrescriptionTrainingData = typeof prescriptionTrainingData.$inferSelect;
export type InsertPrescriptionTrainingData = z.infer<typeof insertPrescriptionTrainingDataSchema>;
